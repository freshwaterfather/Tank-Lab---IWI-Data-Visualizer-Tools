# =============================================================================
# IWI_stream_outlet_visualizer.R
# Indiana Watershed Initiative (IWI): Stream Outlet Data Visualizer
#
# Rebuilds IWI_stream_outlet_visualizer.html from the CSVs that sit next to
# this script. The page is one self-contained file (plotly.js inlined) that
# works offline. Use it to QA/QC the data:
#   1. open the .html, click a point, turn it OFF with a comment
#   2. "download reviewed sensor data" / "download reviewed grab data" -> a CSV
#      with exactly that file's layout, the turned-off points written the way
#      the file already records a missing value (NA; a sensor metric's _SD and
#      _n become NA too)
#   3. put that CSV next to this script, name it in the CONFIG block, rerun
#
# Reads only:  the sensor + grab files below + the two outlet discharge/precip files
# Writes only: IWI_stream_outlet_visualizer.html (same folder)
#
# Packages: readr, dplyr, purrr, jsonlite, plotly (plotly only for its copy
# of plotly.js, which is inlined into the page).
# =============================================================================

# ---- CONFIG -----------------------------------------------------------------
sensor_file <- "IWI_stream_outlet_sensor_data.csv"   # <- daily sensor means; drop a reviewed download in here
grab_file   <- "IWI_stream_outlet_grab_data.csv"     # <- grab samples; drop a reviewed download in here
# -----------------------------------------------------------------------------

# Normally unchanged: the outlet files, the page, and the download names.
outlet_files <- c(
  Shatto      = "IWI_shatto_outlet_discharge_precip.csv",
  Kirkpatrick = "IWI_kirkpatrick_outlet_discharge_precip.csv"
)
html_file     <- "IWI_stream_outlet_visualizer.html"
download_names <- list(
  sensor = "IWI_stream_outlet_sensor_data_reviewed.csv",
  grab   = "IWI_stream_outlet_grab_data_reviewed.csv",
  log    = "IWI_stream_outlet_review_log.csv"
)
page_title <- "Indiana Watershed Initiative (IWI): Stream Outlet Data Visualizer"

# How these files record a missing value: the NA token, and for a sensor
# metric its _SD and _n are NA too (n is never 0 here, unlike the tile drain
# file). A point turned OFF in the page is written the same way.
na_token  <- "NA"
missing_n <- "NA"

# Harmonized vocabulary (CLAUDE.md rule 6). Anything else stops the build.
key_cols      <- c("Project", "Watershed", "Sample_date")
watersheds    <- c("Shatto", "Kirkpatrick")
outlet_header <- c("date", "q_ls", "precip_cm")

# The Nutrient Grab Samples tab: one panel per entry, top to bottom, as in the original
# outlet viewer. `overlay` is drawn on the panel's left axis and `col` on a
# right axis locked to the same scale. Colour is the analyte; marker shape is
# the watershed. Every grab column must appear here exactly once.
grab_panels <- list(
  list(col = "TN_mgL",   color = "#e74c3c", overlay = "NO3N_mgL", overlay_color = "#000000"),
  list(col = "NH4N_ugL", color = "#000000"),
  list(col = "TP_ugL",   color = "#3f9e6b", overlay = "SRP_ugL",  overlay_color = "#000000")
)

# Y-axis titles, spelled out as they would be in a paper. The tabs keep the
# CSV column headers; only the axis titles and the captions use these.
# <sub>/<sup> render in both plotly and the HTML caption. The grab panels are
# short, so there the page drops "concentration" and puts the unit on a
# second line.
axis_labels <- c(
  # sensor file
  Q_Ls          = "Stream discharge (L/s)",
  SUNA_NO3N_mgL = "Nitrate concentration, SUNA sensor (mg NO<sub>3</sub><sup>\u2212</sup>-N/L)",
  LDO_mgL       = "Dissolved oxygen concentration (mg O<sub>2</sub>/L)",
  Turb_NTU      = "Turbidity (NTU)",
  Cond_uScm     = "Specific conductance (\u00b5S/cm)",
  Temp_C        = "Water temperature (\u00b0C)",
  # grab file
  NO3N_mgL      = "Nitrate concentration (mg NO<sub>3</sub><sup>\u2212</sup>-N/L)",
  NH4N_ugL      = "Ammonium concentration (\u00b5g NH<sub>4</sub><sup>+</sup>-N/L)",
  SRP_ugL       = "Soluble reactive phosphorus concentration (\u00b5g P/L)",
  TN_mgL        = "Total nitrogen concentration (mg N/L)",
  TP_ugL        = "Total phosphorus concentration (\u00b5g P/L)"
)
# What one point is, in front of each sensor tab's y-axis title:
# "<prefix>:<br><title>". A sensor row is the mean of one day's readings at
# the outlet. The grab panels keep their plain titles: each point is one sample.
axis_prefix <- "Daily mean"

# Tab order, left to right (advisor, 2026-10). Every sensor metric exactly once;
# the Nutrient Grab Samples tab always comes last. The side panel lists the
# sensor metrics in this order too. The CSV column order is not changed.
tab_order <- c("Q_Ls", "SUNA_NO3N_mgL", "Cond_uScm", "Turb_NTU", "LDO_mgL", "Temp_C")
outlet_axis_labels <- c(q_ls = "Stream discharge (L/s)", precip_cm = "Precipitation (cm)")

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(purrr)
  library(jsonlite)
})
if (!requireNamespace("plotly", quietly = TRUE)) {
  stop("The plotly package is needed for its copy of plotly.js: install.packages(\"plotly\")")
}

# =============================================================================
# Stage 1. Find this script's folder, so getwd() doesn't matter
# =============================================================================
script_dir <- function() {
  a <- grep("^--file=", commandArgs(FALSE), value = TRUE)
  if (length(a)) return(dirname(normalizePath(sub("^--file=", "", a[1]))))
  for (i in rev(seq_len(sys.nframe()))) {          # source("...")
    f <- sys.frame(i)$ofile
    if (!is.null(f)) return(dirname(normalizePath(f)))
  }
  if (requireNamespace("rstudioapi", quietly = TRUE) && rstudioapi::isAvailable()) {
    p <- rstudioapi::getSourceEditorContext()$path  # Run in Positron/RStudio
    if (nzchar(p)) return(dirname(normalizePath(p)))
  }
  stop("Can't tell where this script lives. Run it with Rscript or source() it.")
}
pkg_dir <- script_dir()

# =============================================================================
# Stage 2. Read a CSV exactly as text
# Every cell stays the string that is in the file ("0.300" stays "0.300"), so
# the page can write the file back byte for byte. The reader proves that by
# rebuilding the file from its cells and comparing bytes.
# =============================================================================
read_exact <- function(file) {
  path <- file.path(pkg_dir, file)
  if (!file.exists(path)) stop("File not found next to the script: ", file)
  bytes <- readBin(path, "raw", file.size(path))
  if (length(bytes) >= 3 && identical(bytes[1:3], as.raw(c(0xEF, 0xBB, 0xBF)))) {
    stop(file, " starts with a byte-order mark (BOM). Save it as UTF-8 without a BOM.")
  }
  txt <- rawToChar(bytes)
  Encoding(txt) <- "UTF-8"
  if (!validUTF8(txt)) stop(file, " is not valid UTF-8.")
  if (grepl('"', txt, fixed = TRUE)) {
    stop(file, " contains quote characters; this script expects an unquoted CSV.")
  }
  eol <- if (grepl("\r\n", txt, fixed = TRUE)) "\r\n" else "\n"

  cells.df <- read_csv(I(txt), col_types = cols(.default = col_character()),
                       na = character(), quote = "", trim_ws = FALSE,
                       skip_empty_rows = FALSE, progress = FALSE)
  final_eol <- endsWith(txt, eol)
  rebuilt <- paste0(
    paste(c(paste(names(cells.df), collapse = ","),
            do.call(paste, c(unname(as.list(cells.df)), sep = ","))),
          collapse = eol),
    if (final_eol) eol else "")
  if (!identical(charToRaw(enc2utf8(rebuilt)), bytes)) {
    stop(file, " does not rebuild byte for byte from its cells ",
         "(mixed line endings, blank lines, or ragged rows?).")
  }
  list(df = cells.df, eol = eol, final_eol = final_eol,
       md5 = unname(tools::md5sum(path)), bytes = bytes)
}

# =============================================================================
# Stage 3. The sensor and grab data: check the layout and the vocabulary
# A metric is any column after the keys that doesn't end in _SD or _n. If it
# has an SD and an n, they follow it as X, X_SD, X_n (the sensor means); a
# metric without them stands alone (sensor Q_Ls, every grab analyte).
# =============================================================================
is_num_text <- function(x) grepl("^-?(\\d+\\.?\\d*|\\.\\d+)([eE][-+]?\\d+)?$", x)

check_data <- function(dat, file) {
  data.df <- dat$df
  header  <- names(data.df)
  if (!identical(header[seq_along(key_cols)], key_cols)) {
    stop(file, ": the first columns must be ", paste(key_cols, collapse = ", "))
  }
  rest <- header[-seq_along(key_cols)]
  metric_cols <- rest[!grepl("_(SD|n)$", rest)]
  if (!length(metric_cols)) stop(file, ": no metric columns after the keys.")
  expected <- unlist(map(metric_cols, \(m) {
    comp <- paste0(m, c("_SD", "_n"))
    if (all(comp %in% rest)) c(m, comp) else m
  }))
  if (!identical(rest, expected)) {
    stop(file, ": after the key columns each metric must be X alone or the triple X, X_SD, X_n. Got: ",
         paste(rest, collapse = ", "))
  }

  bad_ws <- setdiff(unique(data.df$Watershed), watersheds)
  if (length(bad_ws)) stop(file, ": Watershed values must be Shatto or Kirkpatrick. Found: ", paste(bad_ws, collapse = ", "))
  bad_date <- data.df$Sample_date[is.na(as.Date(data.df$Sample_date, format = "%Y-%m-%d")) |
                                    !grepl("^\\d{4}-\\d{2}-\\d{2}$", data.df$Sample_date)]
  if (length(bad_date)) stop(file, ": Sample_date must be YYYY-MM-DD. Found: ", paste(head(bad_date), collapse = ", "))
  if (anyDuplicated(data.df[c("Watershed", "Sample_date")])) stop(file, ": Watershed x Sample_date must be unique.")

  walk(metric_cols, \(m) {
    v <- data.df[[m]]
    if (!all(v == na_token | is_num_text(v))) stop(file, " ", m, ": values must be numbers or ", na_token)
    if (paste0(m, "_SD") %in% header) {
      s <- data.df[[paste0(m, "_SD")]]; n <- data.df[[paste0(m, "_n")]]
      if (!all(s == na_token | is_num_text(s))) stop(file, " ", m, "_SD: values must be numbers or ", na_token)
      if (!all(n == missing_n | grepl("^\\d+$", n))) stop(file, " ", m, "_n: values must be whole numbers or ", missing_n)
      odd <- sum(v == na_token & (s != na_token | n != missing_n))
      if (odd) warning(file, " ", m, ": ", odd, " rows have no value but an SD or an n")
    }
  })
  metric_cols
}

sensor <- read_exact(sensor_file)
grab   <- read_exact(grab_file)
sensor_metrics <- check_data(sensor, sensor_file)
grab_metrics   <- check_data(grab, grab_file)

if (length(intersect(sensor_metrics, grab_metrics))) {
  stop("The sensor and grab files share a metric name: ",
       paste(intersect(sensor_metrics, grab_metrics), collapse = ", "))
}
panel_cols <- unlist(map(grab_panels, \(p) c(p$col, p$overlay)))
if (!setequal(panel_cols, grab_metrics) || anyDuplicated(panel_cols)) {
  stop("grab_panels must name every grab column exactly once. Grab columns: ",
       paste(grab_metrics, collapse = ", "), "; panels: ", paste(panel_cols, collapse = ", "))
}
if (!setequal(tab_order, sensor_metrics) || anyDuplicated(tab_order)) {
  stop("tab_order must name every sensor metric exactly once. Sensor metrics: ",
       paste(sensor_metrics, collapse = ", "), "; tab_order: ", paste(tab_order, collapse = ", "))
}
no_label <- setdiff(c(sensor_metrics, grab_metrics), names(axis_labels))
if (length(no_label)) stop("Add a y-axis title to `axis_labels` for: ", paste(no_label, collapse = ", "))
if (any(names(grab$df)[-seq_along(key_cols)] != grab_metrics)) {
  stop(grab_file, ": grab analytes are expected to have no _SD/_n columns.")
}

# =============================================================================
# Stage 4. The outlet discharge / precipitation files (context panel)
# Precip is already in cm in the file and is plotted as-is.
# =============================================================================
outlets <- imap(outlet_files, \(file, ws) {
  o <- read_exact(file)
  if (!identical(names(o$df), outlet_header)) {
    stop(file, ": columns must be ", paste(outlet_header, collapse = ", "))
  }
  if (anyNA(as.Date(o$df$date, format = "%Y-%m-%d"))) stop(file, ": dates must be YYYY-MM-DD")
  list(watershed = unbox(ws), file = unbox(file), header = outlet_header,
       columns = as.list(o$df))
}) |> unname()

# =============================================================================
# Stage 5. Embed: only the CSVs' own rows and columns (CLAUDE.md rule 1)
# Columns go in as the file's text; the page parses numbers for plotting and
# writes the text back out for the reviewed download.
# =============================================================================
embed_dataset <- function(id, file, dat, metrics) {
  list(id = unbox(id), file = unbox(file), md5 = unbox(dat$md5),
       eol = unbox(dat$eol), final_eol = unbox(dat$final_eol),
       metrics = metrics, header = names(dat$df), columns = as.list(dat$df))
}
page_data <- list(
  title       = unbox(page_title),
  built       = unbox(format(Sys.time(), "%Y-%m-%d %H:%M")),
  na_token    = unbox(na_token),
  missing_n   = unbox(missing_n),
  names       = map(download_names, unbox),
  datasets    = list(embed_dataset("sensor", sensor_file, sensor, sensor_metrics),
                     embed_dataset("grab", grab_file, grab, grab_metrics)),
  grab_panels = map(grab_panels, \(p) map(p, unbox)),
  labels      = map(as.list(axis_labels[c(sensor_metrics, grab_metrics)]), unbox),
  axis_prefix = unbox(axis_prefix),
  tab_order   = tab_order,
  outlet_labels = map(as.list(outlet_axis_labels), unbox),
  outlets     = outlets
)
# the structural keys above; everything else in the JSON must be a CSV header
structural_keys <- c(names(page_data), names(download_names),
                     "id", "file", "md5", "eol", "final_eol", "metrics", "header", "columns",
                     "col", "color", "overlay", "overlay_color", "watershed")

json <- toJSON(page_data, auto_unbox = FALSE, digits = NA)
json <- gsub("</", "<\\/", json, fixed = TRUE)   # never close the <script> early

# =============================================================================
# Stage 6. Fill the template and write the page
# =============================================================================
fill <- function(x, key, value) {
  i <- regexpr(key, x, fixed = TRUE)
  if (i < 0) stop("Template placeholder missing: ", key)
  paste0(substr(x, 1, i - 1), value, substr(x, i + nchar(key), nchar(x)))
}
plotly_path <- system.file("htmlwidgets/lib/plotlyjs/plotly-latest.min.js", package = "plotly")
if (!nzchar(plotly_path)) stop("plotly.js not found inside the installed plotly package.")
plotly_js <- read_file(plotly_path)

TEMPLATE <- r"---[<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>IWI Stream Outlet Data Visualizer</title>
<script>/*__PLOTLYJS__*/</script>
<style>
  /* ---- palette and base (shared by all three IWI viewers) ---- */
  :root{
    --ink:#0b0b0b; --ink2:#52514e; --muted:#898781;
    --line:#e1e0d9; --surface:#ffffff; --surface2:#faf9f6;
    --good:#1d6b3f; --off:#b1560f; --hi:#fff8dc;
  }
  *{box-sizing:border-box}
  body{margin:0;padding:0 24px 80px;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Helvetica,Arial,sans-serif;
       color:var(--ink);background:var(--surface2);font-size:19px;line-height:1.5}
  header{position:sticky;top:0;z-index:50;background:var(--surface2);border-bottom:1px solid var(--line);
         padding:12px 0 8px}
  .banner{font-size:34px;font-weight:600;line-height:1.2;color:var(--ink);margin:0;padding:18px 0 6px}
  h1{font-size:24px;font-weight:500;margin:0 0 3px}
  h2{font-size:20px;font-weight:500;margin:26px 0 10px;padding-bottom:6px;border-bottom:1px solid var(--line)}
  .sub{color:var(--ink2);font-size:18px;margin:0}
  .controls{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:9px}
  .controls label{font-size:17.5px;color:var(--ink2);display:flex;align-items:center;gap:5px}
  .controls label[hidden]{display:none!important}
  button{font:inherit;font-size:18px;padding:6px 12px;border:1px solid #c3c2b7;background:var(--surface);
         border-radius:6px;cursor:pointer;color:var(--ink)}
  button:hover{background:var(--surface2)}
  button.primary{border-color:#8a8a7e;font-weight:500}
  button:disabled{opacity:.45;cursor:default}
  select{font:inherit;font-size:18px;padding:5px 8px;border:1px solid #c3c2b7;border-radius:6px;background:var(--surface)}
  input[type=checkbox]{width:19px;height:19px;cursor:pointer}

  /* ---- metric tabs: the tab text is the CSV column header ---- */
  .tabs{display:flex;gap:4px;align-items:flex-end;margin:10px 0 0;flex-wrap:wrap}
  .tab{font:inherit;font-size:18.5px;padding:7px 15px;border:1px solid var(--line);border-bottom:none;
       background:var(--surface2);border-radius:8px 8px 0 0;cursor:pointer;color:var(--ink2)}
  .tab:hover{background:var(--surface)}
  .tab.on{background:var(--surface);color:var(--ink);font-weight:500;box-shadow:inset 0 3px 0 var(--ink)}
  .tabsep{width:14px}
  .tabsrule{border-bottom:1px solid var(--line);margin-bottom:2px}

  .wrap{max-width:1600px;margin:0 auto}
  .card{background:var(--surface);border:1px solid var(--line);border-radius:10px;margin:16px 0;overflow:hidden}
  .plotwrap{padding:10px 6px 12px}
  .plot{width:100%;height:640px}
  .hint{font-size:17px;color:var(--muted);padding:6px 14px 10px}
  .empty{padding:14px;color:var(--muted);font-size:17.5px}
  .badge{font-size:16.5px;padding:1px 8px;border-radius:20px;border:1px solid var(--line);color:var(--ink2);
         background:var(--surface2)}
  .badge.on{color:var(--good);border-color:#cfe3d6;background:#f2f8f4}
  .badge.off{color:var(--off);border-color:#f0cfb4;background:#fdf3ea}

  table{border-collapse:collapse;width:100%;font-size:17.5px;font-variant-numeric:tabular-nums}
  th{position:sticky;top:0;background:var(--surface);text-align:left;font-weight:500;color:var(--ink2);
     padding:7px 8px;border-bottom:1px solid var(--line);white-space:nowrap}
  td{padding:5px 8px;text-align:left;border-bottom:1px solid #f2f1ec;vertical-align:top}
  td.num,th.num{text-align:right;white-space:nowrap}
  .swatch{display:inline-block;width:12px;height:12px;margin-right:7px;vertical-align:middle}
  tr.hi{background:var(--hi)}
  tr.clickable{cursor:pointer}
  tr.clickable:hover{background:var(--surface2)}
  tr.hi.clickable:hover{background:var(--hi)}
  .tablewrap{max-height:420px;overflow:auto}

  /* ---- outlet discharge + precipitation panel ---- */
  .ctxwrap{padding:8px 6px 0;border-bottom:1px solid var(--line)}
  .ctxwrap[hidden]{display:none!important}
  .ctxhead{display:flex;gap:6px 14px;align-items:center;flex-wrap:wrap;font-size:17.5px;
           color:var(--ink2);padding:0 8px 2px}
  .ctxhead b{color:var(--ink);font-weight:500}
  .ctxkey{display:inline-flex;align-items:center;gap:5px;font-size:17px}
  .ctxkey i{display:inline-block;flex:none}
  .ctxplot{width:100%;height:240px}
  .card.withctx .plot{height:520px}
  /* the Nutrient Grab Samples tab stacks three panels, so it gets more height */
  .card.grab .plot{height:840px}
  .card.grab.withctx .plot{height:740px}
  .pwrap{position:relative}
  /* figure captions: a full sentence above each panel, as in a paper */
  .figcap{font-size:17.5px;color:var(--ink2);padding:10px 14px 0;max-width:1400px}
  .figcap b{color:var(--ink);font-weight:600}
  .ctxwrap .figcap{padding:0 8px 4px}
  .guide{position:absolute;width:0;border-left:1px dashed #6d6b64;pointer-events:none;display:none;z-index:5}

  /* ---- click-point side panel ---- */
  .side{position:fixed;right:0;top:0;bottom:0;width:700px;max-width:96vw;z-index:80;
        background:var(--surface);border-left:1px solid var(--line);
        box-shadow:-3px 0 18px rgba(0,0,0,.09);display:flex;flex-direction:column}
  .side[hidden]{display:none!important}
  .sidehead{padding:12px 16px;border-bottom:1px solid var(--line);display:flex;align-items:baseline;
            gap:10px;flex-wrap:wrap}
  .sidehead .t{font-size:20px;font-weight:500}
  .sidebody{overflow:auto;padding:0 0 20px}
  .sidesec{padding:10px 16px;border-bottom:1px solid var(--line);font-size:17.5px;color:var(--ink2)}
  .sidesec b{color:var(--ink);font-weight:500}
  .sidesec h3{font-size:17.5px;font-weight:600;color:var(--ink);margin:0 0 6px}
  .side table{font-size:17.5px}
  .side td{padding:4px 8px}
  .closebtn{margin-left:auto;font-size:17px;padding:4px 10px}
  .scrim{position:fixed;inset:0;background:rgba(0,0,0,.12);z-index:70}
  .scrim[hidden]{display:none!important}
  .nodata{color:var(--muted);font-style:italic}
  .was{color:var(--muted);text-decoration:line-through}

  /* ---- the ON/OFF switch and the required comment ---- */
  .toggle{display:flex;align-items:center;gap:10px;margin:4px 0 8px}
  .sw2{position:relative;display:inline-block;width:40px;height:22px;vertical-align:middle;flex:none}
  .sw2 input{opacity:0;width:0;height:0;position:absolute}
  .sw2 .sl{position:absolute;inset:0;background:#cfcdc4;border-radius:22px;transition:background .12s;cursor:pointer}
  .sw2 .sl:before{content:"";position:absolute;height:18px;width:18px;left:2px;top:2px;background:#fff;
                  border-radius:50%;transition:transform .12s;box-shadow:0 1px 2px rgba(0,0,0,.25)}
  .sw2 input:checked + .sl{background:var(--good)}
  .sw2 input:checked + .sl:before{transform:translateX(18px)}
  .sw2 input:disabled + .sl{opacity:.4;cursor:default}
  textarea.comment{width:100%;min-height:64px;font:inherit;font-size:18px;padding:6px 8px;
                   border:1px solid #c3c2b7;border-radius:6px;resize:vertical}
  .req{color:var(--off);font-size:17px}
  .row-actions{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:8px}
</style>
</head>
<body>
<div class="wrap">
<p class="banner" id="h-banner"></p>
<header>
  <p class="sub" id="h-sub"></p>
  <div class="tabs" id="tabs"></div>
  <div class="tabsrule"></div>
  <div class="controls">
    <label>watershed <select id="sel-ws"></select></label>
    <label id="wrap-err">error bars
      <select id="sel-err">
        <option value="sd">&plusmn; SD</option>
        <option value="none">none</option>
      </select>
    </label>
    <label id="wrap-ctx" title="daily discharge and precipitation at the watershed outlet, above the plot">
      <input type="checkbox" id="cb-ctx" checked> outlet Q &amp; precip
    </label>
    <label><input type="checkbox" id="cb-keepzoom"> keep zoom when switching tabs</label>
    <button id="btn-resetzoom">reset zoom</button>
    <span style="width:8px"></span>
    <button id="btn-dl-sensor" class="primary">download reviewed sensor data (.csv)</button>
    <button id="btn-dl-grab" class="primary">download reviewed grab data (.csv)</button>
    <button id="btn-dl-log">download review log (.csv)</button>
    <span style="width:8px"></span>
    <span id="savestate" style="font-size:17px;color:var(--muted)"></span>
    <button id="btn-clear-saved" style="font-size:17px;padding:4px 9px">clear saved review</button>
  </div>
  <p class="sub" id="h-metric" style="margin-top:6px"></p>
</header>

<div class="card" id="plotcard">
  <div class="ctxwrap" id="ctxwrap" hidden>
    <div class="figcap" id="ctx-cap"></div>
    <div class="ctxhead">
      <span id="ctx-keys" style="display:inline-flex;gap:6px 14px;flex-wrap:wrap"></span>
      <span style="flex:1"></span>
      <span id="ctx-src" style="color:var(--muted);font-size:17px"></span>
    </div>
    <div class="pwrap" id="ctx-area"><div class="ctxplot" id="ctx"></div><div class="guide" id="guide-ctx"></div></div>
  </div>
  <div class="figcap" id="plot-cap"></div>
  <div class="plotwrap"><div class="pwrap"><div class="plot" id="plot"></div><div class="guide" id="guide-plot"></div></div></div>
  <div class="hint" id="hint"></div>
</div>

<h2 id="off-title">Points turned off</h2>
<div class="card" id="offlist"></div>

<h2>series summary &mdash; live</h2>
<div class="card" id="summary"></div>
</div>

<div class="scrim" id="scrim" hidden></div>
<aside class="side" id="side" hidden>
  <div class="sidehead">
    <span class="t" id="side-title"></span>
    <span class="badge" id="side-badge"></span>
    <button class="closebtn" id="side-close">close</button>
  </div>
  <div class="sidebody" id="side-body"></div>
</aside>

<script>
const DATA = /*__DATA_START__*/ /*__DATA__*/ /*__DATA_END__*/;

/* ====================================================================
   IWI DATA VISUALIZER -- stream outlet

   The page carries the two EDI CSVs and nothing else: for each file,
   DS[id].cols is the file, column by column, as the TEXT that is in the
   file. Numbers are parsed from that text for plotting; the reviewed
   downloads write the text back, so with nothing turned off each one is
   byte-identical to its file.

     sensor  daily sensor means: Q_Ls, then X, X_SD, X_n per metric
     grab    grab samples: one value per analyte, no SD or n

   A POINT is one row (Watershed x Sample_date) of one file within one
   metric column. Turning a point OFF needs a comment. An OFF point is drawn
   as an x, and in the reviewed download its value -- and its _SD and _n,
   where the file has them -- become the NA token, the way the files
   already record a missing value.

   Tabs: one per sensor metric (the tab text is the column header), then
   Nutrient Grab Samples, which stacks the grab analytes in panels.

   GLOBAL across tabs: watershed filter, error-bar mode, the outlet panel,
   keep-zoom, and every OFF point with its comment. All of it is saved in
   this browser, keyed to both data files' md5s, so a different file never
   inherits an old review.
   ==================================================================== */

const NA_TOKEN = DATA.na_token, MISSING_N = DATA.missing_n;
const GRAB_TAB = "Nutrient Grab Samples";
const DS_LABEL = { sensor: "sensor daily mean", grab: "grab sample" };

/* Marker shape is the watershed everywhere. On the sensor tabs colour is the
   watershed too (the outlet colours, never the cover crop colours); on the
   Nutrient Grab Samples tab colour is the analyte. Shatto is dark navy and
   Kirkpatrick light purple, so the two differ in tone as well as hue. */
const WS_SYMBOL = { "Shatto": "circle", "Kirkpatrick": "triangle-up" };
const WS_COLOR  = { "Shatto": "#1f4e79", "Kirkpatrick": "#B386E0" };
const POINT_SIZE = 8;

const esc = s => String(s == null ? "" : s)
  .replace(/&/g,"&amp;").replace(/"/g,"&quot;")
  .replace(/</g,"&lt;").replace(/>/g,"&gt;");
const num = s => (s == null || s === "" || s === NA_TOKEN) ? null : Number(s);
const hexA = (hex, a) => {
  const n = parseInt(hex.slice(1), 16);
  return "rgba(" + (n >> 16 & 255) + "," + (n >> 8 & 255) + "," + (n & 255) + "," + a + ")";
};
const DOT = " \u00b7 ", PM = " \u00b1 ", DASH = "\u2014";
/* a sensor tab's y-axis title: what one point is, then the spelled-out metric and unit */
const yTitle = m => DATA.axis_prefix + ":<br>" + DATA.labels[m];
const byDate = (D) => (a, b) => D.rows[a].date < D.rows[b].date ? -1 : D.rows[a].date > D.rows[b].date ? 1 : 0;

/* ---------- the two data files ---------- */
const DS = {}, DS_IDS = [];
DATA.datasets.forEach(d => {
  const C = d.columns, n = C[d.header[0]].length;
  const D = {
    id: d.id, file: d.file, md5: d.md5, eol: d.eol, final_eol: d.final_eol,
    header: d.header, metrics: d.metrics, cols: C, n: n,
    rows: Array.from({ length: n }, (_, i) => ({ i, ws: C.Watershed[i], date: C.Sample_date[i] })),
    val: {}, sdv: {}, key: new Map()
  };
  D.rows.forEach(r => D.key.set(r.ws + "|" + r.date, r.i));
  d.metrics.forEach(m => {
    D.val[m] = C[m].map(num);
    D.sdv[m] = C[m + "_SD"] ? C[m + "_SD"].map(num) : null;
  });
  DS[d.id] = D; DS_IDS.push(d.id);
});
const SENSOR = DS.sensor, GRAB = DS.grab;
/* the sensor tabs in the CONFIG order (tab_order), then the grab tab */
const TABS = DATA.tab_order.concat([GRAB_TAB]);
let TAB = TABS[0];
const isGrabTab = () => TAB === GRAB_TAB;
const tabDs = () => isGrabTab() ? "grab" : "sensor";

const WS_LIST = Object.keys(WS_SYMBOL).filter(w => DS_IDS.some(id => DS[id].rows.some(r => r.ws === w)));

/* grab panels: axis names fixed once. The bottom panel owns the date axis
   "x" (so the month letters and the outlet strip follow it); the others
   match it. A panel's overlay sits on the left axis, its own analyte on a
   right axis locked to the same scale. */
let nextRightY = DATA.grab_panels.length + 1;
const GRAB_PANELS = DATA.grab_panels.map((p, idx, all) => Object.assign({}, p, {
  ySuf: idx === 0 ? "" : String(idx + 1),
  xSuf: idx === all.length - 1 ? "" : String(idx + 2),
  rSuf: p.overlay ? String(nextRightY++) : null
}));
const ANALYTE_COLOR = {};
GRAB_PANELS.forEach(p => { ANALYTE_COLOR[p.col] = p.color; if (p.overlay) ANALYTE_COLOR[p.overlay] = p.overlay_color; });
/* legend / summary order as in the original viewer: each panel's own analyte, then its overlay */
const GRAB_ORDER = GRAB_PANELS.flatMap(p => p.overlay ? [p.col, p.overlay] : [p.col]);

/* ---------- state ---------- */
let wsFilter = "all", errMode = "sd", showCtx = true, keepZoom = false;
const OFF = {};                       /* OFF[ds][metric][row] = { comment, ts } */
DS_IDS.forEach(id => { OFF[id] = {}; DS[id].metrics.forEach(m => { OFF[id][m] = {}; }); });
const isOff = (ds, m, i) => !!OFF[ds][m][i];
const hasValue = (ds, m, i) => DS[ds].cols[m][i] !== NA_TOKEN;
const offCount = () => DS_IDS.reduce((a, id) =>
  a + DS[id].metrics.reduce((b, m) => b + Object.keys(OFF[id][m]).length, 0), 0);
const passRow = r => wsFilter === "all" || r.ws === wsFilter;
const wsOnScreen = () => wsFilter === "all" ? WS_LIST : [wsFilter];

/* "value +/- SD (n = ...)", straight from the file's text; a column with no
   SD and n (Q_Ls, the grab analytes) shows its value alone */
function cellText(ds, m, i){
  const C = DS[ds].cols, v = C[m][i];
  if (v === NA_TOKEN) return '<span class="nodata">no data</span>';
  if (!C[m + "_SD"]) return esc(v);
  const sd = C[m + "_SD"][i], n = C[m + "_n"][i];
  return esc(v) + PM + (sd === NA_TOKEN ? DASH : esc(sd)) + " (n = " + esc(n) + ")";
}
/* the columns an OFF point rewrites, and what each is written as */
function offColumns(ds, m){
  const C = DS[ds].cols, cols = [m], toks = [NA_TOKEN];
  if (C[m + "_SD"]) { cols.push(m + "_SD"); toks.push(NA_TOKEN); }
  if (C[m + "_n"])  { cols.push(m + "_n");  toks.push(MISSING_N); }
  return { cols: cols, toks: toks };
}

/* ---------- outlet discharge + precipitation ---------- */
const OUTS = {};
(DATA.outlets || []).forEach(o => {
  const c = o.columns;
  OUTS[o.watershed] = {
    file: o.file, date: c.date, qs: c.q_ls, ps: c.precip_cm,
    q: c.q_ls.map(num), p: c.precip_cm.map(num),
    idx: new Map(c.date.map((d, i) => [d, i]))
  };
});
const OUT_WS  = Object.keys(OUTS);
const HAS_OUT = OUT_WS.length > 0;
/* watershed colours, shared by all IWI viewers: Shatto dark navy,
   Kirkpatrick light purple, so the two differ in tone as well as hue */
const OUT_COLORS = { Shatto: { q: "#1f4e79", p: "#7ea6cf" },
                     Kirkpatrick: { q: "#B386E0", p: "#c9aee9" } };
const outColor = w => OUT_COLORS[w] || { q: "#0f6e6e", p: "#86c4bd" };
const U_Q = "L/s", U_P = "cm";        /* from the column names q_ls, precip_cm */
/* the strip carries the precip axis on the right, so both plots reserve the
   same right margin -- that keeps their date axes on top of one another */
const PLOT_MARGIN_R = HAS_OUT ? 84 : 24;
/* and the same left margin, wide enough for a two-line y-axis title */
const PLOT_MARGIN_L = 116;

const activeOutlets = () => wsOnScreen().filter(w => OUTS[w]);

function outletLine(date, ws){
  const lab = ws + " outlet";
  const O = OUTS[ws];
  if (!O) return lab + ": no outlet record";
  const i = O.idx.get(date);
  if (i == null) return lab + ": no record for this date";
  const q = O.qs[i] === "" ? "no data" : esc(O.qs[i]) + " " + U_Q;
  const p = O.ps[i] === "" ? "no data" : esc(O.ps[i]) + " " + U_P;
  return lab + ": Q " + q + DOT + "precip " + p;
}

function updateCtxHead(){
  if (!HAS_OUT) return;
  const act = activeOutlets();
  document.getElementById("ctx-cap").innerHTML =
    "<b>Outlet discharge and precipitation.</b> Daily stream discharge (lines, left axis) " +
    "and daily precipitation (bars, hanging from the top, right axis) at the " +
    esc(act.join(" and ")) + " watershed outlet" + (act.length > 1 ? "s" : "") +
    ", on the same dates as the figure below. Zoom either plot and the other follows.";
  document.getElementById("ctx-keys").innerHTML = act.map(w => {
    const c = outColor(w), pre = act.length > 1 ? w + " " : "";
    return '<span class="ctxkey"><i style="width:16px;height:0;border-top:2px solid ' + c.q +
           '"></i>' + esc(pre) + 'Q</span>' +
           '<span class="ctxkey"><i style="width:8px;height:11px;background:' + c.p +
           '"></i>' + esc(pre) + 'precip</span>';
  }).join("");
  document.getElementById("ctx-src").textContent = act.map(w => {
    const O = OUTS[w], qd = O.date.filter((d, i) => O.q[i] != null);
    return O.file + DOT + "Q " + qd[0] + " to " + qd[qd.length - 1];
  }).join("   |   ");
  document.getElementById("ctx-area").style.display = act.length ? "" : "none";
}

/* ctxState: "none" until first drawn, "pending" while newPlot runs, then "ready" */
let ctxState = "none", ctxSyncing = false, ctxLast = "";
const ctxEl = () => document.getElementById("ctx");

function niceStep(x){
  if (!(x > 0)) return 1;
  const e = Math.pow(10, Math.floor(Math.log10(x))), f = x / e;
  return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10) * e;
}
const tidy = v => +v.toFixed(10);   /* 0.30000000000000004 -> 0.3 */

/* y-ranges that fit the window on screen, so a zoom into one season shows
   that season's flow rather than a flat line under the biggest flood */
function ctxFit(lo, hi){
  const a = String(lo).slice(0, 10), b = String(hi).slice(0, 10);
  let qmax = 0, pmax = 0;
  activeOutlets().forEach(w => {
    const O = OUTS[w];
    for (let i = 0; i < O.date.length; i++) {
      const d = O.date[i];
      if (d < a) continue;
      if (d > b) break;
      const q = O.q[i], p = O.p[i];
      if (q != null && q > qmax) qmax = q;
      if (p != null && p > pmax) pmax = p;
    }
  });
  /* one panel, two axes: Q rises from the bottom and fills the lower ~65%;
     precip hangs from the top (reversed axis) and fills at most the upper
     40%, so a storm's bars point down at its Q peak */
  const Q_SHARE = 0.65, P_SHARE = 0.40;
  /* Q: range starts at 0 and 0 is always a labelled tick */
  const qtop = qmax > 0 ? qmax / Q_SHARE : 1;
  const qstep = niceStep(qtop / 5);
  const qt = [];
  for (let k = 0; k * qstep <= qtop + 1e-9; k++) qt.push(tidy(k * qstep));
  /* precip: 0 at the top, then 4 or 5 round steps down (5-6 labelled ticks);
     the axis ends on the last tick, chosen as the tightest one that keeps
     the tallest bar within the upper ~45% of the panel */
  const need = (pmax || 0.1) / 0.45;
  const e10 = Math.pow(10, Math.floor(Math.log10(need / 5)));
  let best = null;
  [e10 / 10, e10, e10 * 10].forEach(e => [1, 2, 2.5, 5].forEach(f => [4, 5].forEach(k => {
    const s = f * e, end = k * s;
    if (end >= need && (!best || end < best.end || (end === best.end && k > best.k))) {
      best = { s: s, k: k, end: end };
    }
  })));
  const pt = [];
  for (let k = 0; k <= best.k; k++) pt.push(tidy(k * best.s));
  /* 4% of air at each end, so the 0 labels on the panel's edges aren't clipped */
  const PAD = 0.04;
  return { q: [-PAD * qtop, qtop], qt: qt,
           p: [best.end * (1 + PAD), -PAD * best.end], pt: pt };
}

function ctxTraces(){
  const act = activeOutlets();
  const bars = [], lines = [];
  act.forEach(w => {
    const O = OUTS[w], c = outColor(w), pre = act.length > 1 ? w + " " : "";
    /* dry days carry no bar; their zero is still in the hover of the Q line */
    const pd = [], pv = [];
    O.date.forEach((d, i) => {
      const v = O.p[i];
      if (v != null && v > 0) { pd.push(d); pv.push(v); }
    });
    bars.push({ type: "bar", name: pre + "precip", x: pd, y: pv, xaxis: "x", yaxis: "y",
                marker: { color: c.p, line: { width: 0 } },
                opacity: act.length > 1 ? 0.7 : 0.9, hoverinfo: "skip" });
    lines.push({ type: "scattergl", mode: "lines", name: pre + "outlet Q", x: O.date, y: O.q,
                 xaxis: "x", yaxis: "y2", connectgaps: false,
                 line: { color: c.q, width: 1.2 },
                 customdata: O.ps.map(s => s === "" ? "no data" : s),
                 hovertemplate: "%{x|%Y-%m-%d}<br>" + w + " outlet Q <b>%{y:.1f}</b> " +
                                U_Q + "<br>" + w + " precip <b>%{customdata}</b> " +
                                U_P + "<extra></extra>" });
  });
  return bars.concat(lines);
}

function ctxLayout(r, fit){
  const ax = { gridcolor: "#eeece5", zeroline: false, fixedrange: true,
               tickfont: { size: 16 } };
  return {
    margin: { l: PLOT_MARGIN_L, r: PLOT_MARGIN_R, t: 12, b: 10 },
    xaxis: { type: "date", range: r, gridcolor: "#eeece5", zeroline: false,
             showticklabels: false, ticks: "" },
    /* y  = precipitation, right-hand, reversed (bars hang from the top)
       y2 = discharge, left-hand, drawn over the bars */
    yaxis:  { ...ax, side: "right", range: fit.p, tickmode: "array",
              tickvals: fit.pt, showgrid: false,
              title: { text: DATA.outlet_labels.precip_cm, font: { size: 17 } } },
    yaxis2: { ...ax, side: "left", overlaying: "y", range: fit.q,
              tickmode: "array", tickvals: fit.qt,
              title: { text: DATA.outlet_labels.q_ls, font: { size: 17 } } },
    bargap: 0.1,
    barmode: "overlay",
    hovermode: "x",
    showlegend: false,
    paper_bgcolor: "#fff", plot_bgcolor: "#fff",
    font: { family: "-apple-system,Segoe UI,Helvetica,Arial,sans-serif", size: 17 },
    hoverlabel: { font: { size: 17 } }
  };
}

/* Bring the panel to the metric plot's date window. The metric plot always
   decides: a zoom on the panel is passed to the metric plot, whose own
   relayout then calls this. */
let ctxSet = "";
function syncCtx(){
  if (!HAS_OUT || !showCtx) return;
  const act = activeOutlets();
  if (!act.length) return;
  const gd = document.getElementById("plot");
  const fl = gd._fullLayout;
  if (!fl || !fl.xaxis || !gd.data || !gd.data.length) return;
  if (ctxState === "pending") return;
  const r = fl.xaxis.range.slice();
  const key = r.join("|") + "|" + act.join(",");
  if (ctxState === "ready" && key === ctxLast) return;
  ctxLast = key;
  const setChanged = act.join(",") !== ctxSet;
  ctxSet = act.join(",");
  const fit = ctxFit(r[0], r[1]);
  ctxSyncing = true;
  const done = () => { ctxSyncing = false; };
  if (ctxState === "none") {
    ctxState = "pending";
    Plotly.newPlot(ctxEl(), ctxTraces(), ctxLayout(r, fit),
                   { displaylogo: false, responsive: true, displayModeBar: false })
      .then(() => { ctxState = "ready"; bindCtx(); done(); syncCtx(); },
            () => { ctxState = "none"; done(); });
  } else if (setChanged) {
    Plotly.react(ctxEl(), ctxTraces(), ctxLayout(r, fit),
                 { displaylogo: false, responsive: true, displayModeBar: false })
      .then(() => { Plotly.Plots.resize(ctxEl()); done(); }, done);
  } else {
    Plotly.relayout(ctxEl(), { "xaxis.range": r, "yaxis.range": fit.p,
                               "yaxis.tickvals": fit.pt,
                               "yaxis2.range": fit.q,
                               "yaxis2.tickvals": fit.qt }).then(done, done);
  }
}

function bindCtx(){
  const el = ctxEl();
  el.on("plotly_relayout", ev => {
    if (ctxSyncing) return;
    const gd = document.getElementById("plot");
    if (ev["xaxis.autorange"]) { resetZoom(); return; }
    const a = ev["xaxis.range[0]"] != null ? ev["xaxis.range[0]"] : (ev["xaxis.range"] || [])[0];
    const b = ev["xaxis.range[1]"] != null ? ev["xaxis.range[1]"] : (ev["xaxis.range"] || [])[1];
    if (a == null || b == null) return;
    ctxLast = "";
    Plotly.relayout(gd, { "xaxis.range": [a, b] });
  });
  el.on("plotly_hover", ev => {
    const p = ev.points && ev.points[0];
    if (p) showGuide("plot", p.x);
  });
  el.on("plotly_unhover", () => hideGuide("plot"));
}

/* a dashed line on one plot at the date being hovered on the other */
function showGuide(target, x){
  if (!HAS_OUT || !showCtx) return;
  const gd = document.getElementById(target);
  const g  = document.getElementById("guide-" + target);
  const fl = gd && gd._fullLayout;
  if (!g || !fl || !fl.xaxis || !fl._size) return;
  const xa = fl.xaxis;
  const px = xa._offset + xa.l2p(xa.d2l(x));
  if (!isFinite(px) || px < xa._offset || px > xa._offset + xa._length) {
    g.style.display = "none"; return;
  }
  g.style.left = px + "px";
  g.style.top = fl._size.t + "px";
  g.style.height = fl._size.h + "px";
  g.style.display = "block";
}
function hideGuide(target){
  const g = document.getElementById("guide-" + target);
  if (g) g.style.display = "none";
}

function applyCtx(){
  const on = HAS_OUT && showCtx;
  document.getElementById("ctxwrap").hidden = !on;
  updateCtxHead();
  document.getElementById("plotcard").classList.toggle("withctx", on);
  hideGuide("ctx"); hideGuide("plot");
  const gd = document.getElementById("plot");
  if (gd._fullLayout) Plotly.Plots.resize(gd);
  if (on) {
    if (ctxState === "ready") Plotly.Plots.resize(ctxEl());
    ctxLast = "";
    syncCtx();
  }
}

/* ---------- plotted points: markers only, no connecting lines ---------- */
function hoverFor(ds, m, i){
  const r = DS[ds].rows[i], L = [];
  L.push("<b>" + esc(r.ws) + "</b>" + DOT + DS_LABEL[ds] + "  " + r.date);
  L.push(esc(m) + ": <b>" + cellText(ds, m, i) + "</b>");
  if (isOff(ds, m, i)) L.push("<b>turned off</b>: " + esc(OFF[ds][m][i].comment));
  if (HAS_OUT) L.push(outletLine(r.date, r.ws));
  L.push("<i>click to review this point</i>");
  return L.join("<br>") + "<extra></extra>";
}

/* the ON trace and (if any) the OFF trace for one metric of one watershed.
   meta carries "file|metric" so a click knows which point it was. */
function pointTraces(ds, m, ws, look){
  const D = DS[ds];
  const idx = D.rows.filter(r => r.ws === ws && D.val[m][r.i] != null).map(r => r.i).sort(byDate(D));
  if (!idx.length) return [];         /* e.g. Kirkpatrick has no TN or TP: no empty legend entry */
  const on = idx.filter(i => !isOff(ds, m, i)), off = idx.filter(i => isOff(ds, m, i));
  const base = { type: "scatter", mode: "markers", legendgroup: look.group, meta: ds + "|" + m,
                 xaxis: look.xaxis || "x", yaxis: look.yaxis || "y", hoverlabel: { align: "left" } };
  const t = Object.assign({}, base, {
    name: look.name,
    x: on.map(i => D.rows[i].date), y: on.map(i => D.val[m][i]), customdata: on,
    marker: { size: POINT_SIZE, symbol: WS_SYMBOL[ws], color: look.color, line: { width: 0 } },
    opacity: .92,
    hovertemplate: on.map(i => hoverFor(ds, m, i))
  });
  if (look.legendrank != null) t.legendrank = look.legendrank;
  if (look.errorBars && D.sdv[m]) {
    t.error_y = { type: "data", array: on.map(i => D.sdv[m][i] == null ? 0 : D.sdv[m][i]),
                  color: hexA(look.color, .45), thickness: 1, width: 2 };
  }
  const out = [t];
  /* OFF points: an x at the value the point carries in the file, so the
     decision stays visible; no error bar */
  if (off.length) {
    out.push(Object.assign({}, base, {
      name: look.name + " (turned off)", showlegend: false,
      x: off.map(i => D.rows[i].date), y: off.map(i => D.val[m][i]), customdata: off,
      marker: { size: 11, symbol: "x-thin-open", color: look.color, line: { width: 2, color: look.color } },
      opacity: .85,
      hovertemplate: off.map(i => hoverFor(ds, m, i))
    }));
  }
  return out;
}

/* sensor tab: one series per watershed */
function sensorTraces(){
  return wsOnScreen().flatMap(w => pointTraces("sensor", TAB, w, {
    name: w, group: w, color: WS_COLOR[w], errorBars: errMode === "sd"
  }));
}

/* Nutrient Grab Samples tab: every analyte x watershed on screen, drawn into its
   panel; overlays first so the panel's own analyte sits on top */
function grabTraces(){
  const out = [], wsS = wsOnScreen();
  GRAB_PANELS.forEach((p, pi) => {
    const members = p.overlay ? [[p.overlay, "y" + p.ySuf], [p.col, "y" + p.rSuf]]
                              : [[p.col, "y" + p.ySuf]];
    members.forEach(([m, yaxis]) => wsS.forEach(w => {
      out.push(...pointTraces("grab", m, w, {
        name: m + (wsS.length > 1 ? " " + w : ""), group: m + "|" + w,
        color: ANALYTE_COLOR[m], xaxis: "x" + p.xSuf, yaxis: yaxis,
        legendrank: 100 * (GRAB_ORDER.indexOf(m) + 1) + WS_LIST.indexOf(w)
      }));
    }));
  });
  return out;
}

/* ---------- the date axis (shared by all three IWI viewers; copy verbatim) ----------
   Months are named by their first three letters, and January also carries
   the year ("Jan 2019"). Each tick sits mid-month, centred over the month it
   names. Zoomed out, only Jan and Jun are labelled; zoom in until every label
   has room and each month gets one (advisor, 2026-10). "Room" is measured in
   pixels along the axis, so a narrow window drops to Jan + Jun sooner than a
   wide one. If even Jan + Jun would overlap (a very narrow window), only Jan
   is drawn. The labels are set at TICK_ANGLE degrees; angled labels sit closer
   together without colliding, so they need less room per tick. */
const MONTH_ABBR = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
const TICK_ANGLE = -45;
const TICK_ROOM_PX = TICK_ANGLE ? 22 : 44;     /* room one label needs along the axis */
const X_MARGIN_B = TICK_ANGLE ? 80 : 64;       /* the plot's bottom margin, sized for the labels */
const X_TICK_FONT = TICK_ANGLE ? 14 : 16;     /* angled labels a little smaller, so Jan + Jun fit on a long record */
function monthTicks(a, b, px){
  const from = new Date(a), to = new Date(b);
  if (isNaN(+from) || isNaN(+to) || to <= from) return null;
  const span = (to.getUTCFullYear() - from.getUTCFullYear()) * 12 +
               (to.getUTCMonth() - from.getUTCMonth()) + 1;
  const perMonth = (px > 0 ? px : 1000) / span;  /* 1000 px when the plot isn't laid out yet */
  const show = perMonth >= TICK_ROOM_PX     ? () => true
             : perMonth * 5 >= TICK_ROOM_PX ? m => m === 0 || m === 5   /* Jan to Jun is the tighter gap */
             :                                m => m === 0;
  const vals = [], text = [];
  let y = from.getUTCFullYear(), m = from.getUTCMonth();
  for (let i = 0; i < span; i++) {
    if (show(m)) {
      vals.push(new Date(Date.UTC(y, m, 15)).toISOString().slice(0, 10));
      text.push(m === 0 ? MONTH_ABBR[m] + (TICK_ANGLE ? " " : "<br>") + "<b>" + y + "</b>" : MONTH_ABBR[m]);
    }
    if (++m > 11) { m = 0; y++; }
  }
  return { tickmode: "array", tickvals: vals, ticktext: text, tickangle: TICK_ANGLE };
}
/* The width of a plot's date axis in pixels: plotly's own figure once the
   plot is drawn, else the div's width less the margins. */
function axisPx(id){
  const gd = document.getElementById(id);
  if (!gd) return 0;
  const fl = gd._fullLayout;
  if (fl && fl.xaxis && fl.xaxis._length > 0) return fl.xaxis._length;
  return gd.clientWidth - PLOT_MARGIN_L - PLOT_MARGIN_R;
}
/* The dates of the points on screen: the sensor metric on its tab, every
   grab analyte on the Nutrient Grab Samples tab. */
function datesOnScreen(){
  if (isGrabTab()) {
    return GRAB.rows.filter(x => passRow(x) && GRAB.metrics.some(m => GRAB.val[m][x.i] != null))
                    .map(x => x.date).sort();
  }
  return SENSOR.rows.filter(x => passRow(x) && SENSOR.val[TAB][x.i] != null).map(x => x.date).sort();
}
/* The window the axis is showing: the zoom if there is one, the data on
   screen otherwise. */
function plotDateRange(){
  const gd = document.getElementById("plot");
  const r = gd && gd.layout && gd.layout.xaxis && gd.layout.xaxis.range;
  if (r && r.length === 2 && !(gd.layout.xaxis.autorange)) return r;
  const ds = datesOnScreen();
  return ds.length ? [ds[0], ds[ds.length - 1]] : null;
}
function dateAxis(){
  const base = { title: "", type: "date", gridcolor: "#eeece5", zeroline: false,
                 tickfont: { size: X_TICK_FONT } };
  const r = plotDateRange();
  const t = r ? monthTicks(r[0], r[1], axisPx("plot")) : null;
  return t ? { ...base, ...t } : base;
}
/* Re-letter the axis after a zoom or a pan. Guarded: relayout fires its own
   event, and without the flag this would call itself forever. */
let tickBusy = false;
function refreshMonthTicks(){
  if (tickBusy) return;
  const gd = document.getElementById("plot");
  if (!gd || !gd.layout) return;
  const r = plotDateRange();
  const t = r ? monthTicks(r[0], r[1], axisPx("plot")) : null;
  if (!t) return;
  const cur = gd.layout.xaxis.ticktext || [];
  if (cur.length === t.ticktext.length && cur[0] === t.ticktext[0] &&
      cur[cur.length - 1] === t.ticktext[t.ticktext.length - 1]) return;
  tickBusy = true;
  Plotly.relayout(gd, { "xaxis.tickmode": "array", "xaxis.tickvals": t.tickvals,
                        "xaxis.ticktext": t.ticktext })
        .then(() => { tickBusy = false; }, () => { tickBusy = false; });
}

const baseLayout = () => ({
  hovermode: "closest",
  showlegend: true,
  legend: { orientation: "h", y: 1.08, x: 0, font: { size: 17 } },
  paper_bgcolor: "#fff", plot_bgcolor: "#fff",
  font: { family: "-apple-system,Segoe UI,Helvetica,Arial,sans-serif", size: 17 },
  hoverlabel: { font: { size: 17 } }
});

function sensorLayout(){
  return Object.assign(baseLayout(), {
    margin: { l: PLOT_MARGIN_L, r: PLOT_MARGIN_R, t: 16, b: X_MARGIN_B },
    xaxis: dateAxis(),
    yaxis: { title: { text: yTitle(TAB), font: { size: 17.5 } }, type: "linear",
             gridcolor: "#eeece5", zeroline: false },
    uirevision: keepZoom ? "sticky" : (TAB + "|" + wsFilter)
  });
}

/* stacked panels sharing one date axis, as in the original outlet viewer.
   A right axis only shows when its analyte has points on screen, so with
   Kirkpatrick alone (no TN or TP) the panels read NO3 / NH4 / SRP. */
/* A grab panel is about a third of the plot tall, too short for a full
   title on one line: drop "concentration" (the caption says every grab value
   is one) and put the unit on a second line. */
const panelTitle = m => DATA.labels[m].replace(" concentration", "").replace(" (", "<br>(");
/* the name alone, for the caption: "Total nitrogen" */
const shortName = m => DATA.labels[m].split(" (")[0].replace(/ concentration$/, "");

function grabLayout(){
  const n = GRAB_PANELS.length, gap = 0.06, each = (1 - gap * (n - 1)) / n;
  const L = Object.assign(baseLayout(), {
    margin: { l: PLOT_MARGIN_L, r: PLOT_MARGIN_R, t: 16, b: X_MARGIN_B },
    legend: { orientation: "h", y: 1.02, yanchor: "bottom", x: 0, font: { size: 17 } },
    uirevision: keepZoom ? "sticky" : ("grab|" + wsFilter)
  });
  const shows = m => GRAB.rows.some(r => passRow(r) && GRAB.val[m][r.i] != null);
  GRAB_PANELS.forEach((p, idx) => {
    const top = 1 - idx * (each + gap), bottom = Math.max(0, top - each);
    L["yaxis" + p.ySuf] = {
      title: { text: panelTitle(p.overlay || p.col), font: { size: 16 } },
      domain: [bottom, top], anchor: "x" + p.xSuf, gridcolor: "#eeece5", zeroline: false,
      tickfont: { size: 16 }
    };
    if (p.overlay) {
      L["yaxis" + p.rSuf] = {
        title: { text: panelTitle(p.col), font: { size: 16 } },
        overlaying: "y" + p.ySuf, matches: "y" + p.ySuf, side: "right", anchor: "x" + p.xSuf,
        showgrid: false, zeroline: false, tickfont: { size: 16 }, visible: shows(p.col)
      };
    }
    L["xaxis" + p.xSuf] = idx === n - 1
      ? Object.assign(dateAxis(), { anchor: "y" + p.ySuf })
      : { type: "date", matches: "x", anchor: "y" + p.ySuf, showticklabels: false, ticks: "",
          gridcolor: "#eeece5", zeroline: false };
  });
  return L;
}

/* Sensor and grab plots have different axes; going from one to the other
   starts from a clean div (Plotly.react across that change can lock the
   page up). keep-zoom carries the date window across. */
let drawnKind = null;
function drawPlot(){
  const gd = document.getElementById("plot");
  const kind = tabDs();
  let carry = null;
  if (drawnKind && drawnKind !== kind && gd._fullLayout) {
    const xa = gd.layout.xaxis;
    if (keepZoom && xa && xa.range && !xa.autorange) carry = xa.range.slice();
    Plotly.purge(gd);
    gd._bound = false;
    ctxLast = "";
  }
  drawnKind = kind;
  document.getElementById("plotcard").classList.toggle("grab", kind === "grab");
  const traces = kind === "grab" ? grabTraces() : sensorTraces();
  const lay = kind === "grab" ? grabLayout() : sensorLayout();
  if (carry) {
    lay.xaxis.range = carry; lay.xaxis.autorange = false;
    Object.assign(lay.xaxis, monthTicks(carry[0], carry[1], axisPx("plot")) || {});
  }
  const drawn = Plotly.react(gd, traces, lay,
               { displaylogo: false, responsive: true,
                 modeBarButtonsToRemove: ["select2d", "lasso2d", "autoScale2d"] })
    .then(() => { syncCtx(); refreshMonthTicks(); renderSummary(); });
  if (!gd._bound) {
    gd.on("plotly_click", ev => {
      const p = ev.points && ev.points[0];
      if (!p || p.customdata == null || !p.data || !p.data.meta) return;
      const k = String(p.data.meta).split("|");
      openPanel(k[0], p.customdata, k[1]);
    });
    /* zoom, pan, reset and resize all land here; the outlet panel follows and
       the month letters are re-cut for the new window */
    gd.on("plotly_relayout", () => { syncCtx(); refreshMonthTicks(); });
    gd.on("plotly_hover", ev => {
      const p = ev.points && ev.points[0];
      if (p) showGuide("ctx", p.x);
    });
    gd.on("plotly_unhover", () => hideGuide("ctx"));
    /* a legend click hides or shows a series: the summary's "shown" follows */
    gd.on("plotly_restyle", () => renderSummary());
    gd._bound = true;
  }
  return drawn;
}

function resetZoom(){
  const gd = document.getElementById("plot");
  const fl = gd._fullLayout || {};
  const upd = {};
  Object.keys(fl).filter(k => /^[xy]axis\d*$/.test(k)).forEach(k => { upd[k + ".autorange"] = true; });
  Plotly.relayout(gd, upd);
}

/* ---------- click-point side panel ---------- */
let PANEL = null;        /* { ds, i, m } while open */
let pending = false;     /* switch flipped to OFF, waiting for the comment */

function openPanel(ds, i, m){
  PANEL = { ds: ds, i: i, m: m };
  pending = false;
  document.getElementById("side").hidden = false;
  document.getElementById("scrim").hidden = false;
  renderPanel();
}
function closePanel(){
  PANEL = null; pending = false;
  document.getElementById("side").hidden = true;
  document.getElementById("scrim").hidden = true;
}

/* the tab that shows a file's metric */
const tabFor = (ds, m) => ds === "grab" ? GRAB_TAB : m;

function metricRows(ds, i, hi, attr){
  /* sensor metrics in tab order; the grab analytes in file order */
  return (ds === "sensor" ? DATA.tab_order : DS[ds].metrics).map(k => {
    const off = isOff(ds, k, i);
    const val = off ? '<span class="was">' + cellText(ds, k, i) + '</span>' : cellText(ds, k, i);
    return '<tr class="clickable' + (k === hi ? " hi" : "") + '" ' + attr(k) + '>' +
           '<td>' + (k === hi ? "<b>" + esc(k) + "</b>" : esc(k)) + '</td>' +
           '<td class="num">' + val + '</td>' +
           '<td>' + (off ? '<span class="badge off">OFF</span>' : "") + '</td></tr>';
  }).join("");
}

function renderPanel(){
  if (!PANEL) return;
  const ds = PANEL.ds, D = DS[ds], i = PANEL.i, m = PANEL.m, r = D.rows[i];
  document.getElementById("side-title").textContent = r.ws + DOT + r.date + DOT + DS_LABEL[ds];
  const badge = document.getElementById("side-badge");
  const state = !hasValue(ds, m, i) ? "no data" : isOff(ds, m, i) ? "OFF" : "ON";
  badge.textContent = m + ": " + state;
  badge.className = "badge" + (state === "OFF" ? " off" : state === "ON" ? " on" : "");

  let h = '<div class="sidesec"><h3>' + (ds === "grab" ? "Every analyte in this grab sample" : "Every sensor metric on this day") +
          '</h3><table><tbody>' +
          metricRows(ds, i, m, k => 'data-m="' + esc(k) + '"') +
          '</tbody></table>' +
          '<div style="margin-top:6px;color:var(--muted)">From ' + esc(D.file) +
          '. Click a ' + (ds === "grab" ? "n analyte" : " metric") + ' to review it for this row.</div></div>';

  if (HAS_OUT) {
    h += '<div class="sidesec"><h3>Outlet on this day</h3>' + outletLine(r.date, r.ws) + '</div>';
  }

  /* the other file on the same day and watershed, read-only; a click opens it */
  const other = ds === "sensor" ? "grab" : "sensor", O = DS[other];
  const j = O.key.get(r.ws + "|" + r.date);
  h += '<div class="sidesec"><h3>' + (other === "grab" ? "Grab sample on this day" : "Sensor daily means on this day") + '</h3>';
  if (j == null) {
    h += '<div class="nodata">' + (other === "grab" ? "No grab sample" : "No sensor record") +
         ' for ' + esc(r.ws) + ' on ' + r.date + '.</div>';
  } else {
    h += '<table><tbody>' + metricRows(other, j, null, k => 'data-x="' + other + '" data-xm="' + esc(k) + '" data-xi="' + j + '"') +
         '</tbody></table><div style="margin-top:6px;color:var(--muted)">From ' + esc(O.file) +
         '. Click a row to open that point.</div>';
  }
  h += '</div>';

  h += '<div class="sidesec"><h3>Review ' + esc(m) + ' for this row</h3>';
  if (!hasValue(ds, m, i)) {
    h += '<div>' + esc(m) + ' has no data in this row, so there is nothing to turn off.</div>';
  } else if (isOff(ds, m, i)) {
    const o = OFF[ds][m][i], oc = offColumns(ds, m);
    h += '<div class="toggle"><label class="sw2"><input type="checkbox" id="pt-switch">' +
         '<span class="sl"></span></label><b>OFF</b></div>' +
         '<div>Drawn as an x. In the reviewed download this row\u2019s ' + oc.cols.map(esc).join(", ") +
         (oc.cols.length > 1 ? ' are' : ' is') + ' written ' + oc.toks.map(esc).join(", ") + '.</div>' +
         '<div style="margin-top:6px"><b>Why:</b> ' + esc(o.comment) + '</div>' +
         '<div style="color:var(--muted)">turned off ' + esc(o.ts) + '</div>' +
         '<div style="margin-top:6px;color:var(--muted)">Flip the switch to turn it back on.</div>';
    const others = D.metrics.filter(k => k !== m && isOff(ds, k, i));
    if (others.length) {
      h += '<div class="row-actions"><button id="pt-all-on">turn every metric in this row back on (' +
           (others.length + 1) + ')</button></div>';
    }
  } else if (!pending) {
    h += '<div class="toggle"><label class="sw2"><input type="checkbox" id="pt-switch" checked>' +
         '<span class="sl"></span></label><b>ON</b></div>' +
         '<div style="color:var(--muted)">Flip the switch to turn this point off. You will be asked why.</div>';
  } else {
    const nOther = D.metrics.filter(k => k !== m && hasValue(ds, k, i) && !isOff(ds, k, i)).length;
    h += '<div class="toggle"><label class="sw2"><input type="checkbox" id="pt-switch" disabled>' +
         '<span class="sl"></span></label><b>turning OFF</b></div>' +
         '<label for="pt-comment"><b>Why is this point being turned off?</b> ' +
         '<span class="req">required</span></label>' +
         '<textarea class="comment" id="pt-comment" placeholder="e.g. sensor fouled; checked field notebook"></textarea>' +
         (nOther ? '<label style="display:flex;gap:6px;align-items:center;margin-top:6px">' +
                   '<input type="checkbox" id="pt-allm"> also turn off every other ' +
                   (ds === "grab" ? "analyte in this grab sample" : "metric in this row") + ' (' +
                   nOther + ') with the same comment</label>' : '') +
         '<div class="row-actions"><button class="primary" id="pt-save" disabled>turn off</button>' +
         '<button id="pt-cancel">cancel</button></div>';
  }
  h += '</div>';
  document.getElementById("side-body").innerHTML = h;

  document.querySelectorAll("#side-body tr[data-m]").forEach(tr => {
    tr.onclick = () => {
      const k = tr.dataset.m, t = tabFor(ds, k);
      PANEL.m = k; pending = false;
      if (t !== TAB) switchTo(t); else renderPanel();
    };
  });
  document.querySelectorAll("#side-body tr[data-x]").forEach(tr => {
    tr.onclick = () => {
      const x = tr.dataset.x, k = tr.dataset.xm, xi = Number(tr.dataset.xi);
      const t = tabFor(x, k);
      if (t !== TAB) switchTo(t);
      openPanel(x, xi, k);
    };
  });
  const sw = document.getElementById("pt-switch");
  if (sw && !sw.disabled) {
    sw.onchange = () => {
      if (isOff(ds, m, i)) { turnOn(ds, m, i); }
      else { pending = true; renderPanel(); const c = document.getElementById("pt-comment"); if (c) c.focus(); }
    };
  }
  const allOn = document.getElementById("pt-all-on");
  if (allOn) allOn.onclick = () => { D.metrics.forEach(k => { delete OFF[ds][k][i]; }); refresh(); };
  const cm = document.getElementById("pt-comment");
  if (cm) {
    const save = document.getElementById("pt-save");
    cm.oninput = () => { save.disabled = !cm.value.trim(); };
    save.onclick = () => {
      const all = document.getElementById("pt-allm");
      if (turnOff(ds, m, i, cm.value, !!(all && all.checked))) { pending = false; refresh(); }
    };
    document.getElementById("pt-cancel").onclick = () => { pending = false; renderPanel(); };
  }
}

/* The only two functions that change the review. A comment is required to
   turn a point off; turnOff refuses without one. */
function turnOff(ds, m, i, comment, allMetrics){
  comment = String(comment || "").trim();
  if (!comment) return false;
  if (!DS[ds] || !OFF[ds][m] || !hasValue(ds, m, i)) return false;
  const ts = new Date().toISOString().replace(/\.\d{3}Z$/, "Z");
  const which = allMetrics ? DS[ds].metrics.filter(k => hasValue(ds, k, i) && !isOff(ds, k, i)) : [m];
  which.forEach(k => { OFF[ds][k][i] = { comment: comment, ts: ts }; });
  saveState();
  return true;
}
function turnOn(ds, m, i){
  delete OFF[ds][m][i];
  refresh();
}

/* ---------- the list of points turned off ---------- */
function offEntries(){
  const out = [];
  DS_IDS.forEach(ds => DS[ds].metrics.forEach(m => Object.keys(OFF[ds][m]).map(Number).sort((a, b) => a - b)
    .forEach(i => out.push({ ds: ds, m: m, i: i, o: OFF[ds][m][i] }))));
  return out;
}
function renderOffList(){
  const e = offEntries();
  document.getElementById("off-title").textContent = "Points turned off (" + e.length + ")";
  const el = document.getElementById("offlist");
  if (!e.length) {
    el.innerHTML = '<div class="empty">None yet. Click a point on the plot to review it.</div>';
    return;
  }
  el.innerHTML = '<div class="tablewrap"><table><thead><tr><th>File</th><th>Column</th><th>Watershed</th>' +
    '<th>Date</th><th>Value in file</th><th>Comment</th><th>Turned off</th></tr></thead><tbody>' +
    e.map(x => {
      const r = DS[x.ds].rows[x.i];
      return '<tr class="clickable" data-ds="' + x.ds + '" data-m="' + esc(x.m) + '" data-i="' + x.i + '" title="reopen this point">' +
             '<td>' + esc(DS[x.ds].file) + '</td><td>' + esc(x.m) + '</td><td>' + esc(r.ws) + '</td>' +
             '<td>' + r.date + '</td><td class="num">' + cellText(x.ds, x.m, x.i) + '</td>' +
             '<td>' + esc(x.o.comment) + '</td><td style="white-space:nowrap">' + esc(x.o.ts) + '</td></tr>';
    }).join("") + '</tbody></table></div>' +
    '<div class="hint">Click a row to reopen it and switch it back on.</div>';
  el.querySelectorAll("tr[data-i]").forEach(tr => {
    tr.onclick = () => {
      const ds = tr.dataset.ds, m = tr.dataset.m, i = Number(tr.dataset.i);
      const t = tabFor(ds, m);
      if (t !== TAB) switchTo(t);
      openPanel(ds, i, m);
    };
  });
}

/* ---------- series summary, live ----------
   One row per series for the tab on screen -- a watershed on a sensor tab,
   an analyte x watershed on the Nutrient Grab Samples tab -- computed from the values
   in the file, leaving out points turned off, so it moves as the review
   goes. "shown" follows the watershed filter and the legend. */

/* Significant figures rather than fixed decimals: these metrics span
   temperatures below 1 and conductivity in the hundreds in the same page. */
function fmt(v){
  if (v == null || !isFinite(v)) return DASH;
  const a = Math.abs(v);
  if (a === 0) return "0";
  if (a >= 1000) return v.toFixed(0);
  if (a >= 10)   return v.toFixed(1);
  if (a >= 1)    return v.toFixed(2);
  return v.toPrecision(3);
}
function median(a){
  if (!a.length) return null;
  const b = a.slice().sort((x, y) => x - y), h = b.length >> 1;
  return b.length % 2 ? b[h] : (b[h - 1] + b[h]) / 2;
}
function renderSummary(){
  const gd = document.getElementById("plot");
  const legendOff = new Set((gd._fullData || [])
    .filter(t => t.visible === "legendonly").map(t => t.legendgroup));
  const ds = tabDs(), D = DS[ds];
  const series = ds === "grab"
    ? GRAB_ORDER.flatMap(m => WS_LIST.map(w => ({ m: m, ws: w, id: m + "|" + w, label: m + " " + w, color: ANALYTE_COLOR[m] })))
    : WS_LIST.map(w => ({ m: TAB, ws: w, id: w, label: w, color: WS_COLOR[w] }));
  let h = '<div class="tablewrap"><table><thead><tr><th>series</th><th>shown</th>' +
          '<th class="num">points</th><th class="num">median</th><th class="num">mean</th>' +
          '<th class="num">min</th><th class="num">max</th><th class="num">turned off</th>' +
          '</tr></thead><tbody>';
  series.forEach(s => {
    const idx = D.rows.filter(r => r.ws === s.ws && D.val[s.m][r.i] != null).map(r => r.i);
    if (!idx.length) return;
    const v = idx.filter(i => !isOff(ds, s.m, i)).map(i => D.val[s.m][i]);
    const off = idx.length - v.length;
    const mean = v.length ? v.reduce((a, b) => a + b, 0) / v.length : null;
    const shown = (wsFilter === "all" || wsFilter === s.ws) && !legendOff.has(s.id);
    const shape = WS_SYMBOL[s.ws] === "triangle-up" ? "clip-path:polygon(50% 0,100% 100%,0 100%)" : "border-radius:50%";
    h += '<tr' + (shown ? '' : ' style="color:var(--muted)"') + '>' +
         '<td><span class="swatch" style="background:' + s.color + ';' + shape + '"></span>' +
         esc(s.label) + '</td>' +
         '<td>' + (shown ? "yes" : "no") + '</td>' +
         '<td class="num">' + v.length + '</td>' +
         '<td class="num">' + fmt(median(v)) + '</td>' +
         '<td class="num">' + fmt(mean) + '</td>' +
         '<td class="num">' + fmt(v.length ? Math.min(...v) : null) + '</td>' +
         '<td class="num">' + fmt(v.length ? Math.max(...v) : null) + '</td>' +
         '<td class="num">' + (off || "") + '</td></tr>';
  });
  document.getElementById("summary").innerHTML = h + '</tbody></table></div>' +
    '<div class="hint">' + esc(isGrabTab() ? GRAB_TAB : TAB) + ': statistics of the values in ' + esc(D.file) +
    ' for each series, leaving out points turned off. ' +
    (ds === "grab" ? '"points" counts grab samples.' : '"points" counts days (each a daily mean).') + '</div>';
}

/* ---------- tabs, filters, refresh ---------- */
function renderTabs(){
  /* a sensor tab's text is the CSV column header, character for character;
     Nutrient Grab Samples holds every grab column, each labelled by its header */
  document.getElementById("tabs").innerHTML = TABS.map(t =>
    (t === GRAB_TAB ? '<span class="tabsep"></span>' : '') +
    '<button class="tab' + (t === TAB ? " on" : "") + '" data-k="' + esc(t) + '">' + esc(t) + '</button>'
  ).join("");
  document.querySelectorAll(".tab").forEach(t => { t.onclick = () => switchTo(t.dataset.k); });
}

function metricSubtitle(){
  if (isGrabTab()) {
    const rows = GRAB.rows.filter(r => passRow(r));
    const ds = rows.map(r => r.date).sort();
    const off = offEntries().filter(x => x.ds === "grab" && passRow(GRAB.rows[x.i])).length;
    if (!rows.length) return GRAB_TAB + ": no data for this selection";
    return GRAB_TAB + DOT + rows.length + " samples" + DOT + ds[0] + " to " + ds[ds.length - 1] +
           DOT + GRAB.metrics.join(", ") + DOT + "from " + GRAB.file + (off ? DOT + off + " turned off" : "");
  }
  const idx = SENSOR.rows.filter(r => passRow(r) && SENSOR.val[TAB][r.i] != null);
  const ds = idx.map(r => r.date).sort();
  const off = idx.filter(r => isOff("sensor", TAB, r.i)).length;
  if (!idx.length) return TAB + ": no data for this selection";
  return TAB + DOT + idx.length + " days" + DOT + ds[0] + " to " + ds[ds.length - 1] +
         DOT + "from " + SENSOR.file + (off ? DOT + off + " turned off" : "");
}

function writeHint(){
  const L = [];
  if (isGrabTab()) {
    L.push("<b>Nutrient Grab Samples</b> stacks the grab analytes of " + esc(GRAB.file) + " in panels on one date axis. " +
           GRAB_PANELS.filter(p => p.overlay).map(p => "The " + esc(p.col) + " panel carries " + esc(p.overlay) +
             " on its left axis and " + esc(p.col) + " on its right axis, at the same scale.").join(" "));
    L.push("<b>Colour</b> is the analyte and <b>marker shape</b> is the watershed (circle Shatto, triangle Kirkpatrick).");
  } else {
    L.push("<b>Tabs</b> switch the measurement; each sensor tab is a column of " + esc(SENSOR.file) +
           ". <b>Colour</b> and <b>marker shape</b> are the watershed (legend above the plot).");
    L.push("<b>Hover</b> a point for its daily mean" + (SENSOR.sdv[TAB] ? " " + PM.trim() + " SD and n (the readings averaged that day)" : "") + ".");
  }
  L.push("<b>Click</b> a point to see every value for that row, the other file on the same day, and to turn the point off, with a comment.");
  L.push("<b>Zoom</b> by dragging across the plot; double-click to go back to the whole record. " +
         "Click a name in the legend to hide that series.");
  L.push("<b>Dates</b> run left to right by month " + DASH + " Jan and Jun, then all twelve once zoomed in " + DASH +
         " with the year beside January.");
  if (HAS_OUT) L.push("<b>The strip above</b> is daily discharge and precipitation at the watershed outlet, " +
                      "on the same dates: zoom one and the other follows.");
  L.push("<b>Download reviewed sensor / grab data</b> writes that file back with every OFF point set to " +
         esc(NA_TOKEN) + " (a sensor metric\u2019s _SD and _n too); " +
         "<b>download review log</b> lists each OFF point in both files with its comment.");
  document.getElementById("hint").innerHTML =
    L.map(s => '<div style="margin:2px 0">' + s + '</div>').join("");
}

/* the figure caption above the plot: what one point is, what the colours
   and shapes mean, and what the error bars are */
const capDot = c => '<span style="color:' + c + '">\u25cf</span>\u00a0';
const lowerFirst = s => s.charAt(0).toLowerCase() + s.slice(1);
function plotCaption(){
  if (isGrabTab()) {
    const pos = i => GRAB_PANELS.length === 3 ? ["Top", "Middle", "Bottom"][i] : "Panel " + (i + 1);
    const panels = GRAB_PANELS.map((p, i) => {
      const own = capDot(p.color) + shortName(p.col);
      return pos(i) + " panel: " + (p.overlay
        ? capDot(p.overlay_color) + shortName(p.overlay) + " (left axis) with " + own +
          " (right axis, same scale)."
        : own + ".");
    }).join(" ");
    /* say so when a watershed has no samples of an analyte (Kirkpatrick: no TN or TP) */
    const gaps = wsOnScreen().map(w => {
      const none = GRAB.metrics.filter(m => !GRAB.rows.some(r => r.ws === w && GRAB.val[m][r.i] != null));
      return none.length ? w + " has no " + none.map(m => lowerFirst(shortName(m))).join(" or ") + " samples." : "";
    }).filter(Boolean).join(" ");
    return "<b>Nutrient concentrations in grab samples.</b> Each point is one grab sample of stream " +
           "water collected at a watershed outlet. Colour shows the analyte and marker shape the " +
           "watershed (circle = Shatto, triangle = Kirkpatrick). " + panels + (gaps ? " " + gaps : "");
  }
  const hasSd = !!SENSOR.sdv[TAB];
  const what = hasSd
    ? "Each point is the daily mean of the in-stream sensor readings at a watershed outlet."
    : "Each point is one day\u2019s value at a watershed outlet, as recorded in " + esc(SENSOR.file) + ".";
  const err = !hasSd ? ""
    : errMode === "sd"
      ? " Error bars are " + PM.trim() + " 1 SD of that day\u2019s readings; hover a point for n, the number of readings."
      : " Error bars are turned off; hover a point for its SD and n, the number of readings.";
  return "<b>" + DATA.axis_prefix + ": " + DATA.labels[TAB] + ".</b> " + what + " Colour and marker shape show the watershed " +
         "(dark navy circle = Shatto, light purple triangle = Kirkpatrick)." + err;
}

function refresh(){
  renderTabs();
  document.getElementById("wrap-err").hidden = isGrabTab() || !SENSOR.sdv[TAB];
  document.getElementById("plot-cap").innerHTML = plotCaption();
  writeHint();
  drawPlot();
  renderOffList();
  document.getElementById("h-metric").textContent = metricSubtitle();
  if (PANEL) renderPanel();
  saveState();
}

function switchTo(key){
  if (!TABS.includes(key)) return;
  TAB = key;
  if (PANEL && PANEL.ds === "sensor" && key !== GRAB_TAB) PANEL.m = key;
  pending = false;
  refresh();
}

/* ---------- export: must round-trip ----------
   A reviewed download is the loaded file rebuilt from its own text: same
   columns, order, number text, NA token, dates, UTF-8 without BOM, and line
   endings. Only OFF points change: the value, and its _SD and _n where the
   file has them, become the NA token. */
function reviewedText(ds){
  const D = DS[ds], H = D.header, col = {};
  H.forEach((h, j) => { col[h] = j; });
  const lines = [H.join(",")];
  for (let i = 0; i < D.n; i++) {
    const cells = H.map(h => D.cols[h][i]);
    D.metrics.forEach(m => {
      if (!isOff(ds, m, i)) return;
      cells[col[m]] = NA_TOKEN;
      if (col[m + "_SD"] != null) cells[col[m + "_SD"]] = NA_TOKEN;
      if (col[m + "_n"] != null)  cells[col[m + "_n"]]  = MISSING_N;
    });
    lines.push(cells.join(","));
  }
  return lines.join(D.eol) + (D.final_eol ? D.eol : "");
}

const csvEsc = v => {
  const s = String(v == null ? "" : v);
  return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
};
/* one log for both files; original_SD and original_n are blank where the
   file has no such column (Q_Ls, the grab analytes) */
function reviewLogText(){
  const head = ["data_file", "Watershed", "Sample_date", "metric_column",
                "original_value", "original_SD", "original_n", "comment", "timestamp_utc"];
  const lines = [head.join(",")];
  offEntries().forEach(x => {
    const D = DS[x.ds], r = D.rows[x.i], C = D.cols;
    lines.push([D.file, r.ws, r.date, x.m, C[x.m][x.i],
                C[x.m + "_SD"] ? C[x.m + "_SD"][x.i] : "",
                C[x.m + "_n"] ? C[x.m + "_n"][x.i] : "",
                x.o.comment, x.o.ts].map(csvEsc).join(","));
  });
  return lines.join("\n") + "\n";
}

function download(name, text){
  /* a string Blob is written as UTF-8 with no BOM */
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([text], { type: "text/csv;charset=utf-8" }));
  a.download = name;
  document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 400);
}

/* ---------- saved review (this browser only) ---------- */
const SKEY = "iwi_viewer::" + DS_IDS.map(id => DS[id].file + "::" + DS[id].md5).join("::");
function saveState(){
  const n = offCount();
  document.getElementById("savestate").textContent =
    n ? n + " point" + (n === 1 ? "" : "s") + " off" + DOT + "saved in this browser" : "";
  try {
    localStorage.setItem(SKEY, JSON.stringify({
      off: OFF, tab: TAB, wsFilter: wsFilter, errMode: errMode,
      showCtx: showCtx, keepZoom: keepZoom, when: new Date().toISOString()
    }));
  } catch (e) { /* storage unavailable; the page still works */ }
}
function loadState(){
  let s = null;
  try { s = JSON.parse(localStorage.getItem(SKEY) || "null"); } catch (e) { return; }
  if (!s) return;
  if (s.off) DS_IDS.forEach(ds => DS[ds].metrics.forEach(m =>
    Object.entries((s.off[ds] || {})[m] || {}).forEach(([i, o]) => {
      i = Number(i);
      if (i >= 0 && i < DS[ds].n && hasValue(ds, m, i) && o && String(o.comment || "").trim()) {
        OFF[ds][m][i] = { comment: String(o.comment), ts: String(o.ts || "") };
      }
    })));
  if (TABS.includes(s.tab)) TAB = s.tab;
  if (s.wsFilter === "all" || WS_LIST.includes(s.wsFilter)) wsFilter = s.wsFilter;
  if (s.errMode === "sd" || s.errMode === "none") errMode = s.errMode;
  if (typeof s.showCtx === "boolean") showCtx = s.showCtx;
  keepZoom = !!s.keepZoom;
}

/* ---------- wiring ---------- */
document.getElementById("h-banner").textContent = DATA.title;
(function writeSub(){
  const all = DS_IDS.flatMap(id => DS[id].rows.map(r => r.date)).sort();
  document.getElementById("h-sub").textContent =
    "Loaded files: " + DS_IDS.map(id => DS[id].file + " (" + DS[id].n + " rows)").join(", ") + DOT +
    all[0] + " to " + all[all.length - 1] + DOT +
    SENSOR.metrics.length + " sensor metrics, " + GRAB.metrics.length + " grab analytes" + DOT +
    "built " + DATA.built +
    (HAS_OUT ? DOT + "outlet Q/precip: " + OUT_WS.map(w => OUTS[w].file).join(", ") : "");
})();

document.getElementById("sel-ws").innerHTML = '<option value="all">All</option>' +
  WS_LIST.map(w => '<option value="' + esc(w) + '">' + esc(w) + '</option>').join("");

loadState();

document.getElementById("sel-ws").onchange = e => { wsFilter = e.target.value; updateCtxHead(); refresh(); };
document.getElementById("sel-err").onchange = e => {
  errMode = e.target.value; drawPlot(); saveState();
  document.getElementById("plot-cap").innerHTML = plotCaption();
};
document.getElementById("cb-ctx").onchange = e => { showCtx = e.target.checked; applyCtx(); saveState(); };
document.getElementById("cb-keepzoom").onchange = e => { keepZoom = e.target.checked; drawPlot(); saveState(); };
document.getElementById("btn-resetzoom").onclick = resetZoom;
document.getElementById("btn-dl-sensor").onclick = () => download(DATA.names.sensor, reviewedText("sensor"));
document.getElementById("btn-dl-grab").onclick = () => download(DATA.names.grab, reviewedText("grab"));
document.getElementById("btn-dl-log").onclick = () => download(DATA.names.log, reviewLogText());
document.getElementById("btn-clear-saved").onclick = () => {
  if (offCount() && !confirm("Turn every point back on and forget the comments saved in this browser?")) return;
  DS_IDS.forEach(ds => DS[ds].metrics.forEach(m => { OFF[ds][m] = {}; }));
  try { localStorage.removeItem(SKEY); } catch (e) {}
  refresh();
};
document.getElementById("side-close").onclick = closePanel;
document.getElementById("scrim").onclick = closePanel;
document.addEventListener("keydown", e => { if (e.key === "Escape") closePanel(); });

document.getElementById("sel-ws").value = wsFilter;
document.getElementById("sel-err").value = errMode;
document.getElementById("cb-keepzoom").checked = keepZoom;
document.getElementById("cb-ctx").checked = showCtx;
if (!HAS_OUT) document.getElementById("wrap-ctx").style.display = "none";

applyCtx();
refresh();

/* hooks for the headless round-trip test (work/03_roundtrip.R) */
window.IWI = { reviewedText, reviewLogText, turnOff, turnOn, openPanel, switchTo,
               drawPlot, monthTicks, ctxFit, offCount, DS, TABS, plotCaption };
</script>
</body>
</html>
]---"

html <- TEMPLATE |>
  fill("/*__PLOTLYJS__*/", plotly_js) |>
  fill("/*__DATA__*/", json)
html_path <- file.path(pkg_dir, html_file)
writeBin(charToRaw(enc2utf8(html)), html_path)

# =============================================================================
# Stage 7. Verification
# =============================================================================
written <- read_file(html_path)
json_back <- regmatches(written, regexpr("(?s)/\\*__DATA_START__\\*/.*?/\\*__DATA_END__\\*/",
                                         written, perl = TRUE))
json_back <- sub("^/\\*__DATA_START__\\*/", "", sub("/\\*__DATA_END__\\*/$", "", json_back))
emb <- fromJSON(json_back, simplifyVector = FALSE)

# every key anywhere in the embedded JSON
all_keys <- function(x) {
  if (!is.list(x)) return(character())
  c(names(x), unlist(lapply(x, all_keys), use.names = FALSE))
}
emb_keys <- unique(all_keys(emb))
csv_headers <- unique(c(names(sensor$df), names(grab$df), outlet_header))
extra_cols <- setdiff(emb_keys, c(csv_headers, structural_keys))
if (length(extra_cols)) stop("Embedded JSON has columns that are not in the EDI CSVs: ",
                             paste(extra_cols, collapse = ", "))
walk(emb$outlets, \(o) if (!identical(names(o$columns), outlet_header)) {
  stop("Embedded outlet columns differ from the outlet CSV header.")
})

# per data file: embedded columns == header, same row count, and what the
# page's reviewed download writes with nothing turned off -- rebuilt the same
# way from the embedded text -- must equal the file byte for byte
files_in <- list(sensor = sensor, grab = grab)
checks.df <- map(emb$datasets, \(d) {
  src <- files_in[[d$id]]
  if (!identical(names(d$columns), names(src$df))) stop(d$file, ": embedded columns differ from the CSV header.")
  cols_back <- map(d$columns, unlist)
  no_toggle <- paste0(
    paste(c(paste(unlist(d$header), collapse = ","), do.call(paste, c(unname(cols_back), sep = ","))),
          collapse = d$eol),
    if (isTRUE(d$final_eol)) d$eol else "")
  same <- identical(charToRaw(enc2utf8(no_toggle)), src$bytes)
  if (!same) stop(d$file, ": rebuilding the CSV from the embedded data does not match the file.")
  tibble(file = d$file, rows = nrow(src$df), cols = ncol(src$df),
         emb_rows = length(d$columns[[1]]), emb_cols = length(d$columns),
         metrics = length(d$metrics), md5 = src$md5, byte_identical = same)
}) |> list_rbind()
if (any(checks.df$rows != checks.df$emb_rows)) stop("Embedded row count differs from a CSV.")

# spelled-out names only (rule 5)
abbrev <- grepl("\\b(SDW|KDW|NoCC|CC)\\b", c(TEMPLATE, json), perl = TRUE)
if (any(abbrev)) stop("An abbreviation (SDW/KDW/CC/NoCC) is in the page.")

cat("\n==== IWI stream outlet visualizer: verification ====\n")
pwalk(checks.df, \(file, rows, cols, emb_rows, emb_cols, metrics, md5, byte_identical) {
  cat(sprintf("Data file        : %s  (md5 %s)\n", file, md5))
  cat(sprintf("  rows x columns : %d x %d  (embedded: %d rows, %d columns)\n", rows, cols, emb_rows, emb_cols))
  cat(sprintf("  unedited export rebuilds the file byte for byte: %s\n", byte_identical))
})
cat(sprintf("Sensor tabs      : %s\n", paste(tab_order, collapse = ", ")))
cat(sprintf("Grab tab         : %s\n", paste(grab_metrics, collapse = ", ")))
cat(sprintf("Y-axis titles    : %d of %d metrics\n",
            sum(c(sensor_metrics, grab_metrics) %in% names(emb$labels)), length(c(sensor_metrics, grab_metrics))))
cat(sprintf("Watersheds       : %s\n", paste(sort(unique(c(sensor$df$Watershed, grab$df$Watershed))), collapse = ", ")))
cat(sprintf("Outlet files     : %s\n", paste(outlet_files, collapse = ", ")))
walk(outlets, \(o) cat(sprintf("                   %s: %d days\n", o$watershed, length(o$columns$date))))
cat(sprintf("Extra columns in embedded JSON (must be none): %s\n",
            if (length(extra_cols)) paste(extra_cols, collapse = ", ") else "none"))
cat(sprintf("HTML written     : %s (%.1f MB)\n", normalizePath(html_path), file.size(html_path) / 1e6))
