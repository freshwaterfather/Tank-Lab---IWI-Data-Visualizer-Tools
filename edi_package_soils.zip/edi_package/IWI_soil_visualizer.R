# =============================================================================
# IWI_soil_visualizer.R
# Indiana Watershed Initiative (IWI): Soil Data Visualizer
#
# Rebuilds IWI_soil_visualizer.html from the CSV that sits next to this
# script. The page is one self-contained file (plotly.js inlined) that works
# offline. Use it to QA/QC the data:
#   1. open the .html, click a point, turn it OFF with a comment
#   2. "download reviewed data" -> a CSV with exactly this file's layout, the
#      turned-off points written the way the file already records a missing
#      metric (value, _SD and _n all NA)
#   3. put that CSV next to this script, name it in the CONFIG line, rerun
#
# Reads only:  the data file below
# Writes only: IWI_soil_visualizer.html (same folder)
#
# Packages: readr, dplyr, purrr, jsonlite, plotly (plotly only for its copy
# of plotly.js, which is inlined into the page).
# =============================================================================

# ---- CONFIG -----------------------------------------------------------------
data_file <- "IWI_soil_data.csv"   # <- field means; drop a reviewed download in here
# -----------------------------------------------------------------------------

# Normally unchanged: the page and the download names.
html_file      <- "IWI_soil_visualizer.html"
download_names <- list(
  data = "IWI_soil_data_reviewed.csv",
  log  = "IWI_soil_review_log.csv"
)
page_title <- "Indiana Watershed Initiative (IWI): Soil Data Visualizer"

# How this file records a missing metric: value, _SD and _n are all NA (n is
# never 0 here). A point turned OFF in the page is written the same way.
na_token  <- "NA"
missing_n <- "NA"

# Layout and harmonized vocabulary (CLAUDE.md rule 6). Anything else stops the build.
key_cols    <- c("Project", "Watershed", "Season", "Sample_date", "Site_id", "Depth_cm", "Cover_crop_presence")
row_key     <- c("Watershed", "Sample_date", "Site_id", "Depth_cm")   # one row per field x date x depth
project     <- "Indiana Watershed Initiative (IWI)"
watersheds  <- c("Shatto", "Kirkpatrick")
seasons     <- c("Spring", "Fall")
depths      <- c("0-5cm", "5-20cm")
cover_crops <- c("cover crop", "no cover crop")

# Y-axis titles, spelled out as they would be in a paper. The tabs keep the
# CSV column headers; only the axis titles and the captions use these.
# <sub>/<sup> render in both plotly and the HTML caption.
axis_labels <- c(
  OM_pct      = "Soil organic matter (% LOI at 360\u00b0C)",
  NO3N_mgkg   = "Soil nitrate (mg NO<sub>3</sub><sup>\u2212</sup>-N/kg)",
  NH4N_mgkg   = "Soil ammonium (mg NH<sub>4</sub><sup>+</sup>-N/kg)",
  CEC_meq100g = "Cation exchange capacity (meq/100 g)",
  STP_mgkg    = "Soil test phosphorus (mg P/kg)",
  WEP_mgkg    = "Water-extractable phosphorus (mg P/kg)",
  Ca_mgkg     = "Extractable calcium (mg/kg)",
  Fe_mgkg     = "Extractable iron (mg/kg)",
  Al_mgkg     = "Extractable aluminum (mg/kg)",
  BD_gcm3     = "Bulk density (g/cm<sup>3</sup>)"
)

# What one point is, in front of each panel's y-axis title: "<prefix>:<br><title>".
# Upper panel: the mean of the field means in one watershed x campaign x
# cover crop x depth (worked out in the page). Lower panel: one field's mean
# across its transects (the rows of the file).
axis_prefix_mean  <- "Treatment mean by watershed"
axis_prefix_field <- "Treatment mean by field"

# Tab order, left to right (advisor, 2026-10): every metric exactly once. The
# page opens on the first. The side panel lists metrics in this order too.
# The CSV column order is not changed.
tab_order <- c("NO3N_mgkg", "NH4N_mgkg", "STP_mgkg", "WEP_mgkg",
               "Ca_mgkg", "Fe_mgkg", "Al_mgkg",            # cations
               "CEC_meq100g", "OM_pct", "BD_gcm3")

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(purrr)
  library(jsonlite)
})
if (!requireNamespace("plotly", quietly = TRUE)) {
  stop("The plotly package is needed for its copy of plotly.js: install.packages(\"plotly\")")
}

# =============================================================================
# Stage 1. Find this script's folder, so getwd() doesn't matter
# =============================================================================
script_dir <- function() {
  a <- grep("^--file=", commandArgs(FALSE), value = TRUE)
  if (length(a)) return(dirname(normalizePath(sub("^--file=", "", a[1]))))
  for (i in rev(seq_len(sys.nframe()))) {          # source("...")
    f <- sys.frame(i)$ofile
    if (!is.null(f)) return(dirname(normalizePath(f)))
  }
  if (requireNamespace("rstudioapi", quietly = TRUE) && rstudioapi::isAvailable()) {
    p <- rstudioapi::getSourceEditorContext()$path  # Run in Positron/RStudio
    if (nzchar(p)) return(dirname(normalizePath(p)))
  }
  stop("Can't tell where this script lives. Run it with Rscript or source() it.")
}
pkg_dir <- script_dir()

# =============================================================================
# Stage 2. Read the CSV exactly as text
# Every cell stays the string that is in the file ("0.30" stays "0.30"), so
# the page can write the file back byte for byte. The reader proves that by
# rebuilding the file from its cells and comparing bytes.
# =============================================================================
read_exact <- function(file) {
  path <- file.path(pkg_dir, file)
  if (!file.exists(path)) stop("File not found next to the script: ", file)
  bytes <- readBin(path, "raw", file.size(path))
  if (length(bytes) >= 3 && identical(bytes[1:3], as.raw(c(0xEF, 0xBB, 0xBF)))) {
    stop(file, " starts with a byte-order mark (BOM). Save it as UTF-8 without a BOM.")
  }
  txt <- rawToChar(bytes)
  Encoding(txt) <- "UTF-8"
  if (!validUTF8(txt)) stop(file, " is not valid UTF-8.")
  if (grepl('"', txt, fixed = TRUE)) {
    stop(file, " contains quote characters; this script expects an unquoted CSV.")
  }
  eol <- if (grepl("\r\n", txt, fixed = TRUE)) "\r\n" else "\n"

  cells.df <- read_csv(I(txt), col_types = cols(.default = col_character()),
                       na = character(), quote = "", trim_ws = FALSE,
                       skip_empty_rows = FALSE, progress = FALSE)
  final_eol <- endsWith(txt, eol)
  rebuilt <- paste0(
    paste(c(paste(names(cells.df), collapse = ","),
            do.call(paste, c(unname(as.list(cells.df)), sep = ","))),
          collapse = eol),
    if (final_eol) eol else "")
  if (!identical(charToRaw(enc2utf8(rebuilt)), bytes)) {
    stop(file, " does not rebuild byte for byte from its cells ",
         "(mixed line endings, blank lines, or ragged rows?).")
  }
  list(df = cells.df, eol = eol, final_eol = final_eol,
       md5 = unname(tools::md5sum(path)), bytes = bytes)
}

# =============================================================================
# Stage 3. Check the layout and the vocabulary
# The key columns come first, then every metric as the triple X, X_SD, X_n.
# =============================================================================
is_num_text <- function(x) grepl("^-?(\\d+\\.?\\d*|\\.\\d+)([eE][-+]?\\d+)?$", x)

check_data <- function(dat, file) {
  data.df <- dat$df
  header  <- names(data.df)
  if (!identical(header[seq_along(key_cols)], key_cols)) {
    stop(file, ": the first columns must be ", paste(key_cols, collapse = ", "))
  }
  rest <- header[-seq_along(key_cols)]
  metric_cols <- rest[!grepl("_(SD|n)$", rest)]
  if (!length(metric_cols)) stop(file, ": no metric columns after the keys.")
  expected <- unlist(map(metric_cols, \(m) paste0(m, c("", "_SD", "_n"))))
  if (!identical(rest, expected)) {
    stop(file, ": after the key columns each metric must be the triple X, X_SD, X_n. Got: ",
         paste(rest, collapse = ", "))
  }

  vocab <- list(Project = project, Watershed = watersheds, Season = seasons,
                Depth_cm = depths, Cover_crop_presence = cover_crops)
  iwalk(vocab, \(allowed, col) {
    bad <- setdiff(unique(data.df[[col]]), allowed)
    if (length(bad)) stop(file, ": ", col, " must be one of ", paste(allowed, collapse = " / "),
                          ". Found: ", paste(bad, collapse = ", "))
  })
  if (!all(grepl("^[A-Z]$", data.df$Site_id))) {
    stop(file, ": Site_id must be one capital letter. Found: ",
         paste(head(unique(data.df$Site_id[!grepl("^[A-Z]$", data.df$Site_id)])), collapse = ", "))
  }
  bad_date <- data.df$Sample_date[is.na(as.Date(data.df$Sample_date, format = "%Y-%m-%d")) |
                                    !grepl("^\\d{4}-\\d{2}-\\d{2}$", data.df$Sample_date)]
  if (length(bad_date)) stop(file, ": Sample_date must be YYYY-MM-DD. Found: ", paste(head(bad_date), collapse = ", "))
  if (anyDuplicated(data.df[row_key])) stop(file, ": ", paste(row_key, collapse = " x "), " must be unique.")

  walk(metric_cols, \(m) {
    v <- data.df[[m]]; s <- data.df[[paste0(m, "_SD")]]; n <- data.df[[paste0(m, "_n")]]
    if (!all(v == na_token | is_num_text(v))) stop(file, " ", m, ": values must be numbers or ", na_token)
    if (!all(s == na_token | is_num_text(s))) stop(file, " ", m, "_SD: values must be numbers or ", na_token)
    if (!all(n == missing_n | grepl("^\\d+$", n))) stop(file, " ", m, "_n: values must be whole numbers or ", missing_n)
    odd <- sum(v == na_token & (s != na_token | n != missing_n))
    if (odd) warning(file, " ", m, ": ", odd, " rows have no value but an SD or an n")
  })
  metric_cols
}

soil    <- read_exact(data_file)
metrics <- check_data(soil, data_file)
if (!setequal(tab_order, metrics) || anyDuplicated(tab_order)) {
  stop("tab_order must name every metric exactly once. Metrics: ",
       paste(metrics, collapse = ", "), "; tab_order: ", paste(tab_order, collapse = ", "))
}
no_label <- setdiff(metrics, names(axis_labels))
if (length(no_label)) stop("Add a y-axis title to `axis_labels` for: ", paste(no_label, collapse = ", "))

# =============================================================================
# Stage 4. Embed: only the CSV's own rows and columns (CLAUDE.md rule 1)
# Columns go in as the file's text; the page parses numbers for plotting and
# writes the text back out for the reviewed download.
# =============================================================================
page_data <- list(
  title     = unbox(page_title),
  built     = unbox(format(Sys.time(), "%Y-%m-%d %H:%M")),
  na_token  = unbox(na_token),
  missing_n = unbox(missing_n),
  names     = map(download_names, unbox),
  labels    = map(as.list(axis_labels[metrics]), unbox),
  axis_prefix_mean  = unbox(axis_prefix_mean),
  axis_prefix_field = unbox(axis_prefix_field),
  tab_order = tab_order,
  dataset   = list(id = unbox("soil"), file = unbox(data_file), md5 = unbox(soil$md5),
                   eol = unbox(soil$eol), final_eol = unbox(soil$final_eol),
                   metrics = metrics, header = names(soil$df), columns = as.list(soil$df))
)
# the structural keys above; everything else in the JSON must be a CSV header
structural_keys <- c(names(page_data), names(download_names),
                     "id", "file", "md5", "eol", "final_eol", "metrics", "header", "columns")

json <- toJSON(page_data, auto_unbox = FALSE, digits = NA)
json <- gsub("</", "<\\/", json, fixed = TRUE)   # never close the <script> early

# =============================================================================
# Stage 5. Fill the template and write the page
# =============================================================================
fill <- function(x, key, value) {
  i <- regexpr(key, x, fixed = TRUE)
  if (i < 0) stop("Template placeholder missing: ", key)
  paste0(substr(x, 1, i - 1), value, substr(x, i + nchar(key), nchar(x)))
}
plotly_path <- system.file("htmlwidgets/lib/plotlyjs/plotly-latest.min.js", package = "plotly")
if (!nzchar(plotly_path)) stop("plotly.js not found inside the installed plotly package.")
plotly_js <- read_file(plotly_path)

TEMPLATE <- r"---[<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>IWI Soil Data Visualizer</title>
<script>/*__PLOTLYJS__*/</script>
<style>
  /* ---- palette and base (shared by all three IWI viewers) ---- */
  :root{
    --ink:#0b0b0b; --ink2:#52514e; --muted:#898781;
    --line:#e1e0d9; --surface:#ffffff; --surface2:#faf9f6;
    --good:#1d6b3f; --off:#b1560f; --hi:#fff8dc;
  }
  *{box-sizing:border-box}
  body{margin:0;padding:0 24px 80px;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Helvetica,Arial,sans-serif;
       color:var(--ink);background:var(--surface2);font-size:19px;line-height:1.5}
  header{position:sticky;top:0;z-index:50;background:var(--surface2);border-bottom:1px solid var(--line);
         padding:12px 0 8px}
  .banner{font-size:34px;font-weight:600;line-height:1.2;color:var(--ink);margin:0;padding:18px 0 6px}
  h1{font-size:24px;font-weight:500;margin:0 0 3px}
  h2{font-size:20px;font-weight:500;margin:26px 0 10px;padding-bottom:6px;border-bottom:1px solid var(--line)}
  .sub{color:var(--ink2);font-size:18px;margin:0}
  .controls{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:9px}
  .controls label{font-size:17.5px;color:var(--ink2);display:flex;align-items:center;gap:5px}
  .controls label[hidden]{display:none!important}
  button{font:inherit;font-size:18px;padding:6px 12px;border:1px solid #c3c2b7;background:var(--surface);
         border-radius:6px;cursor:pointer;color:var(--ink)}
  button:hover{background:var(--surface2)}
  button.primary{border-color:#8a8a7e;font-weight:500}
  button:disabled{opacity:.45;cursor:default}
  select{font:inherit;font-size:18px;padding:5px 8px;border:1px solid #c3c2b7;border-radius:6px;background:var(--surface)}
  input[type=checkbox]{width:19px;height:19px;cursor:pointer}

  /* ---- metric tabs: the tab text is the CSV column header ---- */
  .tabs{display:flex;gap:4px;align-items:flex-end;margin:10px 0 0;flex-wrap:wrap}
  .tab{font:inherit;font-size:18.5px;padding:7px 15px;border:1px solid var(--line);border-bottom:none;
       background:var(--surface2);border-radius:8px 8px 0 0;cursor:pointer;color:var(--ink2)}
  .tab:hover{background:var(--surface)}
  .tab.on{background:var(--surface);color:var(--ink);font-weight:500;box-shadow:inset 0 3px 0 var(--ink)}
  .tabsrule{border-bottom:1px solid var(--line);margin-bottom:2px}

  .wrap{max-width:1600px;margin:0 auto}
  .card{background:var(--surface);border:1px solid var(--line);border-radius:10px;margin:16px 0;overflow:hidden}
  .plotwrap{padding:10px 6px 12px}
  .plot{width:100%;height:640px}
  /* the watershed-means plot: two stacked depths, or one when a depth is picked */
  .mplot{width:100%;height:600px}
  .mplot.one{height:460px}
  .pwrap{position:relative}
  .guide{position:absolute;width:0;border-left:1px dashed #6d6b64;pointer-events:none;display:none;z-index:5}
  /* figure captions: a full sentence above each panel, as in a paper */
  .figcap{font-size:17.5px;color:var(--ink2);padding:10px 14px 0;max-width:1400px}
  .figcap b{color:var(--ink);font-weight:600}
  .hint{font-size:17px;color:var(--muted);padding:6px 14px 10px}
  .empty{padding:14px;color:var(--muted);font-size:17.5px}
  .badge{font-size:16.5px;padding:1px 8px;border-radius:20px;border:1px solid var(--line);color:var(--ink2);
         background:var(--surface2)}
  .badge.on{color:var(--good);border-color:#cfe3d6;background:#f2f8f4}
  .badge.off{color:var(--off);border-color:#f0cfb4;background:#fdf3ea}

  table{border-collapse:collapse;width:100%;font-size:17.5px;font-variant-numeric:tabular-nums}
  th{position:sticky;top:0;background:var(--surface);text-align:left;font-weight:500;color:var(--ink2);
     padding:7px 8px;border-bottom:1px solid var(--line);white-space:nowrap}
  td{padding:5px 8px;text-align:left;border-bottom:1px solid #f2f1ec;vertical-align:top}
  td.num,th.num{text-align:right;white-space:nowrap}
  .swatch{display:inline-block;width:14px;height:14px;margin-right:7px;vertical-align:middle}
  tr.hi{background:var(--hi)}
  tr.clickable{cursor:pointer}
  tr.clickable:hover{background:var(--surface2)}
  tr.hi.clickable:hover{background:var(--hi)}
  .tablewrap{max-height:420px;overflow:auto}

  /* ---- field checkboxes, grouped by watershed ---- */
  .fieldcard{padding:10px 14px 8px}
  .fieldhead{display:flex;gap:10px;align-items:center;flex-wrap:wrap;font-size:17.5px;color:var(--ink2);margin-bottom:6px}
  .fieldhead b{color:var(--ink);font-weight:500}
  .wsgroup{display:flex;gap:4px 16px;align-items:center;flex-wrap:wrap;padding:5px 0;border-top:1px solid #f2f1ec}
  .wsgroup .wsn{min-width:128px;font-weight:500;color:var(--ink);font-size:17.5px}
  .fchk{display:inline-flex;align-items:center;gap:5px;font-size:17px;color:var(--ink);cursor:pointer;white-space:nowrap}
  .fchk.nd{color:var(--muted)}
  .fchk .ndnote{font-size:15.5px}

  /* ---- click-point side panel ---- */
  .side{position:fixed;right:0;top:0;bottom:0;width:700px;max-width:96vw;z-index:80;
        background:var(--surface);border-left:1px solid var(--line);
        box-shadow:-3px 0 18px rgba(0,0,0,.09);display:flex;flex-direction:column}
  .side[hidden]{display:none!important}
  .sidehead{padding:12px 16px;border-bottom:1px solid var(--line);display:flex;align-items:baseline;
            gap:10px;flex-wrap:wrap}
  .sidehead .t{font-size:20px;font-weight:500}
  .sidebody{overflow:auto;padding:0 0 20px}
  .sidesec{padding:10px 16px;border-bottom:1px solid var(--line);font-size:17.5px;color:var(--ink2)}
  .sidesec b{color:var(--ink);font-weight:500}
  .sidesec h3{font-size:17.5px;font-weight:600;color:var(--ink);margin:0 0 6px}
  .side table{font-size:17.5px}
  .side td{padding:4px 8px}
  .closebtn{margin-left:auto;font-size:17px;padding:4px 10px}
  .scrim{position:fixed;inset:0;background:rgba(0,0,0,.12);z-index:70}
  .scrim[hidden]{display:none!important}
  .nodata{color:var(--muted);font-style:italic}
  .was{color:var(--muted);text-decoration:line-through}

  /* ---- the ON/OFF switch and the required comment ---- */
  .toggle{display:flex;align-items:center;gap:10px;margin:4px 0 8px}
  .sw2{position:relative;display:inline-block;width:40px;height:22px;vertical-align:middle;flex:none}
  .sw2 input{opacity:0;width:0;height:0;position:absolute}
  .sw2 .sl{position:absolute;inset:0;background:#cfcdc4;border-radius:22px;transition:background .12s;cursor:pointer}
  .sw2 .sl:before{content:"";position:absolute;height:18px;width:18px;left:2px;top:2px;background:#fff;
                  border-radius:50%;transition:transform .12s;box-shadow:0 1px 2px rgba(0,0,0,.25)}
  .sw2 input:checked + .sl{background:var(--good)}
  .sw2 input:checked + .sl:before{transform:translateX(18px)}
  .sw2 input:disabled + .sl{opacity:.4;cursor:default}
  textarea.comment{width:100%;min-height:64px;font:inherit;font-size:18px;padding:6px 8px;
                   border:1px solid #c3c2b7;border-radius:6px;resize:vertical}
  .req{color:var(--off);font-size:17px}
  .row-actions{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:8px}
</style>
</head>
<body>
<div class="wrap">
<p class="banner" id="h-banner"></p>
<header>
  <p class="sub" id="h-sub"></p>
  <div class="tabs" id="tabs"></div>
  <div class="tabsrule"></div>
  <div class="controls">
    <label>watershed <select id="sel-ws"></select></label>
    <label>depth <select id="sel-depth"></select></label>
    <label>cover crop <select id="sel-cc"></select></label>
    <label id="wrap-err">error bars
      <select id="sel-err">
        <option value="sd">&plusmn; SD</option>
        <option value="none">none</option>
      </select>
    </label>
    <label title="a thin grey line joins each field's dates at each depth"><input type="checkbox" id="cb-lines"> connect each field's dates</label>
    <label><input type="checkbox" id="cb-keepzoom"> keep zoom when switching tabs</label>
    <button id="btn-resetzoom">reset zoom</button>
    <span style="width:8px"></span>
    <button id="btn-dl-data" class="primary">download reviewed data (.csv)</button>
    <button id="btn-dl-log">download review log (.csv)</button>
    <span style="width:8px"></span>
    <span id="savestate" style="font-size:17px;color:var(--muted)"></span>
    <button id="btn-clear-saved" style="font-size:17px;padding:4px 9px">clear saved review</button>
  </div>
  <p class="sub" id="h-metric" style="margin-top:6px"></p>
</header>

<div class="card" id="meancard">
  <div class="figcap" id="mean-cap"></div>
  <div class="plotwrap"><div class="pwrap"><div class="mplot" id="mplot"></div><div class="guide" id="guide-mplot"></div></div></div>
</div>

<div class="card fieldcard" id="fieldcard">
  <div class="fieldhead">
    <b>Fields</b>
    <button id="btn-fields-all">Show all fields</button>
    <button id="btn-fields-none">Hide all fields</button>
    <span id="fields-count"></span>
  </div>
  <div id="fieldlist"></div>
</div>

<div class="card" id="plotcard">
  <div class="figcap" id="plot-cap"></div>
  <div class="plotwrap"><div class="pwrap"><div class="plot" id="plot"></div><div class="guide" id="guide-plot"></div></div></div>
  <div class="hint" id="hint"></div>
</div>

<h2 id="off-title">Points turned off</h2>
<div class="card" id="offlist"></div>

<h2>series summary &mdash; live</h2>
<div class="card" id="summary"></div>
</div>

<div class="scrim" id="scrim" hidden></div>
<aside class="side" id="side" hidden>
  <div class="sidehead">
    <span class="t" id="side-title"></span>
    <span class="badge" id="side-badge"></span>
    <button class="closebtn" id="side-close">close</button>
  </div>
  <div class="sidebody" id="side-body"></div>
</aside>

<script>
const DATA = /*__DATA_START__*/ /*__DATA__*/ /*__DATA_END__*/;

/* ====================================================================
   IWI DATA VISUALIZER -- soils

   The page carries the EDI CSV and nothing else: D.cols is the file,
   column by column, as the TEXT that is in the file. Numbers are parsed
   from that text for plotting; the reviewed download writes the text back,
   so with nothing turned off it is byte-identical to the file.

   A ROW is one field (Watershed + Site_id) on one Sample_date at one
   Depth_cm: the mean +/- SD of the field's transects. A POINT is one row
   within one metric column. Turning a point OFF needs a comment. An OFF
   point is drawn as an x, the field's line skips it, and in the reviewed
   download its value, _SD and _n become NA -- the way the file already
   records a missing metric.

   Two panels per tab, on one shared date window:
     TREATMENT MEANS BY WATERSHED (top) -- computed here from the field
       rows, never stored: the mean of the field means in one watershed x
       sampling campaign x cover crop x depth, leaving out points turned
       off. Laid out like the tile drain page: colour = cover crop, shape =
       watershed, filled = 0-5cm, open = 5-20cm, one strip per depth.
       View-only: a click lists the field points behind it, and those are
       what get reviewed.
     TREATMENT MEANS BY FIELD (bottom) -- the file's rows. Colour = that
       row's Cover_crop_presence (a field can switch, so its line is neutral
       grey and only the markers change colour); shape = watershed; filled =
       0-5cm, open = 5-20cm. The field checkboxes act on this panel only.

   GLOBAL across tabs: the watershed, depth and cover crop filters, the
   field checkboxes, error bars, lines, keep-zoom, and every OFF point with
   its comment. All of it is saved in this browser, keyed to the data
   file's md5, so a different file never inherits an old review.
   ==================================================================== */

const NA_TOKEN = DATA.na_token, MISSING_N = DATA.missing_n;

/* the shared IWI cover crop colours: one light and bright, one dark and
   dull, so they differ in tone and not just in hue (lab manager, 2026-09-24) */
const CC_COLOR     = { "cover crop": "#7DC24B", "no cover crop": "#4A3526" };
/* Both panels (advisor, 2026-10): shape = watershed, as in the other two IWI
   viewers (circle Shatto, triangle Kirkpatrick); fill = depth (filled 0-5cm,
   open 5-20cm). An open marker is drawn with a 2px outline in its colour. */
const WS_SYMBOL    = { "Shatto": "circle", "Kirkpatrick": "triangle-up" };
const DEPTH_OPEN   = { "0-5cm": false, "5-20cm": true };
const symbolFor    = (ws, depth) => WS_SYMBOL[ws] + (DEPTH_OPEN[depth] ? "-open" : "");
const depthLine    = (depth, color) => DEPTH_OPEN[depth] ? { width: 2, color: color } : { width: 0 };
const WS_ORDER     = ["Shatto", "Kirkpatrick"];
/* both panels share these margins, so their date axes line up; the left one
   is wide enough for a two-line y-axis title */
const PLOT_MARGIN_L = 116, PLOT_MARGIN_R = 24;
const LINE_COLOR   = "#b9b6ab";
const KEY_GREY     = "#a8a59b";
const POINT_SIZE   = 9;

const esc = s => String(s == null ? "" : s)
  .replace(/&/g,"&amp;").replace(/"/g,"&quot;")
  .replace(/</g,"&lt;").replace(/>/g,"&gt;");
const num = s => (s == null || s === "" || s === NA_TOKEN) ? null : Number(s);
const hexA = (hex, a) => {
  const n = parseInt(hex.slice(1), 16);
  return "rgba(" + (n >> 16 & 255) + "," + (n >> 8 & 255) + "," + (n & 255) + "," + a + ")";
};
const DOT = " \u00b7 ", PM = " \u00b1 ", DASH = "\u2014";
/* a y-axis title: what one point is ("mean" or "field" panel), then the
   spelled-out metric and unit */
const yTitle = (panel, m) => DATA["axis_prefix_" + panel] + ":<br>" + DATA.labels[m];
const capTitle = (panel, m) => DATA["axis_prefix_" + panel].replace("mean", "means") + ": " + DATA.labels[m];

/* ---------- the data file ---------- */
const D = (function(){
  const d = DATA.dataset, C = d.columns, n = C[d.header[0]].length;
  const X = {
    file: d.file, md5: d.md5, eol: d.eol, final_eol: d.final_eol,
    header: d.header, metrics: d.metrics, cols: C, n: n,
    rows: Array.from({ length: n }, (_, i) => ({
      i, ws: C.Watershed[i], date: C.Sample_date[i], site: C.Site_id[i], depth: C.Depth_cm[i],
      cc: C.Cover_crop_presence[i], season: C.Season[i],
      fid: C.Watershed[i] + "|" + C.Site_id[i],
      sid: C.Watershed[i] + "|" + C.Site_id[i] + "|" + C.Depth_cm[i]
    })),
    val: {}, sdv: {}, key: new Map()
  };
  X.rows.forEach(r => X.key.set(r.ws + "|" + r.date + "|" + r.site + "|" + r.depth, r.i));
  d.metrics.forEach(m => { X.val[m] = C[m].map(num); X.sdv[m] = C[m + "_SD"].map(num); });
  return X;
})();
/* the tabs in the CONFIG order (tab_order); the page opens on the first */
const TABS = DATA.tab_order.slice();
let TAB = TABS[0];

const WS_LIST = WS_ORDER.filter(w => D.rows.some(r => r.ws === w));
const DEPTHS  = Object.keys(DEPTH_OPEN).filter(d => D.rows.some(r => r.depth === d));
const CC_LIST = Object.keys(CC_COLOR).filter(c => D.rows.some(r => r.cc === c));

/* a field is Watershed + Site_id: the letters repeat across watersheds */
const FIELDS = [];
WS_LIST.forEach(w => {
  [...new Set(D.rows.filter(r => r.ws === w).map(r => r.site))].sort().forEach(s => {
    FIELDS.push({ id: w + "|" + s, ws: w, site: s, label: "Field " + s, full: w + " Field " + s });
  });
});
const FIELD = new Map(FIELDS.map(f => [f.id, f]));
const fullName = r => FIELD.get(r.fid).full;

/* ---------- state ---------- */
let wsFilter = "all", depthFilter = "all", ccFilter = "all";
let errMode = "sd", showLines = false, keepZoom = false;   /* lines start off (Mitchell, 2026-09-24) */
const HIDDEN = new Set();              /* field ids turned off with the checkboxes */
const OFF = {};                        /* OFF[metric][row] = { comment, ts } */
D.metrics.forEach(m => { OFF[m] = {}; });
const isOff = (m, i) => !!OFF[m][i];
const hasValue = (m, i) => D.cols[m][i] !== NA_TOKEN;
const offCount = () => D.metrics.reduce((a, m) => a + Object.keys(OFF[m]).length, 0);

const wsOnScreen = () => wsFilter === "all" ? WS_LIST : [wsFilter];
const fieldsListed = () => FIELDS.filter(f => wsFilter === "all" || f.ws === wsFilter);
/* the dropdown filters, without the field checkboxes */
const passFilters = r => (wsFilter === "all" || r.ws === wsFilter) &&
                         (depthFilter === "all" || r.depth === depthFilter) &&
                         (ccFilter === "all" || r.cc === ccFilter);
const passRow = r => passFilters(r) && !HIDDEN.has(r.fid);
const onScreen = m => D.rows.filter(r => passRow(r) && D.val[m][r.i] != null);

/* "value +/- SD (n = ...)", straight from the file's text */
function cellText(m, i){
  const C = D.cols, v = C[m][i];
  if (v === NA_TOKEN) return '<span class="nodata">no data</span>';
  const sd = C[m + "_SD"][i], n = C[m + "_n"][i];
  return esc(v) + PM + (sd === NA_TOKEN ? DASH : esc(sd)) + " (n = " + esc(n) + ")";
}
/* the columns an OFF point rewrites, and what each is written as */
function offColumns(m){
  return { cols: [m, m + "_SD", m + "_n"], toks: [NA_TOKEN, NA_TOKEN, MISSING_N] };
}

/* ---------- plotted points ---------- */
function hoverFor(m, i){
  const r = D.rows[i], L = [];
  L.push("<b>" + esc(fullName(r)) + "</b>" + DOT + esc(r.depth) + DOT + r.date);
  L.push(esc(m) + ": <b>" + cellText(m, i) + "</b>");
  L.push(esc(r.season) + DOT + esc(r.cc));
  if (isOff(m, i)) L.push("<b>turned off</b>: " + esc(OFF[m][i].comment));
  L.push("<i>click to review this point</i>");
  return L.join("<br>") + "<extra></extra>";
}
const byDate = (a, b) => D.rows[a].date < D.rows[b].date ? -1 : D.rows[a].date > D.rows[b].date ? 1 : 0;

/* legend-only entries that explain the encoding; clicking them does nothing */
function keyTrace(name, marker){
  return { type: "scatter", mode: "markers", name: name, x: [null], y: [null],
           hoverinfo: "skip", showlegend: true, marker: Object.assign({ size: POINT_SIZE }, marker) };
}

function soilTraces(){
  const m = TAB, shown = onScreen(m).map(r => r.i);
  const out = [];

  /* the key */
  CC_LIST.filter(c => ccFilter === "all" || c === ccFilter).forEach(c =>
    out.push(keyTrace(c, { symbol: "square", color: CC_COLOR[c] })));
  if (wsFilter === "all") WS_LIST.forEach(w =>
    out.push(keyTrace(w, { symbol: WS_SYMBOL[w], color: KEY_GREY })));
  if (depthFilter === "all") DEPTHS.forEach(d =>
    out.push(keyTrace(d + (DEPTH_OPEN[d] ? " (open)" : " (filled)"),
                      { symbol: symbolFor("Shatto", d), color: KEY_GREY, line: depthLine(d, KEY_GREY) })));
  if (shown.some(i => isOff(m, i))) {
    out.push(keyTrace("turned off", { symbol: "x-thin-open", size: 11, color: "#6d6b64",
                                      line: { width: 2, color: "#6d6b64" } }));
  }

  /* neutral lines, one per field x depth, through its ON points only:
     an OFF or missing point is skipped and its neighbours are joined */
  if (showLines) {
    const bySeries = new Map();
    shown.filter(i => !isOff(m, i)).forEach(i => {
      const s = D.rows[i].sid;
      if (!bySeries.has(s)) bySeries.set(s, []);
      bySeries.get(s).push(i);
    });
    bySeries.forEach((idx, s) => {
      if (idx.length < 2) return;
      idx.sort(byDate);
      out.push({ type: "scatter", mode: "lines", name: s, showlegend: false, hoverinfo: "skip",
                 x: idx.map(i => D.rows[i].date), y: idx.map(i => D.val[m][i]),
                 line: { color: LINE_COLOR, width: 1 } });
    });
  }

  /* ON markers: one trace per cover crop x depth x watershed. meta carries
     "soil|metric" and customdata the row, so a click knows which point it was */
  const base = { type: "scatter", mode: "markers", meta: "soil|" + m, showlegend: false,
                 hoverlabel: { align: "left" } };
  CC_LIST.forEach(c => DEPTHS.forEach(d => WS_LIST.forEach(w => {
    const on = shown.filter(i => { const r = D.rows[i]; return r.cc === c && r.depth === d && r.ws === w && !isOff(m, i); })
                    .sort(byDate);
    if (!on.length) return;
    const t = Object.assign({}, base, {
      name: c + DOT + d + DOT + w,
      x: on.map(i => D.rows[i].date), y: on.map(i => D.val[m][i]), customdata: on,
      marker: { size: POINT_SIZE, symbol: symbolFor(w, d), color: CC_COLOR[c], line: depthLine(d, CC_COLOR[c]) },
      opacity: .92,
      hovertemplate: on.map(i => hoverFor(m, i))
    });
    if (errMode === "sd") {
      t.error_y = { type: "data", array: on.map(i => D.sdv[m][i] == null ? 0 : D.sdv[m][i]),
                    color: hexA(CC_COLOR[c], .45), thickness: 1, width: 2 };
    }
    out.push(t);
  })));

  /* OFF points: an x at the value the point carries in the file, in the
     row's cover crop colour, so the decision stays visible; no error bar */
  const off = shown.filter(i => isOff(m, i)).sort(byDate);
  if (off.length) {
    const col = off.map(i => CC_COLOR[D.rows[i].cc]);
    out.push(Object.assign({}, base, {
      name: "turned off",
      x: off.map(i => D.rows[i].date), y: off.map(i => D.val[m][i]), customdata: off,
      marker: { size: 11, symbol: "x-thin-open", color: col, line: { width: 2, color: col } },
      opacity: .85,
      hovertemplate: off.map(i => hoverFor(m, i))
    }));
  }
  return out;
}

/* why the plot is empty, in words */
function emptyMessage(){
  const listed = fieldsListed();
  if (listed.length && listed.every(f => HIDDEN.has(f.id))) {
    return "No fields selected. Use \u201cShow all fields\u201d, or tick a field above.";
  }
  const parts = [wsFilter === "all" ? "either watershed" : wsFilter,
                 depthFilter === "all" ? "any depth" : depthFilter,
                 ccFilter === "all" ? "either cover crop status" : ccFilter];
  return "No " + TAB + " data for " + parts.join(", ") + " in the fields selected.";
}

/* ---------- watershed means: worked out here, never stored ----------
   A sampling CAMPAIGN is one watershed's sampling in one season of one year.
   It can take several days (Shatto Fall 2014 ran 11-19 November), and a Fall
   campaign run late can reach January (Fall 2022 -> January 2023), so a Fall
   date before July belongs to the previous year's campaign. Each mean is
   plotted at its campaign's first sampling date. */
const campYear = r => Number(r.date.slice(0, 4)) -
  (r.season === "Fall" && Number(r.date.slice(5, 7)) < 7 ? 1 : 0);
const campKey  = r => r.ws + "|" + r.season + "|" + campYear(r);
const CAMP_FIRST = new Map();
D.rows.forEach(r => {
  const k = campKey(r);
  if (!CAMP_FIRST.has(k) || r.date < CAMP_FIRST.get(k)) CAMP_FIRST.set(k, r.date);
});
const meanDepths = () => DEPTHS.filter(d => depthFilter === "all" || d === depthFilter);

/* One group per campaign x cover crop x depth, under the dropdown filters
   (the field checkboxes don't apply). The mean and SD are over the fields'
   ON values; n = those fields. */
function meanGroups(m){
  const G = new Map();
  D.rows.forEach(r => {
    if (!passFilters(r) || D.val[m][r.i] == null) return;
    const k = campKey(r) + "|" + r.cc + "|" + r.depth;
    if (!G.has(k)) G.set(k, { key: k, ws: r.ws, season: r.season, year: campYear(r), cc: r.cc,
                              depth: r.depth, x: CAMP_FIRST.get(campKey(r)), rows: [] });
    G.get(k).rows.push(r.i);
  });
  return [...G.values()].map(g => {
    g.rows.sort((a, b) => byDate(a, b) || (D.rows[a].site < D.rows[b].site ? -1 : 1));
    const v = g.rows.filter(i => !isOff(m, i)).map(i => D.val[m][i]);
    g.n = v.length;
    g.mean = v.length ? v.reduce((a, b) => a + b, 0) / v.length : null;
    g.sd = v.length > 1 ? Math.sqrt(v.reduce((a, b) => a + (b - g.mean) ** 2, 0) / (v.length - 1)) : null;
    g.first = D.rows[g.rows[0]].date;
    g.last = D.rows[g.rows[g.rows.length - 1]].date;
    return g;
  });
}

function meanHover(m, g){
  const L = [];
  L.push("<b>" + esc(g.ws) + DOT + esc(g.cc) + DOT + esc(g.depth) + "</b>  " + esc(g.season) + " " + g.year + " campaign");
  L.push(esc(m) + " treatment mean by watershed: <b>" + fmt(g.mean) + PM + (g.sd == null ? DASH : fmt(g.sd)) +
         " (n = " + g.n + " field" + (g.n === 1 ? "" : "s") + ")</b>");
  L.push("sampled " + (g.first === g.last ? g.first : g.first + " to " + g.last));
  const nOff = g.rows.length - g.n;
  if (nOff) L.push(nOff + " field point" + (nOff === 1 ? "" : "s") + " turned off, left out");
  L.push("<i>click to list the fields in this mean</i>");
  return L.join("<br>") + "<extra></extra>";
}

/* with both depths on screen: 0-5cm on top (axes x2/y), 5-20cm below (x/y2);
   the bottom strip owns the date axis "x" */
const meanAxes = (di, n) => n === 1 ? { x: "x", y: "y" } : (di === 0 ? { x: "x2", y: "y" } : { x: "x", y: "y2" });

function meanTraces(m){
  const groups = meanGroups(m), dps = meanDepths(), out = [];
  dps.forEach((d, di) => {
    const ax = meanAxes(di, dps.length);
    wsOnScreen().forEach(w => CC_LIST.filter(c => ccFilter === "all" || c === ccFilter).forEach(c => {
      const gs = groups.filter(g => g.depth === d && g.ws === w && g.cc === c && g.n > 0)
                       .sort((a, b) => a.x < b.x ? -1 : a.x > b.x ? 1 : 0);
      if (!gs.length) return;
      const col = CC_COLOR[c], grp = w + "|" + c;
      const t = {
        type: "scatter", mode: "markers", name: w + " " + c, legendgroup: grp,
        showlegend: !out.some(o => o.legendgroup === grp),
        meta: "mean|" + m, xaxis: ax.x, yaxis: ax.y,
        x: gs.map(g => g.x), y: gs.map(g => g.mean), customdata: gs.map(g => g.key),
        marker: { size: POINT_SIZE, symbol: symbolFor(w, d), color: col, line: depthLine(d, col) },
        opacity: .92, hovertemplate: gs.map(g => meanHover(m, g)), hoverlabel: { align: "left" }
      };
      if (errMode === "sd") {
        t.error_y = { type: "data", array: gs.map(g => g.sd == null ? 0 : g.sd),
                      color: hexA(col, .45), thickness: 1, width: 2 };
      }
      out.push(t);
    }));
  });
  return out;
}

function meanLayout(m, empty){
  const dps = meanDepths(), two = dps.length > 1;
  const grid = { gridcolor: "#eeece5", zeroline: false, tickfont: { size: 16 } };
  const L = {
    hovermode: "closest",
    showlegend: true,
    legend: { orientation: "h", y: 1.02, yanchor: "bottom", x: 0, font: { size: 17 } },
    paper_bgcolor: "#fff", plot_bgcolor: "#fff",
    font: { family: "-apple-system,Segoe UI,Helvetica,Arial,sans-serif", size: 17 },
    hoverlabel: { font: { size: 17 } },
    margin: { l: PLOT_MARGIN_L, r: PLOT_MARGIN_R, t: 16, b: X_MARGIN_B },
    uirevision: "mean|" + (keepZoom ? "sticky" : (TAB + "|" + wsFilter + "|" + depthFilter + "|" + ccFilter)),
    annotations: []
  };
  const xa = dateAxis();
  if (!two) {
    L.xaxis = xa;
    L.yaxis = Object.assign({ title: { text: yTitle("mean", m), font: { size: 17.5 } }, type: "linear" }, grid);
  } else {
    /* two strips, one title: a strip is too short for a long title of its own */
    const gap = 0.1, each = (1 - gap) / 2;
    L.yaxis  = Object.assign({ domain: [1 - each, 1], anchor: "x2", type: "linear" }, grid);
    L.yaxis2 = Object.assign({ domain: [0, each], anchor: "x", type: "linear" }, grid);
    L.xaxis2 = { type: "date", matches: "x", anchor: "y", showticklabels: false, ticks: "",
                 gridcolor: "#eeece5", zeroline: false };
    L.xaxis  = Object.assign(xa, { anchor: "y2" });
    L.annotations.push({ text: yTitle("mean", m), textangle: -90, xref: "paper", yref: "paper",
                         x: 0, xshift: -86, xanchor: "center", y: 0.5, showarrow: false,
                         font: { size: 17.5 } });
    dps.forEach((d, di) => L.annotations.push({
      text: "<b>" + esc(d) + "</b>", xref: "paper", yref: "paper", x: 0.004, xanchor: "left",
      y: di === 0 ? 1 : each, yanchor: "top", showarrow: false,
      font: { size: 16, color: "#52514e" }, bgcolor: "rgba(255,255,255,.85)" }));
  }
  if (empty) {
    Object.keys(L).filter(k => /^[xy]axis\d*$/.test(k)).forEach(k => { L[k].visible = false; });
    const parts = [wsFilter === "all" ? "either watershed" : wsFilter,
                   depthFilter === "all" ? "any depth" : depthFilter,
                   ccFilter === "all" ? "either cover crop status" : ccFilter];
    L.annotations = [{ text: esc("No " + TAB + " data for " + parts.join(", ") + "."),
                       xref: "paper", yref: "paper", x: 0.5, y: 0.5,
                       showarrow: false, font: { size: 19, color: "#6d6b64" } }];
  }
  return L;
}

/* ---------- the shared date window ----------
   Both panels always show the same dates. The full window covers every row
   that passes the dropdown filters for the tab (not the field checkboxes,
   so ticking a field never moves it). A zoom on either panel becomes xWin
   and is copied to the other; a reset or double-click clears it. */
let xWin = null, xSyncing = false;
const isoDay = t => new Date(t).toISOString().slice(0, 10);
function fullRange(){
  let ds = D.rows.filter(r => passFilters(r) && D.val[TAB][r.i] != null).map(r => r.date);
  if (!ds.length) ds = D.rows.map(r => r.date);
  ds.sort();
  const a = Date.parse(ds[0]), b = Date.parse(ds[ds.length - 1]);
  const pad = Math.max((b - a) * 0.025, 20 * 864e5);
  return [isoDay(a - pad), isoDay(b + pad)];
}
const winRange = () => (xWin || fullRange()).slice();

function bindX(id){
  const gd = document.getElementById(id), other = id === "plot" ? "mplot" : "plot";
  gd.on("plotly_relayout", ev => {
    if (xSyncing) return;
    const keys = Object.keys(ev || {});
    if (keys.some(k => /^xaxis\d*\.autorange$/.test(k) && ev[k])) { resetZoom(); return; }
    if (!keys.some(k => /^xaxis\d*\.range/.test(k))) return;
    const r = gd._fullLayout.xaxis.range;
    xWin = [String(r[0]), String(r[1])];
    const og = document.getElementById(other);
    const done = () => { xSyncing = false; refreshMonthTicks("plot"); refreshMonthTicks("mplot"); };
    if (!og._fullLayout) { done(); return; }
    xSyncing = true;
    Plotly.relayout(og, { "xaxis.range": xWin.slice() }).then(done, done);
  });
  gd.on("plotly_hover", ev => { const p = ev.points && ev.points[0]; if (p) showGuide(other, p.x); });
  gd.on("plotly_unhover", () => hideGuide(other));
}

function resetZoom(){
  xWin = null;
  const r = fullRange();
  const upd = gd => {
    const u = { "xaxis.range": r.slice() };
    Object.keys(gd._fullLayout).filter(k => /^yaxis\d*$/.test(k)).forEach(k => { u[k + ".autorange"] = true; });
    return u;
  };
  xSyncing = true;
  return Promise.all(["plot", "mplot"].map(id => {
    const gd = document.getElementById(id);
    return gd._fullLayout ? Plotly.relayout(gd, upd(gd)) : null;
  })).then(() => { xSyncing = false; refreshMonthTicks("plot"); refreshMonthTicks("mplot"); },
           () => { xSyncing = false; });
}

/* a dashed line on one panel at the date being hovered on the other */
function showGuide(target, x){
  const gd = document.getElementById(target);
  const g  = document.getElementById("guide-" + target);
  const fl = gd && gd._fullLayout;
  if (!g || !fl || !fl.xaxis || !fl._size || fl.xaxis.visible === false) return;
  const xa = fl.xaxis;
  const px = xa._offset + xa.l2p(xa.d2l(x));
  if (!isFinite(px) || px < xa._offset || px > xa._offset + xa._length) {
    g.style.display = "none"; return;
  }
  g.style.left = px + "px";
  g.style.top = fl._size.t + "px";
  g.style.height = fl._size.h + "px";
  g.style.display = "block";
}
function hideGuide(target){
  const g = document.getElementById("guide-" + target);
  if (g) g.style.display = "none";
}

/* ---------- the date axis (shared by all three IWI viewers; copy verbatim) ----------
   Months are named by their first three letters, and January also carries
   the year ("Jan 2019"). Each tick sits mid-month, centred over the month it
   names. Zoomed out, only Jan and Jun are labelled; zoom in until every label
   has room and each month gets one (advisor, 2026-10). "Room" is measured in
   pixels along the axis, so a narrow window drops to Jan + Jun sooner than a
   wide one. If even Jan + Jun would overlap (a very narrow window), only Jan
   is drawn. The labels are set at TICK_ANGLE degrees; angled labels sit closer
   together without colliding, so they need less room per tick. */
const MONTH_ABBR = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
const TICK_ANGLE = -45;
const TICK_ROOM_PX = TICK_ANGLE ? 22 : 44;     /* room one label needs along the axis */
const X_MARGIN_B = TICK_ANGLE ? 80 : 64;       /* the plot's bottom margin, sized for the labels */
const X_TICK_FONT = TICK_ANGLE ? 14 : 16;     /* angled labels a little smaller, so Jan + Jun fit on a long record */
function monthTicks(a, b, px){
  const from = new Date(a), to = new Date(b);
  if (isNaN(+from) || isNaN(+to) || to <= from) return null;
  const span = (to.getUTCFullYear() - from.getUTCFullYear()) * 12 +
               (to.getUTCMonth() - from.getUTCMonth()) + 1;
  const perMonth = (px > 0 ? px : 1000) / span;  /* 1000 px when the plot isn't laid out yet */
  const show = perMonth >= TICK_ROOM_PX     ? () => true
             : perMonth * 5 >= TICK_ROOM_PX ? m => m === 0 || m === 5   /* Jan to Jun is the tighter gap */
             :                                m => m === 0;
  const vals = [], text = [];
  let y = from.getUTCFullYear(), m = from.getUTCMonth();
  for (let i = 0; i < span; i++) {
    if (show(m)) {
      vals.push(new Date(Date.UTC(y, m, 15)).toISOString().slice(0, 10));
      text.push(m === 0 ? MONTH_ABBR[m] + (TICK_ANGLE ? " " : "<br>") + "<b>" + y + "</b>" : MONTH_ABBR[m]);
    }
    if (++m > 11) { m = 0; y++; }
  }
  return { tickmode: "array", tickvals: vals, ticktext: text, tickangle: TICK_ANGLE };
}
/* The width of a plot's date axis in pixels: plotly's own figure once the
   plot is drawn, else the div's width less the margins. */
function axisPx(id){
  const gd = document.getElementById(id);
  if (!gd) return 0;
  const fl = gd._fullLayout;
  if (fl && fl.xaxis && fl.xaxis._length > 0) return fl.xaxis._length;
  return gd.clientWidth - PLOT_MARGIN_L - PLOT_MARGIN_R;
}
/* The window both panels show: the shared zoom if there is one, else the
   full window for the tab (see "the shared date window" above). */
const plotDateRange = () => winRange();
function dateAxis(){
  const r = plotDateRange();
  const base = { title: "", type: "date", gridcolor: "#eeece5", zeroline: false,
                 tickfont: { size: X_TICK_FONT }, range: r, autorange: false };
  const t = monthTicks(r[0], r[1], axisPx("plot"));
  return t ? { ...base, ...t } : base;
}
/* Re-letter a panel's axis after a zoom or a pan. Guarded per panel:
   relayout fires its own event, and without the flag this would call itself
   forever. */
const tickBusy = {};
function refreshMonthTicks(id){
  if (tickBusy[id]) return;
  const gd = document.getElementById(id);
  if (!gd || !gd.layout || !gd.layout.xaxis) return;
  const r = plotDateRange();
  const t = monthTicks(r[0], r[1], axisPx("plot"));
  if (!t) return;
  const cur = gd.layout.xaxis.ticktext || [];
  if (cur.length === t.ticktext.length && cur[0] === t.ticktext[0] &&
      cur[cur.length - 1] === t.ticktext[t.ticktext.length - 1]) return;
  tickBusy[id] = true;
  Plotly.relayout(gd, { "xaxis.tickmode": "array", "xaxis.tickvals": t.tickvals,
                        "xaxis.ticktext": t.ticktext })
        .then(() => { tickBusy[id] = false; }, () => { tickBusy[id] = false; });
}

function soilLayout(empty){
  const L = {
    hovermode: "closest",
    showlegend: true,
    legend: { orientation: "h", y: 1.08, x: 0, font: { size: 17 },
              itemclick: false, itemdoubleclick: false },
    paper_bgcolor: "#fff", plot_bgcolor: "#fff",
    font: { family: "-apple-system,Segoe UI,Helvetica,Arial,sans-serif", size: 17 },
    hoverlabel: { font: { size: 17 } },
    margin: { l: PLOT_MARGIN_L, r: PLOT_MARGIN_R, t: 16, b: X_MARGIN_B },
    xaxis: dateAxis(),
    yaxis: { title: { text: yTitle("field", TAB), font: { size: 17.5 } }, type: "linear",
             gridcolor: "#eeece5", zeroline: false },
    uirevision: keepZoom ? "sticky" : (TAB + "|" + wsFilter + "|" + depthFilter + "|" + ccFilter),
    annotations: []
  };
  if (empty) {
    L.xaxis.visible = false; L.yaxis.visible = false;
    L.annotations = [{ text: esc(emptyMessage()), xref: "paper", yref: "paper", x: 0.5, y: 0.5,
                       showarrow: false, font: { size: 19, color: "#6d6b64" } }];
  }
  return L;
}

/* both panels: watershed means (mplot) and field means (plot). A
   double-click autosizes, which bindX turns into a reset of the shared
   window. */
function drawPlot(){
  const cfg = { displaylogo: false, responsive: true, doubleClick: "autosize",
                modeBarButtonsToRemove: ["select2d", "lasso2d", "autoScale2d"] };
  const mg = document.getElementById("mplot"), gd = document.getElementById("plot");
  const oneStrip = meanDepths().length < 2;
  const resized = mg.classList.contains("one") !== oneStrip;
  mg.classList.toggle("one", oneStrip);
  const mt = meanTraces(TAB);
  const traces = soilTraces();
  const empty = !traces.some(t => t.meta);
  hideGuide("plot"); hideGuide("mplot");
  const drawn = Promise.all([
    Plotly.react(mg, mt, meanLayout(TAB, !mt.length), cfg)
      .then(() => { if (resized) return Plotly.Plots.resize(mg); }),
    Plotly.react(gd, traces, soilLayout(empty), cfg)
  ]).then(() => renderSummary());
  if (!gd._bound) {
    gd.on("plotly_click", ev => {
      const p = ev.points && ev.points[0];
      if (!p || p.customdata == null || !p.data || !p.data.meta) return;
      openPanel(p.customdata, String(p.data.meta).split("|")[1]);
    });
    bindX("plot");
    gd._bound = true;
  }
  if (!mg._bound) {
    mg.on("plotly_click", ev => {
      const p = ev.points && ev.points[0];
      if (!p || p.customdata == null || !p.data || !p.data.meta) return;
      openMeanPanel(p.customdata);
    });
    bindX("mplot");
    mg._bound = true;
  }
  return drawn;
}

/* ---------- field checkboxes ---------- */
function renderFields(){
  const listed = fieldsListed(), m = TAB;
  const hasPts = f => D.rows.some(r => r.fid === f.id && passFilters(r) && D.val[m][r.i] != null);
  let h = "";
  wsOnScreen().forEach(w => {
    const fs = listed.filter(f => f.ws === w);
    if (!fs.length) return;
    h += '<div class="wsgroup"><span class="wsn">' + esc(w) + '</span>' + fs.map(f => {
      const nd = !hasPts(f);
      return '<label class="fchk' + (nd ? ' nd' : '') + '" title="' + esc(f.full) +
             (nd ? ': no ' + esc(m) + ' points under the current filters' : '') + '">' +
             '<input type="checkbox" data-f="' + esc(f.id) + '"' + (HIDDEN.has(f.id) ? '' : ' checked') + '> ' +
             esc(f.label) + (nd ? ' <span class="ndnote">(no data)</span>' : '') + '</label>';
    }).join("") + '</div>';
  });
  const el = document.getElementById("fieldlist");
  el.innerHTML = h;
  el.querySelectorAll("input[data-f]").forEach(cb => {
    cb.onchange = () => {
      if (cb.checked) HIDDEN.delete(cb.dataset.f); else HIDDEN.add(cb.dataset.f);
      refresh();
    };
  });
  const nOn = listed.filter(f => !HIDDEN.has(f.id)).length;
  document.getElementById("fields-count").textContent = nOn + " of " + listed.length + " fields shown";
}
function showAllFields(){ fieldsListed().forEach(f => HIDDEN.delete(f.id)); return refresh(); }
function hideAllFields(){ fieldsListed().forEach(f => HIDDEN.add(f.id)); return refresh(); }

/* ---------- click-point side panel ---------- */
let PANEL = null;        /* { i, m } while open */
let pending = false;     /* switch flipped to OFF, waiting for the comment */

function openPanel(i, m){
  PANEL = { i: i, m: m };
  pending = false;
  document.getElementById("side").hidden = false;
  document.getElementById("scrim").hidden = false;
  renderPanel();
}
function closePanel(){
  PANEL = null; pending = false;
  document.getElementById("side").hidden = true;
  document.getElementById("scrim").hidden = true;
}

function metricRows(i, hi, attr){
  return TABS.map(k => {     /* tab order */
    const off = isOff(k, i);
    const val = off ? '<span class="was">' + cellText(k, i) + '</span>' : cellText(k, i);
    return '<tr class="clickable' + (k === hi ? " hi" : "") + '" ' + attr(k) + '>' +
           '<td>' + (k === hi ? "<b>" + esc(k) + "</b>" : esc(k)) + '</td>' +
           '<td class="num">' + val + '</td>' +
           '<td>' + (off ? '<span class="badge off">OFF</span>' : "") + '</td></tr>';
  }).join("");
}

/* a watershed mean: view-only. It lists the field points behind it, and a
   click opens one of those, which is where the review happens. */
function openMeanPanel(key){
  PANEL = { kind: "mean", key: key, m: TAB };
  pending = false;
  document.getElementById("side").hidden = false;
  document.getElementById("scrim").hidden = false;
  renderPanel();
}
function renderMeanPanel(){
  const m = PANEL.m, g = meanGroups(m).find(x => x.key === PANEL.key);
  const [ws, season, year, cc, depth] = PANEL.key.split("|");
  document.getElementById("side-title").textContent = ws + DOT + cc + DOT + depth + DOT + season + " " + year;
  const badge = document.getElementById("side-badge");
  badge.textContent = m + ": treatment mean by watershed";
  badge.className = "badge";
  let h;
  if (!g) {
    h = '<div class="sidesec"><div class="nodata">No ' + esc(m) + ' data for this campaign under the current filters.</div></div>';
  } else {
    h = '<div class="sidesec"><h3>Treatment mean by watershed</h3>' +
        '<b>' + fmt(g.mean) + PM + (g.sd == null ? DASH : fmt(g.sd)) + '</b> (n = ' + g.n +
        ' field' + (g.n === 1 ? '' : 's') + ')' +
        '<div>' + esc(season) + ' ' + year + ' campaign, sampled ' +
        (g.first === g.last ? g.first : g.first + ' to ' + g.last) +
        '; plotted at ' + g.x + ', the campaign\u2019s first sampling date.</div></div>';
    h += '<div class="sidesec"><h3>Field points in this mean</h3><table><tbody>' +
         g.rows.map(i => {
           const r = D.rows[i], off = isOff(m, i);
           return '<tr class="clickable" data-xi="' + i + '">' +
                  '<td>' + esc(FIELD.get(r.fid).label) + '</td><td>' + r.date + '</td>' +
                  '<td class="num">' + (off ? '<span class="was">' + cellText(m, i) + '</span>' : cellText(m, i)) + '</td>' +
                  '<td>' + (off ? '<span class="badge off">OFF, left out</span>' : '') + '</td></tr>';
         }).join("") +
         '</tbody></table><div style="margin-top:6px;color:var(--muted)">Click a field to open that point and review it.</div></div>';
  }
  h += '<div class="sidesec">This mean is worked out in the page from the field means in ' + esc(D.file) +
       ', leaving out points turned off. It is not a column of the file, so it has no switch of its own: ' +
       'review the field points instead.</div>';
  document.getElementById("side-body").innerHTML = h;
  document.querySelectorAll("#side-body tr[data-xi]").forEach(tr => {
    tr.onclick = () => openPanel(Number(tr.dataset.xi), m);
  });
}

function renderPanel(){
  if (!PANEL) return;
  if (PANEL.kind === "mean") { renderMeanPanel(); return; }
  const i = PANEL.i, m = PANEL.m, r = D.rows[i];
  document.getElementById("side-title").textContent = fullName(r) + DOT + r.depth + DOT + r.date;
  const badge = document.getElementById("side-badge");
  const state = !hasValue(m, i) ? "no data" : isOff(m, i) ? "OFF" : "ON";
  badge.textContent = m + ": " + state;
  badge.className = "badge" + (state === "OFF" ? " off" : state === "ON" ? " on" : "");

  let h = '<div class="sidesec"><h3>Treatment mean by field</h3>' +
          'Season <b>' + esc(r.season) + '</b>' + DOT +
          'Cover_crop_presence <b style="color:' + CC_COLOR[r.cc] + '">' + esc(r.cc) + '</b></div>';

  h += '<div class="sidesec"><h3>Every metric in this row</h3><table><tbody>' +
       metricRows(i, m, k => 'data-m="' + esc(k) + '"') +
       '</tbody></table>' +
       '<div style="margin-top:6px;color:var(--muted)">From ' + esc(D.file) +
       '. Each value is the field mean ' + PM.trim() + ' SD across transects, n = transects. ' +
       'Click a metric to review it for this row.</div></div>';

  /* the other depth, same field and date: read-only, a click opens it */
  const other = DEPTHS.filter(d => d !== r.depth);
  other.forEach(d => {
    const j = D.key.get(r.ws + "|" + r.date + "|" + r.site + "|" + d);
    h += '<div class="sidesec"><h3>Same field and date at ' + esc(d) + '</h3>';
    if (j == null) {
      h += '<div class="nodata">No ' + esc(d) + ' row for ' + esc(fullName(r)) + ' on ' + r.date + '.</div>';
    } else {
      h += '<table><tbody>' + metricRows(j, null, k => 'data-xm="' + esc(k) + '" data-xi="' + j + '"') +
           '</tbody></table><div style="margin-top:6px;color:var(--muted)">Click a row to open that point.</div>';
    }
    h += '</div>';
  });

  h += '<div class="sidesec"><h3>Review ' + esc(m) + ' for this row</h3>';
  if (!hasValue(m, i)) {
    h += '<div>' + esc(m) + ' has no data in this row, so there is nothing to turn off.</div>';
  } else if (isOff(m, i)) {
    const o = OFF[m][i], oc = offColumns(m);
    h += '<div class="toggle"><label class="sw2"><input type="checkbox" id="pt-switch">' +
         '<span class="sl"></span></label><b>OFF</b></div>' +
         '<div>Drawn as an x; the field\u2019s line skips it. In the reviewed download this row\u2019s ' +
         oc.cols.map(esc).join(", ") + ' are written ' + oc.toks.map(esc).join(", ") + '.</div>' +
         '<div style="margin-top:6px"><b>Why:</b> ' + esc(o.comment) + '</div>' +
         '<div style="color:var(--muted)">turned off ' + esc(o.ts) + '</div>' +
         '<div style="margin-top:6px;color:var(--muted)">Flip the switch to turn it back on.</div>';
    const others = D.metrics.filter(k => k !== m && isOff(k, i));
    if (others.length) {
      h += '<div class="row-actions"><button id="pt-all-on">turn every metric in this row back on (' +
           (others.length + 1) + ')</button></div>';
    }
  } else if (!pending) {
    h += '<div class="toggle"><label class="sw2"><input type="checkbox" id="pt-switch" checked>' +
         '<span class="sl"></span></label><b>ON</b></div>' +
         '<div style="color:var(--muted)">Flip the switch to turn this point off. You will be asked why.</div>';
  } else {
    const nOther = D.metrics.filter(k => k !== m && hasValue(k, i) && !isOff(k, i)).length;
    h += '<div class="toggle"><label class="sw2"><input type="checkbox" id="pt-switch" disabled>' +
         '<span class="sl"></span></label><b>turning OFF</b></div>' +
         '<label for="pt-comment"><b>Why is this point being turned off?</b> ' +
         '<span class="req">required</span></label>' +
         '<textarea class="comment" id="pt-comment" placeholder="e.g. lab rerun disagrees; checked the lab sheet"></textarea>' +
         (nOther ? '<label style="display:flex;gap:6px;align-items:center;margin-top:6px">' +
                   '<input type="checkbox" id="pt-allm"> also turn off every other metric in this row (' +
                   nOther + ') with the same comment</label>' : '') +
         '<div class="row-actions"><button class="primary" id="pt-save" disabled>turn off</button>' +
         '<button id="pt-cancel">cancel</button></div>';
  }
  h += '</div>';
  document.getElementById("side-body").innerHTML = h;

  document.querySelectorAll("#side-body tr[data-m]").forEach(tr => {
    tr.onclick = () => {
      const k = tr.dataset.m;
      PANEL.m = k; pending = false;
      if (k !== TAB) switchTo(k); else renderPanel();
    };
  });
  document.querySelectorAll("#side-body tr[data-xi]").forEach(tr => {
    tr.onclick = () => {
      const k = tr.dataset.xm, xi = Number(tr.dataset.xi);
      if (k !== TAB) switchTo(k);
      openPanel(xi, k);
    };
  });
  const sw = document.getElementById("pt-switch");
  if (sw && !sw.disabled) {
    sw.onchange = () => {
      if (isOff(m, i)) { turnOn(m, i); }
      else { pending = true; renderPanel(); const c = document.getElementById("pt-comment"); if (c) c.focus(); }
    };
  }
  const allOn = document.getElementById("pt-all-on");
  if (allOn) allOn.onclick = () => { D.metrics.forEach(k => { delete OFF[k][i]; }); refresh(); };
  const cm = document.getElementById("pt-comment");
  if (cm) {
    const save = document.getElementById("pt-save");
    cm.oninput = () => { save.disabled = !cm.value.trim(); };
    save.onclick = () => {
      const all = document.getElementById("pt-allm");
      if (turnOff(m, i, cm.value, !!(all && all.checked))) { pending = false; refresh(); }
    };
    document.getElementById("pt-cancel").onclick = () => { pending = false; renderPanel(); };
  }
}

/* The only two functions that change the review. A comment is required to
   turn a point off; turnOff refuses without one. */
function turnOff(m, i, comment, allMetrics){
  comment = String(comment || "").trim();
  if (!comment) return false;
  if (!OFF[m] || !hasValue(m, i)) return false;
  const ts = new Date().toISOString().replace(/\.\d{3}Z$/, "Z");
  const which = allMetrics ? D.metrics.filter(k => hasValue(k, i) && !isOff(k, i)) : [m];
  which.forEach(k => { OFF[k][i] = { comment: comment, ts: ts }; });
  saveState();
  return true;
}
function turnOn(m, i){
  delete OFF[m][i];
  refresh();
}

/* ---------- the list of points turned off ---------- */
function offEntries(){
  const out = [];
  D.metrics.forEach(m => Object.keys(OFF[m]).map(Number).sort((a, b) => a - b)
    .forEach(i => out.push({ m: m, i: i, o: OFF[m][i] })));
  return out;
}
function renderOffList(){
  const e = offEntries();
  document.getElementById("off-title").textContent = "Points turned off (" + e.length + ")";
  const el = document.getElementById("offlist");
  if (!e.length) {
    el.innerHTML = '<div class="empty">None yet. Click a point on the plot to review it.</div>';
    return;
  }
  el.innerHTML = '<div class="tablewrap"><table><thead><tr><th>Column</th><th>Watershed</th><th>Field</th>' +
    '<th>Depth</th><th>Date</th><th>Value in file</th><th>Comment</th><th>Turned off</th></tr></thead><tbody>' +
    e.map(x => {
      const r = D.rows[x.i];
      return '<tr class="clickable" data-m="' + esc(x.m) + '" data-i="' + x.i + '" title="reopen this point">' +
             '<td>' + esc(x.m) + '</td><td>' + esc(r.ws) + '</td><td>' + esc(FIELD.get(r.fid).label) + '</td>' +
             '<td>' + esc(r.depth) + '</td><td>' + r.date + '</td><td class="num">' + cellText(x.m, x.i) + '</td>' +
             '<td>' + esc(x.o.comment) + '</td><td style="white-space:nowrap">' + esc(x.o.ts) + '</td></tr>';
    }).join("") + '</tbody></table></div>' +
    '<div class="hint">Click a row to reopen it and switch it back on.</div>';
  el.querySelectorAll("tr[data-i]").forEach(tr => {
    tr.onclick = () => {
      const m = tr.dataset.m, i = Number(tr.dataset.i);
      if (m !== TAB) switchTo(m);
      openPanel(i, m);
    };
  });
}

/* ---------- series summary, live ----------
   One row per field x depth for the tab on screen, within the watershed,
   depth and cover crop filters, computed from the values in the file and
   leaving out points turned off, so it moves as the review goes. "shown"
   follows the field checkboxes. */

/* Significant figures rather than fixed decimals: these metrics span bulk
   density near 1 and calcium in the thousands in the same page. */
function fmt(v){
  if (v == null || !isFinite(v)) return DASH;
  const a = Math.abs(v);
  if (a === 0) return "0";
  if (a >= 1000) return v.toFixed(0);
  if (a >= 10)   return v.toFixed(1);
  if (a >= 1)    return v.toFixed(2);
  return v.toPrecision(3);
}
function median(a){
  if (!a.length) return null;
  const b = a.slice().sort((x, y) => x - y), h = b.length >> 1;
  return b.length % 2 ? b[h] : (b[h - 1] + b[h]) / 2;
}
/* a small marker drawn like the plot's: watershed shape, open for 5-20cm */
function swatch(depth, ws){
  const paint = DEPTH_OPEN[depth] ? ' fill="none" stroke="' + KEY_GREY + '" stroke-width="2"' : ' fill="' + KEY_GREY + '"';
  const shape = WS_SYMBOL[ws] === "triangle-up"
    ? '<polygon points="7,2 12.5,12 1.5,12"' + paint + '/>'
    : '<circle cx="7" cy="7" r="5"' + paint + '/>';
  return '<svg class="swatch" viewBox="0 0 14 14">' + shape + '</svg>';
}
function renderSummary(){
  const m = TAB;
  let h = '<div class="tablewrap"><table><thead><tr><th>series</th><th>cover crop</th><th>shown</th>' +
          '<th class="num">points</th><th class="num">median</th><th class="num">mean</th>' +
          '<th class="num">min</th><th class="num">max</th><th class="num">turned off</th>' +
          '</tr></thead><tbody>';
  let nRows = 0;
  FIELDS.forEach(f => DEPTHS.forEach(d => {
    const idx = D.rows.filter(r => r.fid === f.id && r.depth === d && passFilters(r) && D.val[m][r.i] != null)
                      .map(r => r.i);
    if (!idx.length) return;
    nRows++;
    const v = idx.filter(i => !isOff(m, i)).map(i => D.val[m][i]);
    const off = idx.length - v.length;
    const mean = v.length ? v.reduce((a, b) => a + b, 0) / v.length : null;
    const shown = !HIDDEN.has(f.id);
    const ccs = CC_LIST.filter(c => idx.some(i => D.rows[i].cc === c));
    h += '<tr' + (shown ? '' : ' style="color:var(--muted)"') + '>' +
         '<td style="white-space:nowrap">' + swatch(d, f.ws) + esc(f.full) + DOT + esc(d) + '</td>' +
         '<td>' + ccs.map(c => '<span style="color:' + (shown ? CC_COLOR[c] : "inherit") + '">' + esc(c) + '</span>').join(" / ") + '</td>' +
         '<td>' + (shown ? "yes" : "no") + '</td>' +
         '<td class="num">' + v.length + '</td>' +
         '<td class="num">' + fmt(median(v)) + '</td>' +
         '<td class="num">' + fmt(mean) + '</td>' +
         '<td class="num">' + fmt(v.length ? Math.min(...v) : null) + '</td>' +
         '<td class="num">' + fmt(v.length ? Math.max(...v) : null) + '</td>' +
         '<td class="num">' + (off || "") + '</td></tr>';
  }));
  if (!nRows) h += '<tr><td colspan="9" class="empty">No ' + esc(m) + ' data under these filters.</td></tr>';
  document.getElementById("summary").innerHTML = h + '</tbody></table></div>' +
    '<div class="hint">' + esc(m) + ': statistics of the field means in ' + esc(D.file) +
    ' for each field and depth within the watershed, depth and cover crop filters, leaving out points turned off. ' +
    '"points" counts sampling dates; "shown" follows the field checkboxes.</div>';
}

/* ---------- tabs, filters, refresh ---------- */
function renderTabs(){
  /* the tab text is the CSV column header, character for character */
  document.getElementById("tabs").innerHTML = TABS.map(t =>
    '<button class="tab' + (t === TAB ? " on" : "") + '" data-k="' + esc(t) + '">' + esc(t) + '</button>'
  ).join("");
  document.querySelectorAll(".tab").forEach(t => { t.onclick = () => switchTo(t.dataset.k); });
}

function metricSubtitle(){
  const rows = onScreen(TAB);
  if (!rows.length) return TAB + ": no data for this selection";
  const ds = rows.map(r => r.date).sort();
  const off = rows.filter(r => isOff(TAB, r.i)).length;
  const nf = new Set(rows.map(r => r.fid)).size;
  return TAB + DOT + rows.length + " points" + DOT + nf + " field" + (nf === 1 ? "" : "s") + DOT +
         ds[0] + " to " + ds[ds.length - 1] + DOT + "from " + D.file + (off ? DOT + off + " turned off" : "");
}

/* the figure captions above the two panels: what one point is, what the
   colours and shapes mean, and what the error bars are */
function meanCaption(){
  const two = meanDepths().length > 1;
  const err = errMode === "sd"
    ? "Error bars are " + PM.trim() + " 1 SD across fields; hover a point for n, the number of fields (a mean of one field has no SD)."
    : "Error bars are turned off; hover a point for its SD and n, the number of fields.";
  return "<b>" + capTitle("mean", TAB) + ".</b> Each point is the mean of the field means in one " +
         "watershed for one sampling campaign (one season\u2019s sampling, which can span several days; the point " +
         "sits at the campaign\u2019s first sampling date), averaged separately for fields under cover crop and no " +
         "cover crop" + (two ? ", with 0-5cm on top and 5-20cm below" : ", at " + esc(depthFilter)) + ". " +
         "Colour shows cover crop (light green = cover crop, dark brown = no cover crop) and marker shape shows " +
         "the watershed (circle = Shatto, triangle = Kirkpatrick); a filled marker is 0-5cm, an open one 5-20cm. " + err + " These means are worked out in this " +
         "page from the field means below, leave out points turned off, and ignore the field tick-boxes.";
}
function fieldCaption(){
  const err = errMode === "sd"
    ? "Error bars are " + PM.trim() + " 1 SD across transects; hover a point for n, the number of transects."
    : "Error bars are turned off; hover a point for its SD and n, the number of transects.";
  return "<b>" + capTitle("field", TAB) + ".</b> Each point is one field\u2019s mean across its transects " +
         "on one sampling date, at one depth, as recorded in " + esc(D.file) + ". Colour shows that row\u2019s " +
         "cover crop status (light green = cover crop, dark brown = no cover crop), marker shape the watershed " +
         "(circle = Shatto, triangle = Kirkpatrick), and a filled marker is 0-5cm, an open one 5-20cm. " + err +
         " Tick the fields above to choose which are drawn.";
}
function renderCaptions(){
  document.getElementById("mean-cap").innerHTML = meanCaption();
  document.getElementById("plot-cap").innerHTML = fieldCaption();
}

function writeHint(){
  const L = [];
  L.push("<b>Tabs</b> switch the measurement; each tab is a column of " + esc(D.file) +
         ". Each tab has two panels on one date axis: <b>treatment means by watershed</b> on top and " +
         "<b>treatment means by field</b> below.");
  L.push("<b>Both panels</b>: colour is cover crop (light green cover crop, dark brown no cover crop); " +
         "<b>marker shape</b> is the watershed (circle Shatto, triangle Kirkpatrick); a <b>filled</b> marker is " +
         "0-5cm, an <b>open</b> one 5-20cm. In the lower panel the colour is that row\u2019s own cover crop status. " +
         "Tick <b>connect each field\u2019s dates</b> for a grey line through one field\u2019s dates at one depth; " +
         "a field that changed cover crop status keeps one line.");
  L.push("<b>Fields</b>: tick or untick fields to choose what the treatment-means-by-field panel draws; the list " +
         "follows the watershed filter. The treatment means by watershed always use every field that passes the filters.");
  L.push("<b>Hover</b> a point for its value, SD and n; <b>click</b> a treatment mean by field to see every metric " +
         "for that row and the other depth, and to turn the point off, with a comment. Click a <b>treatment mean by " +
         "watershed</b> to list the field points behind it.");
  L.push("<b>Zoom</b> by dragging across either panel, and the other follows; double-click to go back to the whole record.");
  L.push("<b>Dates</b> run left to right by month " + DASH + " Jan and Jun, then all twelve once zoomed in " + DASH +
         " with the year beside January.");
  L.push("<b>Download reviewed data</b> writes " + esc(D.file) + " back with every OFF point\u2019s value, _SD and _n set to " +
         esc(NA_TOKEN) + "; <b>download review log</b> lists each OFF point with its comment.");
  document.getElementById("hint").innerHTML =
    L.map(s => '<div style="margin:2px 0">' + s + '</div>').join("");
}

function refresh(){
  renderTabs();
  renderFields();
  renderCaptions();
  writeHint();
  const drawn = drawPlot();
  renderOffList();
  document.getElementById("h-metric").textContent = metricSubtitle();
  if (PANEL) renderPanel();
  saveState();
  return drawn;
}

function switchTo(key){
  if (!TABS.includes(key)) return;
  TAB = key;
  if (!keepZoom) xWin = null;
  if (PANEL) PANEL.m = key;
  pending = false;
  return refresh();
}

/* set any of the dropdown filters at once (used by the headless test) */
function setFilters(f){
  if (f.ws != null)    { wsFilter = f.ws;       document.getElementById("sel-ws").value = wsFilter; }
  if (f.depth != null) { depthFilter = f.depth; document.getElementById("sel-depth").value = depthFilter; }
  if (f.cc != null)    { ccFilter = f.cc;       document.getElementById("sel-cc").value = ccFilter; }
  xWin = null;
  return refresh();
}

/* ---------- export: must round-trip ----------
   A reviewed download is the loaded file rebuilt from its own text: same
   columns, order, number text, NA token, dates, UTF-8 without BOM, and line
   endings. Only OFF points change: the value, _SD and _n become NA. */
function reviewedText(){
  const H = D.header, col = {};
  H.forEach((h, j) => { col[h] = j; });
  const lines = [H.join(",")];
  for (let i = 0; i < D.n; i++) {
    const cells = H.map(h => D.cols[h][i]);
    D.metrics.forEach(m => {
      if (!isOff(m, i)) return;
      const oc = offColumns(m);
      oc.cols.forEach((c, k) => { cells[col[c]] = oc.toks[k]; });
    });
    lines.push(cells.join(","));
  }
  return lines.join(D.eol) + (D.final_eol ? D.eol : "");
}

const csvEsc = v => {
  const s = String(v == null ? "" : v);
  return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
};
function reviewLogText(){
  const head = ["Watershed", "Sample_date", "Site_id", "Depth_cm", "Season", "Cover_crop_presence",
                "metric_column", "original_value", "original_SD", "original_n", "comment", "timestamp_utc"];
  const lines = [head.join(",")];
  offEntries().forEach(x => {
    const r = D.rows[x.i], C = D.cols;
    lines.push([r.ws, r.date, r.site, r.depth, r.season, r.cc, x.m,
                C[x.m][x.i], C[x.m + "_SD"][x.i], C[x.m + "_n"][x.i],
                x.o.comment, x.o.ts].map(csvEsc).join(","));
  });
  return lines.join("\n") + "\n";
}

function download(name, text){
  /* a string Blob is written as UTF-8 with no BOM */
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([text], { type: "text/csv;charset=utf-8" }));
  a.download = name;
  document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 400);
}

/* ---------- saved review (this browser only) ---------- */
const SKEY = "iwi_viewer::" + D.file + "::" + D.md5;
function saveState(){
  const n = offCount();
  document.getElementById("savestate").textContent =
    n ? n + " point" + (n === 1 ? "" : "s") + " off" + DOT + "saved in this browser" : "";
  try {
    localStorage.setItem(SKEY, JSON.stringify({
      off: OFF, tab: TAB, wsFilter: wsFilter, depthFilter: depthFilter, ccFilter: ccFilter,
      hidden: [...HIDDEN], errMode: errMode, showLines: showLines, keepZoom: keepZoom,
      when: new Date().toISOString()
    }));
  } catch (e) { /* storage unavailable; the page still works */ }
}
function loadState(){
  let s = null;
  try { s = JSON.parse(localStorage.getItem(SKEY) || "null"); } catch (e) { return; }
  if (!s) return;
  if (s.off) D.metrics.forEach(m =>
    Object.entries(s.off[m] || {}).forEach(([i, o]) => {
      i = Number(i);
      if (i >= 0 && i < D.n && hasValue(m, i) && o && String(o.comment || "").trim()) {
        OFF[m][i] = { comment: String(o.comment), ts: String(o.ts || "") };
      }
    }));
  if (TABS.includes(s.tab)) TAB = s.tab;
  if (s.wsFilter === "all" || WS_LIST.includes(s.wsFilter)) wsFilter = s.wsFilter;
  if (s.depthFilter === "all" || DEPTHS.includes(s.depthFilter)) depthFilter = s.depthFilter;
  if (s.ccFilter === "all" || CC_LIST.includes(s.ccFilter)) ccFilter = s.ccFilter;
  (s.hidden || []).forEach(id => { if (FIELD.has(id)) HIDDEN.add(id); });
  if (s.errMode === "sd" || s.errMode === "none") errMode = s.errMode;
  if (typeof s.showLines === "boolean") showLines = s.showLines;
  keepZoom = !!s.keepZoom;
}

/* ---------- wiring ---------- */
document.getElementById("h-banner").textContent = DATA.title;
(function writeSub(){
  const all = D.rows.map(r => r.date).sort();
  document.getElementById("h-sub").textContent =
    "Loaded file: " + D.file + " (" + D.n + " rows)" + DOT +
    all[0] + " to " + all[all.length - 1] + DOT +
    D.metrics.length + " metrics" + DOT +
    FIELDS.length + " fields (" + WS_LIST.map(w => w + " " + FIELDS.filter(f => f.ws === w).length).join(", ") + ")" + DOT +
    "built " + DATA.built;
})();

document.getElementById("sel-ws").innerHTML = '<option value="all">All</option>' +
  WS_LIST.map(w => '<option value="' + esc(w) + '">' + esc(w) + '</option>').join("");
document.getElementById("sel-depth").innerHTML = '<option value="all">All depths</option>' +
  DEPTHS.map(d => '<option value="' + esc(d) + '">' + esc(d) + '</option>').join("");
document.getElementById("sel-cc").innerHTML = '<option value="all">All</option>' +
  CC_LIST.map(c => '<option value="' + esc(c) + '">' + esc(c) + '</option>').join("");

loadState();

/* a filter changes the full date window, so it also clears the zoom */
document.getElementById("sel-ws").onchange = e => { wsFilter = e.target.value; xWin = null; refresh(); };
document.getElementById("sel-depth").onchange = e => { depthFilter = e.target.value; xWin = null; refresh(); };
document.getElementById("sel-cc").onchange = e => { ccFilter = e.target.value; xWin = null; refresh(); };
document.getElementById("sel-err").onchange = e => { errMode = e.target.value; drawPlot(); renderCaptions(); saveState(); };
document.getElementById("cb-lines").onchange = e => { showLines = e.target.checked; drawPlot(); saveState(); };
document.getElementById("cb-keepzoom").onchange = e => { keepZoom = e.target.checked; drawPlot(); saveState(); };
document.getElementById("btn-resetzoom").onclick = resetZoom;
document.getElementById("btn-fields-all").onclick = showAllFields;
document.getElementById("btn-fields-none").onclick = hideAllFields;
document.getElementById("btn-dl-data").onclick = () => download(DATA.names.data, reviewedText());
document.getElementById("btn-dl-log").onclick = () => download(DATA.names.log, reviewLogText());
document.getElementById("btn-clear-saved").onclick = () => {
  if (offCount() && !confirm("Turn every point back on and forget the comments saved in this browser?")) return;
  D.metrics.forEach(m => { OFF[m] = {}; });
  try { localStorage.removeItem(SKEY); } catch (e) {}
  refresh();
};
document.getElementById("side-close").onclick = closePanel;
document.getElementById("scrim").onclick = closePanel;
document.addEventListener("keydown", e => { if (e.key === "Escape") closePanel(); });

document.getElementById("sel-ws").value = wsFilter;
document.getElementById("sel-depth").value = depthFilter;
document.getElementById("sel-cc").value = ccFilter;
document.getElementById("sel-err").value = errMode;
document.getElementById("cb-lines").checked = showLines;
document.getElementById("cb-keepzoom").checked = keepZoom;

refresh();

/* hooks for the headless round-trip test (work/03_roundtrip.R) */
window.IWI = { reviewedText, reviewLogText, turnOff, turnOn, openPanel, switchTo, setFilters,
               showAllFields, hideAllFields, drawPlot, monthTicks, offCount, D, TABS, FIELDS, HIDDEN,
               meanGroups, openMeanPanel, resetZoom, fullRange, meanCaption, fieldCaption,
               winRange: () => winRange() };
</script>
</body>
</html>
]---"

html <- TEMPLATE |>
  fill("/*__PLOTLYJS__*/", plotly_js) |>
  fill("/*__DATA__*/", json)
html_path <- file.path(pkg_dir, html_file)
writeBin(charToRaw(enc2utf8(html)), html_path)

# =============================================================================
# Stage 6. Verification
# =============================================================================
written <- read_file(html_path)
json_back <- regmatches(written, regexpr("(?s)/\\*__DATA_START__\\*/.*?/\\*__DATA_END__\\*/",
                                         written, perl = TRUE))
json_back <- sub("^/\\*__DATA_START__\\*/", "", sub("/\\*__DATA_END__\\*/$", "", json_back))
emb <- fromJSON(json_back, simplifyVector = FALSE)

# every key anywhere in the embedded JSON must be a CSV header or structural (rule 1)
all_keys <- function(x) {
  if (!is.list(x)) return(character())
  c(names(x), unlist(lapply(x, all_keys), use.names = FALSE))
}
emb_keys   <- unique(all_keys(emb))
extra_cols <- setdiff(emb_keys, c(names(soil$df), structural_keys))
if (length(extra_cols)) stop("Embedded JSON has columns that are not in the EDI CSV: ",
                             paste(extra_cols, collapse = ", "))

# embedded columns == header, same row count, and what the page's reviewed
# download writes with nothing turned off -- rebuilt the same way from the
# embedded text -- must equal the file byte for byte
d <- emb$dataset
if (!identical(names(d$columns), names(soil$df))) stop(data_file, ": embedded columns differ from the CSV header.")
emb_rows <- length(d$columns[[1]])
if (emb_rows != nrow(soil$df)) stop("Embedded row count differs from the CSV.")
no_toggle <- paste0(
  paste(c(paste(unlist(d$header), collapse = ","),
          do.call(paste, c(unname(map(d$columns, unlist)), sep = ","))),
        collapse = d$eol),
  if (isTRUE(d$final_eol)) d$eol else "")
byte_identical <- identical(charToRaw(enc2utf8(no_toggle)), soil$bytes)
if (!byte_identical) stop(data_file, ": rebuilding the CSV from the embedded data does not match the file.")

# spelled-out names only (rule 5), and no leftover typo
abbrev <- grepl("\\b(SDW|KDW|NoCC|CC|Kikpatrick)\\b", c(TEMPLATE, json), perl = TRUE)
if (any(abbrev)) stop("An abbreviation (SDW/KDW/CC/NoCC) or 'Kikpatrick' is in the page.")

fields.df <- soil$df |> distinct(Watershed, Site_id) |> count(Watershed)
cat("\n==== IWI soil visualizer: verification ====\n")
cat(sprintf("Data file        : %s  (md5 %s)\n", data_file, soil$md5))
cat(sprintf("  rows x columns : %d x %d  (embedded: %d rows, %d columns)\n",
            nrow(soil$df), ncol(soil$df), emb_rows, length(d$columns)))
cat(sprintf("  unedited export rebuilds the file byte for byte: %s\n", byte_identical))
cat(sprintf("Metric tabs      : %s\n", paste(tab_order, collapse = ", ")))
cat(sprintf("Y-axis titles    : %d of %d metrics\n", sum(metrics %in% names(emb$labels)), length(metrics)))
cat(sprintf("Fields           : %s\n", paste(fields.df$Watershed, fields.df$n, collapse = ", ")))
cat(sprintf("Depths           : %s\n", paste(unique(soil$df$Depth_cm), collapse = ", ")))
cat(sprintf("Sample dates     : %s to %s\n", min(soil$df$Sample_date), max(soil$df$Sample_date)))
cat(sprintf("Extra columns in embedded JSON (must be none): %s\n",
            if (length(extra_cols)) paste(extra_cols, collapse = ", ") else "none"))
cat(sprintf("HTML written     : %s (%.1f MB)\n", normalizePath(html_path), file.size(html_path) / 1e6))
