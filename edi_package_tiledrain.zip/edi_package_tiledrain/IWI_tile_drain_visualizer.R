# =============================================================================
# IWI_tile_drain_visualizer.R
# Indiana Watershed Initiative (IWI): Tile Drain Data Visualizer
#
# Rebuilds IWI_tile_drain_visualizer.html from the CSVs that sit next to this
# script. The page is one self-contained file (plotly.js inlined) that works
# offline. Use it to QA/QC the data:
#   1. open the .html, click a point, turn it OFF with a comment
#   2. "download reviewed data" -> a CSV with exactly this file's layout, the
#      turned-off points written as NA,NA,0 (value, SD, n)
#   3. put that CSV next to this script, name it in `data_file` below, rerun
#
# Reads only:  the data file below + the two outlet discharge/precip files
# Writes only: IWI_tile_drain_visualizer.html (same folder)
#
# Packages: readr, dplyr, purrr, jsonlite, plotly (plotly only for its copy
# of plotly.js, which is inlined into the page).
# =============================================================================

# ---- CONFIG -----------------------------------------------------------------
data_file <- "IWI_tile_drain_data.csv"   # <- the data file; drop a reviewed download in here
# -----------------------------------------------------------------------------

# Normally unchanged: the outlet files, the page, and the download names.
outlet_files <- c(
  Shatto      = "IWI_shatto_outlet_discharge_precip.csv",
  Kirkpatrick = "IWI_kirkpatrick_outlet_discharge_precip.csv"
)
html_file      <- "IWI_tile_drain_visualizer.html"
reviewed_name  <- "IWI_tile_drain_data_reviewed.csv"
log_name       <- "IWI_tile_drain_review_log.csv"
page_title     <- "Indiana Watershed Initiative (IWI): Tile Drain Data Visualizer"

# Y-axis titles, spelled out as they would be in a paper. The tabs keep the
# CSV column headers; only the axis titles and the captions use these.
# <sub>/<sup> render in both plotly and the HTML caption.
axis_labels <- c(
  Q_Ls      = "Tile drain discharge (L/s)",
  NO3N_mgL  = "Nitrate concentration (mg NO<sub>3</sub><sup>\u2212</sup>-N/L)",
  NO3N_mgs  = "Nitrate flux (mg NO<sub>3</sub><sup>\u2212</sup>-N/s)",
  NH4N_ugL  = "Ammonium concentration (\u00b5g NH<sub>4</sub><sup>+</sup>-N/L)",
  NH4N_ugs  = "Ammonium flux (\u00b5g NH<sub>4</sub><sup>+</sup>-N/s)",
  SRP_ugL   = "Soluble reactive phosphorus concentration (\u00b5g P/L)",
  SRP_ugs   = "Soluble reactive phosphorus flux (\u00b5g P/s)",
  Turb_NTU  = "Turbidity (NTU)",
  Cond_uScm = "Specific conductance (\u00b5S/cm)",
  Temp_C    = "Water temperature (\u00b0C)",
  pH        = "pH"
)
# What one point is, in front of every y-axis title: "<prefix>:<br><title>".
# Each row is the mean of the tile drains under one treatment (cover crop or
# no cover crop) in one watershed on one date.
axis_prefix <- "Treatment mean by watershed"
outlet_axis_labels <- c(q_ls = "Stream discharge (L/s)", precip_cm = "Precipitation (cm)")

# How this file records a missing metric: value and SD are the NA token and
# n is 0. A point turned OFF in the page is written the same way.
na_token  <- "NA"
missing_n <- "0"

# Harmonized vocabulary (CLAUDE.md rule 6). Anything else stops the build.
key_cols      <- c("Project", "Watershed", "Sample_date", "Cover_crop_presence")
watersheds    <- c("Shatto", "Kirkpatrick")
cover_crops   <- c("cover crop", "no cover crop")
outlet_header <- c("date", "q_ls", "precip_cm")

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(purrr)
  library(jsonlite)
})
if (!requireNamespace("plotly", quietly = TRUE)) {
  stop("The plotly package is needed for its copy of plotly.js: install.packages(\"plotly\")")
}

# =============================================================================
# Stage 1. Find this script's folder, so getwd() doesn't matter
# =============================================================================
script_dir <- function() {
  a <- grep("^--file=", commandArgs(FALSE), value = TRUE)
  if (length(a)) return(dirname(normalizePath(sub("^--file=", "", a[1]))))
  for (i in rev(seq_len(sys.nframe()))) {          # source("...")
    f <- sys.frame(i)$ofile
    if (!is.null(f)) return(dirname(normalizePath(f)))
  }
  if (requireNamespace("rstudioapi", quietly = TRUE) && rstudioapi::isAvailable()) {
    p <- rstudioapi::getSourceEditorContext()$path  # Run in Positron/RStudio
    if (nzchar(p)) return(dirname(normalizePath(p)))
  }
  stop("Can't tell where this script lives. Run it with Rscript or source() it.")
}
pkg_dir <- script_dir()

# =============================================================================
# Stage 2. Read a CSV exactly as text
# Every cell stays the string that is in the file ("0.300" stays "0.300"), so
# the page can write the file back byte for byte. The reader proves that by
# rebuilding the file from its cells and comparing bytes.
# =============================================================================
read_exact <- function(file) {
  path <- file.path(pkg_dir, file)
  if (!file.exists(path)) stop("File not found next to the script: ", file)
  bytes <- readBin(path, "raw", file.size(path))
  if (length(bytes) >= 3 && identical(bytes[1:3], as.raw(c(0xEF, 0xBB, 0xBF)))) {
    stop(file, " starts with a byte-order mark (BOM). Save it as UTF-8 without a BOM.")
  }
  txt <- rawToChar(bytes)
  Encoding(txt) <- "UTF-8"
  if (!validUTF8(txt)) stop(file, " is not valid UTF-8.")
  if (grepl('"', txt, fixed = TRUE)) {
    stop(file, " contains quote characters; this script expects an unquoted CSV.")
  }
  eol <- if (grepl("\r\n", txt, fixed = TRUE)) "\r\n" else "\n"

  cells.df <- read_csv(I(txt), col_types = cols(.default = col_character()),
                       na = character(), quote = "", trim_ws = FALSE,
                       skip_empty_rows = FALSE, progress = FALSE)
  final_eol <- endsWith(txt, eol)
  rebuilt <- paste0(
    paste(c(paste(names(cells.df), collapse = ","),
            do.call(paste, c(unname(as.list(cells.df)), sep = ","))),
          collapse = eol),
    if (final_eol) eol else "")
  if (!identical(charToRaw(enc2utf8(rebuilt)), bytes)) {
    stop(file, " does not rebuild byte for byte from its cells ",
         "(mixed line endings, blank lines, or ragged rows?).")
  }
  list(df = cells.df, eol = eol, final_eol = final_eol,
       md5 = unname(tools::md5sum(path)), bytes = bytes)
}

# =============================================================================
# Stage 3. The tile drain data: check the layout and the vocabulary
# =============================================================================
dat <- read_exact(data_file)
data.df <- dat$df
header <- names(data.df)

if (!identical(header[1:4], key_cols)) {
  stop("The first four columns must be: ", paste(key_cols, collapse = ", "))
}
# every metric is a triple X, X_SD, X_n, in that order
metric_cols <- header[-(1:4)][c(TRUE, FALSE, FALSE)]
expected <- as.vector(rbind(metric_cols, paste0(metric_cols, "_SD"), paste0(metric_cols, "_n")))
if (!identical(header[-(1:4)], expected)) {
  stop("After the key columns every metric must be a triple X, X_SD, X_n. Got: ",
       paste(header[-(1:4)], collapse = ", "))
}
no_label <- setdiff(metric_cols, names(axis_labels))
if (length(no_label)) stop("Add a y-axis title to `axis_labels` for: ", paste(no_label, collapse = ", "))

bad_ws <- setdiff(unique(data.df$Watershed), watersheds)
if (length(bad_ws)) stop("Watershed values must be Shatto or Kirkpatrick. Found: ", paste(bad_ws, collapse = ", "))
bad_cc <- setdiff(unique(data.df$Cover_crop_presence), cover_crops)
if (length(bad_cc)) stop("Cover_crop_presence must be 'cover crop' or 'no cover crop'. Found: ", paste(bad_cc, collapse = ", "))
bad_date <- data.df$Sample_date[is.na(as.Date(data.df$Sample_date, format = "%Y-%m-%d")) |
                                  !grepl("^\\d{4}-\\d{2}-\\d{2}$", data.df$Sample_date)]
if (length(bad_date)) stop("Sample_date must be YYYY-MM-DD. Found: ", paste(head(bad_date), collapse = ", "))
if (anyDuplicated(data.df[key_cols[-1]])) stop("Watershed x Sample_date x Cover_crop_presence must be unique.")

is_num_text <- function(x) grepl("^-?(\\d+\\.?\\d*|\\.\\d+)([eE][-+]?\\d+)?$", x)
walk(metric_cols, \(m) {
  v <- data.df[[m]]; s <- data.df[[paste0(m, "_SD")]]; n <- data.df[[paste0(m, "_n")]]
  if (!all(v == na_token | is_num_text(v))) stop(m, ": values must be numbers or ", na_token)
  if (!all(s == na_token | is_num_text(s))) stop(m, "_SD: values must be numbers or ", na_token)
  if (!all(grepl("^\\d+$", n))) stop(m, "_n: values must be whole numbers")
  odd <- sum(v == na_token & (s != na_token | n != missing_n))
  if (odd) warning(m, ": ", odd, " rows have no value but an SD or a non-zero n")
})

# =============================================================================
# Stage 4. The outlet discharge / precipitation files (context panel)
# Precip is already in cm in the file and is plotted as-is.
# =============================================================================
outlets <- imap(outlet_files, \(file, ws) {
  o <- read_exact(file)
  if (!identical(names(o$df), outlet_header)) {
    stop(file, ": columns must be ", paste(outlet_header, collapse = ", "))
  }
  if (anyNA(as.Date(o$df$date, format = "%Y-%m-%d"))) stop(file, ": dates must be YYYY-MM-DD")
  list(watershed = unbox(ws), file = unbox(file), header = outlet_header,
       columns = as.list(o$df))
}) |> unname()

# =============================================================================
# Stage 5. Embed: only the CSVs' own rows and columns (CLAUDE.md rule 1)
# Columns go in as the file's text; the page parses numbers for plotting and
# writes the text back out for the reviewed download.
# =============================================================================
page_data <- list(
  title       = unbox(page_title),
  source_file = unbox(data_file),
  source_md5  = unbox(dat$md5),
  built       = unbox(format(Sys.time(), "%Y-%m-%d %H:%M")),
  eol         = unbox(dat$eol),
  final_eol   = unbox(dat$final_eol),
  na_token    = unbox(na_token),
  missing_n   = unbox(missing_n),
  names       = list(reviewed = unbox(reviewed_name), log = unbox(log_name)),
  metrics     = metric_cols,
  labels      = map(as.list(axis_labels[metric_cols]), unbox),
  axis_prefix = unbox(axis_prefix),
  outlet_labels = map(as.list(outlet_axis_labels), unbox),
  header      = header,
  columns     = as.list(data.df),
  outlets     = outlets
)
# the structural keys above; everything else in the JSON must be a CSV header
structural_keys <- c(names(page_data), "reviewed", "log", "watershed", "file")

json <- toJSON(page_data, auto_unbox = FALSE, digits = NA)
json <- gsub("</", "<\\/", json, fixed = TRUE)   # never close the <script> early

# =============================================================================
# Stage 6. Fill the template and write the page
# =============================================================================
fill <- function(x, key, value) {
  i <- regexpr(key, x, fixed = TRUE)
  if (i < 0) stop("Template placeholder missing: ", key)
  paste0(substr(x, 1, i - 1), value, substr(x, i + nchar(key), nchar(x)))
}
plotly_path <- system.file("htmlwidgets/lib/plotlyjs/plotly-latest.min.js", package = "plotly")
if (!nzchar(plotly_path)) stop("plotly.js not found inside the installed plotly package.")
plotly_js <- read_file(plotly_path)

TEMPLATE <- r"---[<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>IWI Tile Drain Data Visualizer</title>
<script>/*__PLOTLYJS__*/</script>
<style>
  /* ---- palette and base (shared by all three IWI viewers) ---- */
  :root{
    --ink:#0b0b0b; --ink2:#52514e; --muted:#898781;
    --line:#e1e0d9; --surface:#ffffff; --surface2:#faf9f6;
    --good:#1d6b3f; --off:#b1560f; --hi:#fff8dc;
  }
  *{box-sizing:border-box}
  body{margin:0;padding:0 24px 80px;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Helvetica,Arial,sans-serif;
       color:var(--ink);background:var(--surface2);font-size:19px;line-height:1.5}
  header{position:sticky;top:0;z-index:50;background:var(--surface2);border-bottom:1px solid var(--line);
         padding:12px 0 8px}
  .banner{font-size:34px;font-weight:600;line-height:1.2;color:var(--ink);margin:0;padding:18px 0 6px}
  h1{font-size:24px;font-weight:500;margin:0 0 3px}
  h2{font-size:20px;font-weight:500;margin:26px 0 10px;padding-bottom:6px;border-bottom:1px solid var(--line)}
  .sub{color:var(--ink2);font-size:18px;margin:0}
  .controls{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:9px}
  .controls label{font-size:17.5px;color:var(--ink2);display:flex;align-items:center;gap:5px}
  button{font:inherit;font-size:18px;padding:6px 12px;border:1px solid #c3c2b7;background:var(--surface);
         border-radius:6px;cursor:pointer;color:var(--ink)}
  button:hover{background:var(--surface2)}
  button.primary{border-color:#8a8a7e;font-weight:500}
  button:disabled{opacity:.45;cursor:default}
  select{font:inherit;font-size:18px;padding:5px 8px;border:1px solid #c3c2b7;border-radius:6px;background:var(--surface)}
  input[type=checkbox]{width:19px;height:19px;cursor:pointer}

  /* ---- metric tabs: the tab text is the CSV column header ---- */
  .tabs{display:flex;gap:4px;align-items:flex-end;margin:10px 0 0;flex-wrap:wrap}
  .tab{font:inherit;font-size:18.5px;padding:7px 15px;border:1px solid var(--line);border-bottom:none;
       background:var(--surface2);border-radius:8px 8px 0 0;cursor:pointer;color:var(--ink2)}
  .tab:hover{background:var(--surface)}
  .tab.on{background:var(--surface);color:var(--ink);font-weight:500;box-shadow:inset 0 3px 0 var(--ink)}
  .tabsrule{border-bottom:1px solid var(--line);margin-bottom:2px}

  .wrap{max-width:1600px;margin:0 auto}
  .card{background:var(--surface);border:1px solid var(--line);border-radius:10px;margin:16px 0;overflow:hidden}
  .plotwrap{padding:10px 6px 12px}
  .plot{width:100%;height:640px}
  .hint{font-size:17px;color:var(--muted);padding:6px 14px 10px}
  .empty{padding:14px;color:var(--muted);font-size:17.5px}
  .badge{font-size:16.5px;padding:1px 8px;border-radius:20px;border:1px solid var(--line);color:var(--ink2);
         background:var(--surface2)}
  .badge.on{color:var(--good);border-color:#cfe3d6;background:#f2f8f4}
  .badge.off{color:var(--off);border-color:#f0cfb4;background:#fdf3ea}

  table{border-collapse:collapse;width:100%;font-size:17.5px;font-variant-numeric:tabular-nums}
  th{position:sticky;top:0;background:var(--surface);text-align:left;font-weight:500;color:var(--ink2);
     padding:7px 8px;border-bottom:1px solid var(--line);white-space:nowrap}
  td{padding:5px 8px;text-align:left;border-bottom:1px solid #f2f1ec;vertical-align:top}
  td.num,th.num{text-align:right;white-space:nowrap}
  .swatch{display:inline-block;width:12px;height:12px;margin-right:7px;vertical-align:middle}
  tr.hi{background:var(--hi)}
  tr.clickable{cursor:pointer}
  tr.clickable:hover{background:var(--surface2)}
  tr.hi.clickable:hover{background:var(--hi)}
  .tablewrap{max-height:420px;overflow:auto}

  /* ---- outlet discharge + precipitation panel ---- */
  .ctxwrap{padding:8px 6px 0;border-bottom:1px solid var(--line)}
  .ctxwrap[hidden]{display:none!important}
  .ctxhead{display:flex;gap:6px 14px;align-items:center;flex-wrap:wrap;font-size:17.5px;
           color:var(--ink2);padding:0 8px 2px}
  .ctxhead b{color:var(--ink);font-weight:500}
  .ctxkey{display:inline-flex;align-items:center;gap:5px;font-size:17px}
  .ctxkey i{display:inline-block;flex:none}
  .ctxplot{width:100%;height:240px}
  .card.withctx .plot{height:520px}
  .pwrap{position:relative}
  /* figure captions: a full sentence above each panel, as in a paper */
  .figcap{font-size:17.5px;color:var(--ink2);padding:10px 14px 0;max-width:1400px}
  .figcap b{color:var(--ink);font-weight:600}
  .ctxwrap .figcap{padding:0 8px 4px}
  .guide{position:absolute;width:0;border-left:1px dashed #6d6b64;pointer-events:none;display:none;z-index:5}

  /* ---- click-point side panel ---- */
  .side{position:fixed;right:0;top:0;bottom:0;width:700px;max-width:96vw;z-index:80;
        background:var(--surface);border-left:1px solid var(--line);
        box-shadow:-3px 0 18px rgba(0,0,0,.09);display:flex;flex-direction:column}
  .side[hidden]{display:none!important}
  .sidehead{padding:12px 16px;border-bottom:1px solid var(--line);display:flex;align-items:baseline;
            gap:10px;flex-wrap:wrap}
  .sidehead .t{font-size:20px;font-weight:500}
  .sidebody{overflow:auto;padding:0 0 20px}
  .sidesec{padding:10px 16px;border-bottom:1px solid var(--line);font-size:17.5px;color:var(--ink2)}
  .sidesec b{color:var(--ink);font-weight:500}
  .sidesec h3{font-size:17.5px;font-weight:600;color:var(--ink);margin:0 0 6px}
  .side table{font-size:17.5px}
  .side td{padding:4px 8px}
  .closebtn{margin-left:auto;font-size:17px;padding:4px 10px}
  .scrim{position:fixed;inset:0;background:rgba(0,0,0,.12);z-index:70}
  .scrim[hidden]{display:none!important}
  .nodata{color:var(--muted);font-style:italic}
  .was{color:var(--muted);text-decoration:line-through}

  /* ---- the ON/OFF switch and the required comment ---- */
  .toggle{display:flex;align-items:center;gap:10px;margin:4px 0 8px}
  .sw2{position:relative;display:inline-block;width:40px;height:22px;vertical-align:middle;flex:none}
  .sw2 input{opacity:0;width:0;height:0;position:absolute}
  .sw2 .sl{position:absolute;inset:0;background:#cfcdc4;border-radius:22px;transition:background .12s;cursor:pointer}
  .sw2 .sl:before{content:"";position:absolute;height:18px;width:18px;left:2px;top:2px;background:#fff;
                  border-radius:50%;transition:transform .12s;box-shadow:0 1px 2px rgba(0,0,0,.25)}
  .sw2 input:checked + .sl{background:var(--good)}
  .sw2 input:checked + .sl:before{transform:translateX(18px)}
  .sw2 input:disabled + .sl{opacity:.4;cursor:default}
  textarea.comment{width:100%;min-height:64px;font:inherit;font-size:18px;padding:6px 8px;
                   border:1px solid #c3c2b7;border-radius:6px;resize:vertical}
  .req{color:var(--off);font-size:17px}
  .row-actions{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:8px}
</style>
</head>
<body>
<div class="wrap">
<p class="banner" id="h-banner"></p>
<header>
  <p class="sub" id="h-sub"></p>
  <div class="tabs" id="tabs"></div>
  <div class="tabsrule"></div>
  <div class="controls">
    <label>watershed <select id="sel-ws"></select></label>
    <label>cover crop <select id="sel-cc"></select></label>
    <label>error bars
      <select id="sel-err">
        <option value="sd">&plusmn; SD</option>
        <option value="none">none</option>
      </select>
    </label>
    <label id="wrap-ctx" title="daily discharge and precipitation at the watershed outlet, above the plot">
      <input type="checkbox" id="cb-ctx" checked> outlet Q &amp; precip
    </label>
    <label><input type="checkbox" id="cb-keepzoom"> keep zoom when switching tabs</label>
    <button id="btn-resetzoom">reset zoom</button>
    <span style="width:8px"></span>
    <button id="btn-dl-reviewed" class="primary">download reviewed data (.csv)</button>
    <button id="btn-dl-log">download review log (.csv)</button>
    <span style="width:8px"></span>
    <span id="savestate" style="font-size:17px;color:var(--muted)"></span>
    <button id="btn-clear-saved" style="font-size:17px;padding:4px 9px">clear saved review</button>
  </div>
  <p class="sub" id="h-metric" style="margin-top:6px"></p>
</header>

<div class="card" id="plotcard">
  <div class="ctxwrap" id="ctxwrap" hidden>
    <div class="figcap" id="ctx-cap"></div>
    <div class="ctxhead">
      <span id="ctx-keys" style="display:inline-flex;gap:6px 14px;flex-wrap:wrap"></span>
      <span style="flex:1"></span>
      <span id="ctx-src" style="color:var(--muted);font-size:17px"></span>
    </div>
    <div class="pwrap" id="ctx-area"><div class="ctxplot" id="ctx"></div><div class="guide" id="guide-ctx"></div></div>
  </div>
  <div class="figcap" id="plot-cap"></div>
  <div class="plotwrap"><div class="pwrap"><div class="plot" id="plot"></div><div class="guide" id="guide-plot"></div></div></div>
  <div class="hint" id="hint"></div>
</div>

<h2 id="off-title">Points turned off</h2>
<div class="card" id="offlist"></div>

<h2>series summary &mdash; live</h2>
<div class="card" id="summary"></div>
</div>

<div class="scrim" id="scrim" hidden></div>
<aside class="side" id="side" hidden>
  <div class="sidehead">
    <span class="t" id="side-title"></span>
    <span class="badge" id="side-badge"></span>
    <button class="closebtn" id="side-close">close</button>
  </div>
  <div class="sidebody" id="side-body"></div>
</aside>

<script>
const DATA = /*__DATA_START__*/ /*__DATA__*/ /*__DATA_END__*/;

/* ====================================================================
   IWI DATA VISUALIZER -- tile drain

   The page carries the EDI CSV and nothing else: DATA.columns is the file,
   column by column, as the TEXT that is in the file. Numbers are parsed
   from that text for plotting; the reviewed download writes the text back,
   so with nothing turned off it is byte-identical to the file.

   A POINT is one row (Watershed x Sample_date x Cover_crop_presence) within
   one metric column. Turning a point OFF needs a comment. An OFF point is
   drawn as an x, and in the reviewed download its value and SD become the
   NA token and its n becomes 0 -- the way the file already records a
   missing metric.

   GLOBAL across tabs: watershed filter, cover crop filter, error-bar mode,
   the outlet panel, keep-zoom, and every OFF point with its comment. All of
   it is saved in this browser, keyed to the data file's md5, so a different
   file never inherits an old review.
   ==================================================================== */

const H = DATA.header, COLS = DATA.columns;
const NROW = COLS[H[0]].length;
const METRICS = DATA.metrics;                /* the value columns, CSV order */
const NA_TOKEN = DATA.na_token, MISSING_N = DATA.missing_n;
let M = METRICS[0];

/* Cover crop is the colour, watershed is the marker shape. These two
   colours are the shared IWI cover crop colours for all three viewers:
   one light and bright, one dark and dull, so they differ in tone and not
   just in hue (lab manager, 2026-09-24). */
const CC_COLOR  = { "cover crop": "#7DC24B", "no cover crop": "#4A3526" };
const WS_SYMBOL = { "Shatto": "circle", "Kirkpatrick": "triangle-up" };
const POINT_SIZE = 8;

const esc = s => String(s == null ? "" : s)
  .replace(/&/g,"&amp;").replace(/"/g,"&quot;")
  .replace(/</g,"&lt;").replace(/>/g,"&gt;");
const num = s => (s == null || s === "" || s === NA_TOKEN) ? null : Number(s);
const hexA = (hex, a) => {
  const n = parseInt(hex.slice(1), 16);
  return "rgba(" + (n >> 16 & 255) + "," + (n >> 8 & 255) + "," + (n & 255) + "," + a + ")";
};
const DOT = " \u00b7 ", PM = " \u00b1 ", DASH = "\u2014";
/* the y-axis title: what one point is, then the spelled-out metric and unit */
const yTitle = m => DATA.axis_prefix + ":<br>" + DATA.labels[m];

const ROWS = Array.from({ length: NROW }, (_, i) => ({
  i, ws: COLS.Watershed[i], date: COLS.Sample_date[i], cc: COLS.Cover_crop_presence[i]
}));
const VAL = {}, SDV = {};
METRICS.forEach(m => { VAL[m] = COLS[m].map(num); SDV[m] = COLS[m + "_SD"].map(num); });

const WS_LIST = Object.keys(WS_SYMBOL).filter(w => ROWS.some(r => r.ws === w));
const CC_LIST = Object.keys(CC_COLOR).filter(c => ROWS.some(r => r.cc === c));
const SERIES = [];
WS_LIST.forEach(w => CC_LIST.forEach(c => {
  if (ROWS.some(r => r.ws === w && r.cc === c)) SERIES.push({ id: w + " " + c, ws: w, cc: c });
}));

/* ---------- state ---------- */
let wsFilter = "all", ccFilter = "all", errMode = "sd", showCtx = true, keepZoom = false;
const OFF = {};                       /* OFF[metric][row] = { comment, ts } */
METRICS.forEach(m => { OFF[m] = {}; });
const isOff = (m, i) => !!OFF[m][i];
const hasValue = (m, i) => COLS[m][i] !== NA_TOKEN;
const offCount = () => METRICS.reduce((a, m) => a + Object.keys(OFF[m]).length, 0);
const passRow = r => (wsFilter === "all" || r.ws === wsFilter) &&
                     (ccFilter === "all" || r.cc === ccFilter);
const shownSeries = () => SERIES.filter(s => (wsFilter === "all" || s.ws === wsFilter) &&
                                             (ccFilter === "all" || s.cc === ccFilter));

/* "value +/- SD (n = ...)", straight from the file's text */
function cellText(m, i){
  const v = COLS[m][i];
  if (v === NA_TOKEN) return '<span class="nodata">no data</span>';
  const sd = COLS[m + "_SD"][i], n = COLS[m + "_n"][i];
  return esc(v) + PM + (sd === NA_TOKEN ? DASH : esc(sd)) + " (n = " + esc(n) + ")";
}

/* ---------- outlet discharge + precipitation ---------- */
const OUTS = {};
(DATA.outlets || []).forEach(o => {
  const c = o.columns;
  OUTS[o.watershed] = {
    file: o.file, date: c.date, qs: c.q_ls, ps: c.precip_cm,
    q: c.q_ls.map(num), p: c.precip_cm.map(num),
    idx: new Map(c.date.map((d, i) => [d, i]))
  };
});
const OUT_WS  = Object.keys(OUTS);
const HAS_OUT = OUT_WS.length > 0;
/* watershed colours, shared by all IWI viewers: Shatto dark navy,
   Kirkpatrick light purple, so the two differ in tone as well as hue */
const OUT_COLORS = { Shatto: { q: "#1f4e79", p: "#7ea6cf" },
                     Kirkpatrick: { q: "#B386E0", p: "#c9aee9" } };
const outColor = w => OUT_COLORS[w] || { q: "#0f6e6e", p: "#86c4bd" };
const U_Q = "L/s", U_P = "cm";        /* from the column names q_ls, precip_cm */
/* the strip carries the precip axis on the right, so both plots reserve the
   same right margin -- that keeps their date axes on top of one another */
const PLOT_MARGIN_R = HAS_OUT ? 84 : 24;
/* and the same left margin, wide enough for a two-line y-axis title */
const PLOT_MARGIN_L = 116;

const wsOnScreen = () => wsFilter === "all" ? WS_LIST : [wsFilter];
const activeOutlets = () => wsOnScreen().filter(w => OUTS[w]);

function outletLine(date, ws){
  const lab = ws + " outlet";
  const O = OUTS[ws];
  if (!O) return lab + ": no outlet record";
  const i = O.idx.get(date);
  if (i == null) return lab + ": no record for this date";
  const q = O.qs[i] === "" ? "no data" : esc(O.qs[i]) + " " + U_Q;
  const p = O.ps[i] === "" ? "no data" : esc(O.ps[i]) + " " + U_P;
  return lab + ": Q " + q + DOT + "precip " + p;
}

function updateCtxHead(){
  if (!HAS_OUT) return;
  const act = activeOutlets();
  document.getElementById("ctx-cap").innerHTML =
    "<b>Outlet discharge and precipitation.</b> Daily stream discharge (lines, left axis) " +
    "and daily precipitation (bars, hanging from the top, right axis) at the " +
    esc(act.join(" and ")) + " watershed outlet" + (act.length > 1 ? "s" : "") +
    ", on the same dates as the figure below. Zoom either plot and the other follows.";
  document.getElementById("ctx-keys").innerHTML = act.map(w => {
    const c = outColor(w), pre = act.length > 1 ? w + " " : "";
    return '<span class="ctxkey"><i style="width:16px;height:0;border-top:2px solid ' + c.q +
           '"></i>' + esc(pre) + 'Q</span>' +
           '<span class="ctxkey"><i style="width:8px;height:11px;background:' + c.p +
           '"></i>' + esc(pre) + 'precip</span>';
  }).join("");
  document.getElementById("ctx-src").textContent = act.map(w => {
    const O = OUTS[w], qd = O.date.filter((d, i) => O.q[i] != null);
    return O.file + DOT + "Q " + qd[0] + " to " + qd[qd.length - 1];
  }).join("   |   ");
  document.getElementById("ctx-area").style.display = act.length ? "" : "none";
}

/* ctxState: "none" until first drawn, "pending" while newPlot runs, then "ready" */
let ctxState = "none", ctxSyncing = false, ctxLast = "";
const ctxEl = () => document.getElementById("ctx");

function niceStep(x){
  if (!(x > 0)) return 1;
  const e = Math.pow(10, Math.floor(Math.log10(x))), f = x / e;
  return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10) * e;
}
const tidy = v => +v.toFixed(10);   /* 0.30000000000000004 -> 0.3 */

/* y-ranges that fit the window on screen, so a zoom into one season shows
   that season's flow rather than a flat line under the biggest flood */
function ctxFit(lo, hi){
  const a = String(lo).slice(0, 10), b = String(hi).slice(0, 10);
  let qmax = 0, pmax = 0;
  activeOutlets().forEach(w => {
    const O = OUTS[w];
    for (let i = 0; i < O.date.length; i++) {
      const d = O.date[i];
      if (d < a) continue;
      if (d > b) break;
      const q = O.q[i], p = O.p[i];
      if (q != null && q > qmax) qmax = q;
      if (p != null && p > pmax) pmax = p;
    }
  });
  /* one panel, two axes: Q rises from the bottom and fills the lower ~65%;
     precip hangs from the top (reversed axis) and fills at most the upper
     40%, so a storm's bars point down at its Q peak */
  const Q_SHARE = 0.65, P_SHARE = 0.40;
  /* Q: range starts at 0 and 0 is always a labelled tick */
  const qtop = qmax > 0 ? qmax / Q_SHARE : 1;
  const qstep = niceStep(qtop / 5);
  const qt = [];
  for (let k = 0; k * qstep <= qtop + 1e-9; k++) qt.push(tidy(k * qstep));
  /* precip: 0 at the top, then 4 or 5 round steps down (5-6 labelled ticks);
     the axis ends on the last tick, chosen as the tightest one that keeps
     the tallest bar within the upper ~45% of the panel */
  const need = (pmax || 0.1) / 0.45;
  const e10 = Math.pow(10, Math.floor(Math.log10(need / 5)));
  let best = null;
  [e10 / 10, e10, e10 * 10].forEach(e => [1, 2, 2.5, 5].forEach(f => [4, 5].forEach(k => {
    const s = f * e, end = k * s;
    if (end >= need && (!best || end < best.end || (end === best.end && k > best.k))) {
      best = { s: s, k: k, end: end };
    }
  })));
  const pt = [];
  for (let k = 0; k <= best.k; k++) pt.push(tidy(k * best.s));
  /* 4% of air at each end, so the 0 labels on the panel's edges aren't clipped */
  const PAD = 0.04;
  return { q: [-PAD * qtop, qtop], qt: qt,
           p: [best.end * (1 + PAD), -PAD * best.end], pt: pt };
}

function ctxTraces(){
  const act = activeOutlets();
  const bars = [], lines = [];
  act.forEach(w => {
    const O = OUTS[w], c = outColor(w), pre = act.length > 1 ? w + " " : "";
    /* dry days carry no bar; their zero is still in the hover of the Q line */
    const pd = [], pv = [];
    O.date.forEach((d, i) => {
      const v = O.p[i];
      if (v != null && v > 0) { pd.push(d); pv.push(v); }
    });
    bars.push({ type: "bar", name: pre + "precip", x: pd, y: pv, xaxis: "x", yaxis: "y",
                marker: { color: c.p, line: { width: 0 } },
                opacity: act.length > 1 ? 0.7 : 0.9, hoverinfo: "skip" });
    lines.push({ type: "scattergl", mode: "lines", name: pre + "outlet Q", x: O.date, y: O.q,
                 xaxis: "x", yaxis: "y2", connectgaps: false,
                 line: { color: c.q, width: 1.2 },
                 customdata: O.ps.map(s => s === "" ? "no data" : s),
                 hovertemplate: "%{x|%Y-%m-%d}<br>" + w + " outlet Q <b>%{y:.1f}</b> " +
                                U_Q + "<br>" + w + " precip <b>%{customdata}</b> " +
                                U_P + "<extra></extra>" });
  });
  return bars.concat(lines);
}

function ctxLayout(r, fit){
  const ax = { gridcolor: "#eeece5", zeroline: false, fixedrange: true,
               tickfont: { size: 16 } };
  return {
    margin: { l: PLOT_MARGIN_L, r: PLOT_MARGIN_R, t: 12, b: 10 },
    xaxis: { type: "date", range: r, gridcolor: "#eeece5", zeroline: false,
             showticklabels: false, ticks: "" },
    /* y  = precipitation, right-hand, reversed (bars hang from the top)
       y2 = discharge, left-hand, drawn over the bars */
    yaxis:  { ...ax, side: "right", range: fit.p, tickmode: "array",
              tickvals: fit.pt, showgrid: false,
              title: { text: DATA.outlet_labels.precip_cm, font: { size: 17 } } },
    yaxis2: { ...ax, side: "left", overlaying: "y", range: fit.q,
              tickmode: "array", tickvals: fit.qt,
              title: { text: DATA.outlet_labels.q_ls, font: { size: 17 } } },
    bargap: 0.1,
    barmode: "overlay",
    hovermode: "x",
    showlegend: false,
    paper_bgcolor: "#fff", plot_bgcolor: "#fff",
    font: { family: "-apple-system,Segoe UI,Helvetica,Arial,sans-serif", size: 17 },
    hoverlabel: { font: { size: 17 } }
  };
}

/* Bring the panel to the metric plot's date window. The metric plot always
   decides: a zoom on the panel is passed to the metric plot, whose own
   relayout then calls this. */
let ctxSet = "";
function syncCtx(){
  if (!HAS_OUT || !showCtx) return;
  const act = activeOutlets();
  if (!act.length) return;
  const gd = document.getElementById("plot");
  const fl = gd._fullLayout;
  if (!fl || !fl.xaxis || !gd.data || !gd.data.length) return;
  if (ctxState === "pending") return;
  const r = fl.xaxis.range.slice();
  const key = r.join("|") + "|" + act.join(",");
  if (ctxState === "ready" && key === ctxLast) return;
  ctxLast = key;
  const setChanged = act.join(",") !== ctxSet;
  ctxSet = act.join(",");
  const fit = ctxFit(r[0], r[1]);
  ctxSyncing = true;
  const done = () => { ctxSyncing = false; };
  if (ctxState === "none") {
    ctxState = "pending";
    Plotly.newPlot(ctxEl(), ctxTraces(), ctxLayout(r, fit),
                   { displaylogo: false, responsive: true, displayModeBar: false })
      .then(() => { ctxState = "ready"; bindCtx(); done(); syncCtx(); },
            () => { ctxState = "none"; done(); });
  } else if (setChanged) {
    Plotly.react(ctxEl(), ctxTraces(), ctxLayout(r, fit),
                 { displaylogo: false, responsive: true, displayModeBar: false })
      .then(() => { Plotly.Plots.resize(ctxEl()); done(); }, done);
  } else {
    Plotly.relayout(ctxEl(), { "xaxis.range": r, "yaxis.range": fit.p,
                               "yaxis.tickvals": fit.pt,
                               "yaxis2.range": fit.q,
                               "yaxis2.tickvals": fit.qt }).then(done, done);
  }
}

function bindCtx(){
  const el = ctxEl();
  el.on("plotly_relayout", ev => {
    if (ctxSyncing) return;
    const gd = document.getElementById("plot");
    if (ev["xaxis.autorange"]) {
      Plotly.relayout(gd, { "xaxis.autorange": true, "yaxis.autorange": true });
      return;
    }
    const a = ev["xaxis.range[0]"] != null ? ev["xaxis.range[0]"] : (ev["xaxis.range"] || [])[0];
    const b = ev["xaxis.range[1]"] != null ? ev["xaxis.range[1]"] : (ev["xaxis.range"] || [])[1];
    if (a == null || b == null) return;
    ctxLast = "";
    Plotly.relayout(gd, { "xaxis.range": [a, b] });
  });
  el.on("plotly_hover", ev => {
    const p = ev.points && ev.points[0];
    if (p) showGuide("plot", p.x);
  });
  el.on("plotly_unhover", () => hideGuide("plot"));
}

/* a dashed line on one plot at the date being hovered on the other */
function showGuide(target, x){
  if (!HAS_OUT || !showCtx) return;
  const gd = document.getElementById(target);
  const g  = document.getElementById("guide-" + target);
  const fl = gd && gd._fullLayout;
  if (!g || !fl || !fl.xaxis || !fl._size) return;
  const xa = fl.xaxis;
  const px = xa._offset + xa.l2p(xa.d2l(x));
  if (!isFinite(px) || px < xa._offset || px > xa._offset + xa._length) {
    g.style.display = "none"; return;
  }
  g.style.left = px + "px";
  g.style.top = fl._size.t + "px";
  g.style.height = fl._size.h + "px";
  g.style.display = "block";
}
function hideGuide(target){
  const g = document.getElementById("guide-" + target);
  if (g) g.style.display = "none";
}

function applyCtx(){
  const on = HAS_OUT && showCtx;
  document.getElementById("ctxwrap").hidden = !on;
  updateCtxHead();
  document.getElementById("plotcard").classList.toggle("withctx", on);
  hideGuide("ctx"); hideGuide("plot");
  const gd = document.getElementById("plot");
  if (gd._fullLayout) Plotly.Plots.resize(gd);
  if (on) {
    if (ctxState === "ready") Plotly.Plots.resize(ctxEl());
    ctxLast = "";
    syncCtx();
  }
}

/* ---------- metric plot: points only, no connecting lines ---------- */
function hoverFor(i){
  const r = ROWS[i], L = [];
  L.push("<b>" + esc(r.ws) + DOT + esc(r.cc) + "</b>  " + r.date);
  L.push(esc(M) + ": <b>" + cellText(M, i) + "</b>");
  if (isOff(M, i)) L.push("<b>turned off</b>: " + esc(OFF[M][i].comment));
  if (HAS_OUT) L.push(outletLine(r.date, r.ws));
  L.push("<i>click to review this point</i>");
  return L.join("<br>") + "<extra></extra>";
}

function tracesFor(s){
  const idx = ROWS.filter(r => r.ws === s.ws && r.cc === s.cc && VAL[M][r.i] != null)
                  .sort((a, b) => a.date < b.date ? -1 : a.date > b.date ? 1 : 0)
                  .map(r => r.i);
  const on = idx.filter(i => !isOff(M, i)), off = idx.filter(i => isOff(M, i));
  const color = CC_COLOR[s.cc];
  const t = {
    type: "scatter", mode: "markers", name: s.ws + " " + s.cc, legendgroup: s.id,
    x: on.map(i => ROWS[i].date), y: on.map(i => VAL[M][i]), customdata: on,
    marker: { size: POINT_SIZE, symbol: WS_SYMBOL[s.ws], color: color, line: { width: 0 } },
    opacity: .92,
    hovertemplate: on.map(hoverFor), hoverlabel: { align: "left" }
  };
  if (errMode === "sd") {
    t.error_y = { type: "data", array: on.map(i => SDV[M][i] == null ? 0 : SDV[M][i]),
                  color: hexA(color, .45), thickness: 1, width: 2 };
  }
  const out = [t];
  /* OFF points: an x at the value the point carries in the file, so the
     decision stays visible; no error bar */
  if (off.length) {
    out.push({
      type: "scatter", mode: "markers", name: s.ws + " " + s.cc + " (turned off)",
      legendgroup: s.id, showlegend: false,
      x: off.map(i => ROWS[i].date), y: off.map(i => VAL[M][i]), customdata: off,
      marker: { size: 11, symbol: "x-thin-open", color: color, line: { width: 2, color: color } },
      opacity: .85,
      hovertemplate: off.map(hoverFor), hoverlabel: { align: "left" }
    });
  }
  return out;
}

/* ---------- the date axis (shared by all three IWI viewers; copy verbatim) ----------
   Months are named by their first three letters, and January also carries
   the year ("Jan 2019"). Each tick sits mid-month, centred over the month it
   names. Zoomed out, only Jan and Jun are labelled; zoom in until every label
   has room and each month gets one (advisor, 2026-10). "Room" is measured in
   pixels along the axis, so a narrow window drops to Jan + Jun sooner than a
   wide one. If even Jan + Jun would overlap (a very narrow window), only Jan
   is drawn. The labels are set at TICK_ANGLE degrees; angled labels sit closer
   together without colliding, so they need less room per tick. */
const MONTH_ABBR = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
const TICK_ANGLE = -45;
const TICK_ROOM_PX = TICK_ANGLE ? 22 : 44;     /* room one label needs along the axis */
const X_MARGIN_B = TICK_ANGLE ? 80 : 64;       /* the plot's bottom margin, sized for the labels */
const X_TICK_FONT = TICK_ANGLE ? 14 : 16;     /* angled labels a little smaller, so Jan + Jun fit on a long record */
function monthTicks(a, b, px){
  const from = new Date(a), to = new Date(b);
  if (isNaN(+from) || isNaN(+to) || to <= from) return null;
  const span = (to.getUTCFullYear() - from.getUTCFullYear()) * 12 +
               (to.getUTCMonth() - from.getUTCMonth()) + 1;
  const perMonth = (px > 0 ? px : 1000) / span;  /* 1000 px when the plot isn't laid out yet */
  const show = perMonth >= TICK_ROOM_PX     ? () => true
             : perMonth * 5 >= TICK_ROOM_PX ? m => m === 0 || m === 5   /* Jan to Jun is the tighter gap */
             :                                m => m === 0;
  const vals = [], text = [];
  let y = from.getUTCFullYear(), m = from.getUTCMonth();
  for (let i = 0; i < span; i++) {
    if (show(m)) {
      vals.push(new Date(Date.UTC(y, m, 15)).toISOString().slice(0, 10));
      text.push(m === 0 ? MONTH_ABBR[m] + (TICK_ANGLE ? " " : "<br>") + "<b>" + y + "</b>" : MONTH_ABBR[m]);
    }
    if (++m > 11) { m = 0; y++; }
  }
  return { tickmode: "array", tickvals: vals, ticktext: text, tickangle: TICK_ANGLE };
}
/* The width of a plot's date axis in pixels: plotly's own figure once the
   plot is drawn, else the div's width less the margins. */
function axisPx(id){
  const gd = document.getElementById(id);
  if (!gd) return 0;
  const fl = gd._fullLayout;
  if (fl && fl.xaxis && fl.xaxis._length > 0) return fl.xaxis._length;
  return gd.clientWidth - PLOT_MARGIN_L - PLOT_MARGIN_R;
}
/* The window the axis is showing: the zoom if there is one, the data on
   screen otherwise. */
function plotDateRange(){
  const gd = document.getElementById("plot");
  const r = gd && gd.layout && gd.layout.xaxis && gd.layout.xaxis.range;
  if (r && r.length === 2 && !(gd.layout.xaxis.autorange)) return r;
  const ds = ROWS.filter(x => passRow(x) && VAL[M][x.i] != null).map(x => x.date).sort();
  return ds.length ? [ds[0], ds[ds.length - 1]] : null;
}
function dateAxis(){
  const base = { title: "", type: "date", gridcolor: "#eeece5", zeroline: false,
                 tickfont: { size: X_TICK_FONT } };
  const r = plotDateRange();
  const t = r ? monthTicks(r[0], r[1], axisPx("plot")) : null;
  return t ? { ...base, ...t } : base;
}
/* Re-letter the axis after a zoom or a pan. Guarded: relayout fires its own
   event, and without the flag this would call itself forever. */
let tickBusy = false;
function refreshMonthTicks(){
  if (tickBusy) return;
  const gd = document.getElementById("plot");
  if (!gd || !gd.layout) return;
  const r = plotDateRange();
  const t = r ? monthTicks(r[0], r[1], axisPx("plot")) : null;
  if (!t) return;
  const cur = gd.layout.xaxis.ticktext || [];
  if (cur.length === t.ticktext.length && cur[0] === t.ticktext[0] &&
      cur[cur.length - 1] === t.ticktext[t.ticktext.length - 1]) return;
  tickBusy = true;
  Plotly.relayout(gd, { "xaxis.tickmode": "array", "xaxis.tickvals": t.tickvals,
                        "xaxis.ticktext": t.ticktext })
        .then(() => { tickBusy = false; }, () => { tickBusy = false; });
}

function layout(){
  return {
    margin: { l: PLOT_MARGIN_L, r: PLOT_MARGIN_R, t: 16, b: X_MARGIN_B },
    xaxis: dateAxis(),
    yaxis: { title: { text: yTitle(M), font: { size: 17.5 } }, type: "linear",
             gridcolor: "#eeece5", zeroline: false },
    hovermode: "closest",
    showlegend: true,
    legend: { orientation: "h", y: 1.08, x: 0, font: { size: 17 } },
    paper_bgcolor: "#fff", plot_bgcolor: "#fff",
    font: { family: "-apple-system,Segoe UI,Helvetica,Arial,sans-serif", size: 17 },
    hoverlabel: { font: { size: 17 } },
    uirevision: keepZoom ? "sticky" : (M + "|" + ccFilter + "|" + wsFilter)
  };
}

function drawPlot(){
  const traces = shownSeries().flatMap(tracesFor);
  const gd = document.getElementById("plot");
  const drawn = Plotly.react(gd, traces, layout(),
               { displaylogo: false, responsive: true,
                 modeBarButtonsToRemove: ["select2d", "lasso2d", "autoScale2d"] })
    .then(() => { syncCtx(); refreshMonthTicks(); renderSummary(); });
  if (!gd._bound) {
    gd.on("plotly_click", ev => {
      const p = ev.points && ev.points[0];
      if (p && p.customdata != null) openPanel(p.customdata, M);
    });
    /* zoom, pan, reset and resize all land here; the outlet panel follows and
       the month letters are re-cut for the new window */
    gd.on("plotly_relayout", () => { syncCtx(); refreshMonthTicks(); });
    gd.on("plotly_hover", ev => {
      const p = ev.points && ev.points[0];
      if (p) showGuide("ctx", p.x);
    });
    gd.on("plotly_unhover", () => hideGuide("ctx"));
    /* a legend click hides or shows a series: the summary's "shown" follows */
    gd.on("plotly_restyle", () => renderSummary());
    gd._bound = true;
  }
  return drawn;
}

/* ---------- click-point side panel ---------- */
let PANEL = null;        /* { i, m } while open */
let pending = false;     /* switch flipped to OFF, waiting for the comment */

function openPanel(i, m){
  PANEL = { i: i, m: m || M };
  pending = false;
  document.getElementById("side").hidden = false;
  document.getElementById("scrim").hidden = false;
  renderPanel();
}
function closePanel(){
  PANEL = null; pending = false;
  document.getElementById("side").hidden = true;
  document.getElementById("scrim").hidden = true;
}

function renderPanel(){
  if (!PANEL) return;
  const i = PANEL.i, m = PANEL.m, r = ROWS[i];
  document.getElementById("side-title").textContent = r.ws + DOT + r.cc + DOT + r.date;
  const badge = document.getElementById("side-badge");
  const state = !hasValue(m, i) ? "no data" : isOff(m, i) ? "OFF" : "ON";
  badge.textContent = m + ": " + state;
  badge.className = "badge" + (state === "OFF" ? " off" : state === "ON" ? " on" : "");

  let h = '<div class="sidesec"><h3>Every metric in this row</h3>' +
          '<table><tbody>' +
          METRICS.map(k => {
            const off = isOff(k, i);
            const val = off ? '<span class="was">' + cellText(k, i) + '</span>' : cellText(k, i);
            return '<tr class="clickable' + (k === m ? " hi" : "") + '" data-m="' + esc(k) + '">' +
                   '<td>' + (k === m ? "<b>" + esc(k) + "</b>" : esc(k)) + '</td>' +
                   '<td class="num">' + val + '</td>' +
                   '<td>' + (off ? '<span class="badge off">OFF</span>' : "") + '</td></tr>';
          }).join("") +
          '</tbody></table>' +
          '<div style="margin-top:6px;color:var(--muted)">Click a metric to review it for this row.</div></div>';

  if (HAS_OUT) {
    h += '<div class="sidesec"><h3>Outlet on this day</h3>' + outletLine(r.date, r.ws) + '</div>';
  }

  h += '<div class="sidesec"><h3>Review ' + esc(m) + ' for this row</h3>';
  if (!hasValue(m, i)) {
    h += '<div>' + esc(m) + ' has no data in this row, so there is nothing to turn off.</div>';
  } else if (isOff(m, i)) {
    const o = OFF[m][i];
    h += '<div class="toggle"><label class="sw2"><input type="checkbox" id="pt-switch">' +
         '<span class="sl"></span></label><b>OFF</b></div>' +
         '<div>Drawn as an x. In the reviewed download this row\u2019s ' + esc(m) + ', ' +
         esc(m) + '_SD and ' + esc(m) + '_n are written ' + esc(NA_TOKEN) + ', ' +
         esc(NA_TOKEN) + ', ' + esc(MISSING_N) + '.</div>' +
         '<div style="margin-top:6px"><b>Why:</b> ' + esc(o.comment) + '</div>' +
         '<div style="color:var(--muted)">turned off ' + esc(o.ts) + '</div>' +
         '<div style="margin-top:6px;color:var(--muted)">Flip the switch to turn it back on.</div>';
    const others = METRICS.filter(k => k !== m && isOff(k, i));
    if (others.length) {
      h += '<div class="row-actions"><button id="pt-all-on">turn every metric in this row back on (' +
           (others.length + 1) + ')</button></div>';
    }
  } else if (!pending) {
    h += '<div class="toggle"><label class="sw2"><input type="checkbox" id="pt-switch" checked>' +
         '<span class="sl"></span></label><b>ON</b></div>' +
         '<div style="color:var(--muted)">Flip the switch to turn this point off. You will be asked why.</div>';
  } else {
    const nOther = METRICS.filter(k => k !== m && hasValue(k, i) && !isOff(k, i)).length;
    h += '<div class="toggle"><label class="sw2"><input type="checkbox" id="pt-switch" disabled>' +
         '<span class="sl"></span></label><b>turning OFF</b></div>' +
         '<label for="pt-comment"><b>Why is this point being turned off?</b> ' +
         '<span class="req">required</span></label>' +
         '<textarea class="comment" id="pt-comment" placeholder="e.g. value implausible for a tile drain; checked field notebook"></textarea>' +
         (nOther ? '<label style="display:flex;gap:6px;align-items:center;margin-top:6px">' +
                   '<input type="checkbox" id="pt-allm"> also turn off every other metric in this row (' +
                   nOther + ') with the same comment</label>' : '') +
         '<div class="row-actions"><button class="primary" id="pt-save" disabled>turn off</button>' +
         '<button id="pt-cancel">cancel</button></div>';
  }
  h += '</div>';
  document.getElementById("side-body").innerHTML = h;

  document.querySelectorAll("#side-body tr[data-m]").forEach(tr => {
    tr.onclick = () => { if (tr.dataset.m !== M) switchTo(tr.dataset.m); else { PANEL.m = M; pending = false; renderPanel(); } };
  });
  const sw = document.getElementById("pt-switch");
  if (sw && !sw.disabled) {
    sw.onchange = () => {
      if (isOff(m, i)) { turnOn(m, i); }
      else { pending = true; renderPanel(); const c = document.getElementById("pt-comment"); if (c) c.focus(); }
    };
  }
  const allOn = document.getElementById("pt-all-on");
  if (allOn) allOn.onclick = () => { METRICS.forEach(k => { delete OFF[k][i]; }); refresh(); };
  const cm = document.getElementById("pt-comment");
  if (cm) {
    const save = document.getElementById("pt-save");
    cm.oninput = () => { save.disabled = !cm.value.trim(); };
    save.onclick = () => {
      const all = document.getElementById("pt-allm");
      if (turnOff(m, i, cm.value, !!(all && all.checked))) { pending = false; refresh(); }
    };
    document.getElementById("pt-cancel").onclick = () => { pending = false; renderPanel(); };
  }
}

/* The only two functions that change the review. A comment is required to
   turn a point off; turnOff refuses without one. */
function turnOff(m, i, comment, allMetrics){
  comment = String(comment || "").trim();
  if (!comment) return false;
  if (!hasValue(m, i)) return false;
  const ts = new Date().toISOString().replace(/\.\d{3}Z$/, "Z");
  const which = allMetrics ? METRICS.filter(k => hasValue(k, i) && !isOff(k, i)) : [m];
  which.forEach(k => { OFF[k][i] = { comment: comment, ts: ts }; });
  saveState();
  return true;
}
function turnOn(m, i){
  delete OFF[m][i];
  refresh();
}

/* ---------- the list of points turned off ---------- */
function offEntries(){
  const out = [];
  METRICS.forEach(m => Object.keys(OFF[m]).map(Number).sort((a, b) => a - b)
    .forEach(i => out.push({ m: m, i: i, o: OFF[m][i] })));
  return out;
}
function renderOffList(){
  const e = offEntries();
  document.getElementById("off-title").textContent = "Points turned off (" + e.length + ")";
  const el = document.getElementById("offlist");
  if (!e.length) {
    el.innerHTML = '<div class="empty">None yet. Click a point on the plot to review it.</div>';
    return;
  }
  el.innerHTML = '<div class="tablewrap"><table><thead><tr><th>Column</th><th>Watershed</th>' +
    '<th>Cover crop</th><th>Date</th><th>Value in file</th><th>Comment</th><th>Turned off</th></tr></thead><tbody>' +
    e.map(x => {
      const r = ROWS[x.i];
      return '<tr class="clickable" data-m="' + esc(x.m) + '" data-i="' + x.i + '" title="reopen this point">' +
             '<td>' + esc(x.m) + '</td><td>' + esc(r.ws) + '</td><td>' + esc(r.cc) + '</td>' +
             '<td>' + r.date + '</td><td class="num">' + cellText(x.m, x.i) + '</td>' +
             '<td>' + esc(x.o.comment) + '</td><td style="white-space:nowrap">' + esc(x.o.ts) + '</td></tr>';
    }).join("") + '</tbody></table></div>' +
    '<div class="hint">Click a row to reopen it and switch it back on.</div>';
  el.querySelectorAll("tr[data-i]").forEach(tr => {
    tr.onclick = () => {
      const m = tr.dataset.m, i = Number(tr.dataset.i);
      if (m !== M) switchTo(m);
      openPanel(i, m);
    };
  });
}

/* ---------- series summary, live ----------
   One row per series (watershed x cover crop) for the metric on screen,
   computed from the values in the file, leaving out points turned off, so
   it moves as the review goes. "shown" follows the filters and the legend. */

/* Significant figures rather than fixed decimals: these metrics span pH ~8
   and NO3 flux in the hundreds in the same page. */
function fmt(v){
  if (v == null || !isFinite(v)) return DASH;
  const a = Math.abs(v);
  if (a === 0) return "0";
  if (a >= 1000) return v.toFixed(0);
  if (a >= 10)   return v.toFixed(1);
  if (a >= 1)    return v.toFixed(2);
  return v.toPrecision(3);
}
function median(a){
  if (!a.length) return null;
  const b = a.slice().sort((x, y) => x - y), h = b.length >> 1;
  return b.length % 2 ? b[h] : (b[h - 1] + b[h]) / 2;
}
function renderSummary(){
  const gd = document.getElementById("plot");
  const legendOff = new Set((gd._fullData || [])
    .filter(t => t.visible === "legendonly").map(t => t.legendgroup));
  const onScreen = new Set(shownSeries().map(s => s.id));
  let h = '<div class="tablewrap"><table><thead><tr><th>series</th><th>shown</th>' +
          '<th class="num">points</th><th class="num">median</th><th class="num">mean</th>' +
          '<th class="num">min</th><th class="num">max</th><th class="num">turned off</th>' +
          '</tr></thead><tbody>';
  SERIES.forEach(s => {
    const idx = ROWS.filter(r => r.ws === s.ws && r.cc === s.cc && VAL[M][r.i] != null).map(r => r.i);
    const v = idx.filter(i => !isOff(M, i)).map(i => VAL[M][i]);
    const off = idx.length - v.length;
    const mean = v.length ? v.reduce((a, b) => a + b, 0) / v.length : null;
    const shown = onScreen.has(s.id) && !legendOff.has(s.id);
    const shape = WS_SYMBOL[s.ws] === "triangle-up" ? "clip-path:polygon(50% 0,100% 100%,0 100%)" : "border-radius:50%";
    h += '<tr' + (shown ? '' : ' style="color:var(--muted)"') + '>' +
         '<td><span class="swatch" style="background:' + CC_COLOR[s.cc] + ';' + shape + '"></span>' +
         esc(s.ws + " " + s.cc) + '</td>' +
         '<td>' + (shown ? "yes" : "no") + '</td>' +
         '<td class="num">' + v.length + '</td>' +
         '<td class="num">' + fmt(median(v)) + '</td>' +
         '<td class="num">' + fmt(mean) + '</td>' +
         '<td class="num">' + fmt(v.length ? Math.min(...v) : null) + '</td>' +
         '<td class="num">' + fmt(v.length ? Math.max(...v) : null) + '</td>' +
         '<td class="num">' + (off || "") + '</td></tr>';
  });
  document.getElementById("summary").innerHTML = h + '</tbody></table></div>' +
    '<div class="hint">' + esc(M) + ': statistics of the means in the file for each series, ' +
    'leaving out points turned off. "points" counts sample dates, not drains.</div>';
}

/* ---------- tabs, filters, refresh ---------- */
function renderTabs(){
  /* the tab text is the CSV column header, character for character */
  document.getElementById("tabs").innerHTML = METRICS.map(m =>
    '<button class="tab' + (m === M ? " on" : "") + '" data-k="' + esc(m) + '">' + esc(m) + '</button>'
  ).join("");
  document.querySelectorAll(".tab").forEach(t => { t.onclick = () => switchTo(t.dataset.k); });
}

function metricSubtitle(){
  const idx = ROWS.filter(r => passRow(r) && VAL[M][r.i] != null);
  const ds = idx.map(r => r.date).sort();
  const off = idx.filter(r => isOff(M, r.i)).length;
  if (!idx.length) return M + ": no data for this selection";
  return M + DOT + idx.length + " points" + DOT + ds[0] + " to " + ds[ds.length - 1] +
         (off ? DOT + off + " turned off" : "");
}

/* the figure caption above the metric plot: what one point is, what the
   colours and shapes mean, and what the error bars are */
function plotCaption(){
  const err = errMode === "sd"
    ? "Error bars are " + PM.trim() + " 1 SD across those tile drains; hover a point for n, the number of tile drains."
    : "Error bars are turned off; hover a point for its SD and n, the number of tile drains.";
  return "<b>" + DATA.axis_prefix + ": " + DATA.labels[M] + ".</b> Each point is the mean of the tile drains sampled on one date " +
         "in one watershed, averaged separately for drains under cover crop and no cover crop. " +
         "Colour shows cover crop (light green = cover crop, dark brown = no cover crop) and marker " +
         "shape shows the watershed (circle = Shatto, triangle = Kirkpatrick). " + err;
}

function refresh(){
  renderTabs();
  drawPlot();
  renderOffList();
  document.getElementById("plot-cap").innerHTML = plotCaption();
  document.getElementById("h-metric").textContent = metricSubtitle();
  if (PANEL) renderPanel();
  saveState();
}

function switchTo(key){
  if (!METRICS.includes(key)) return;
  M = key;
  if (PANEL) { PANEL.m = key; pending = false; }
  refresh();
}

/* ---------- export: must round-trip ----------
   The reviewed download is the loaded file rebuilt from its own text: same
   columns, order, number text, NA token, dates, UTF-8 without BOM, and line
   endings. Only OFF points change: value and SD -> NA token, n -> 0. */
function reviewedText(){
  const col = {};
  H.forEach((h, j) => { col[h] = j; });
  const lines = [H.join(",")];
  for (let i = 0; i < NROW; i++) {
    const cells = H.map(h => COLS[h][i]);
    METRICS.forEach(m => {
      if (!isOff(m, i)) return;
      cells[col[m]] = NA_TOKEN;
      cells[col[m + "_SD"]] = NA_TOKEN;
      cells[col[m + "_n"]] = MISSING_N;
    });
    lines.push(cells.join(","));
  }
  return lines.join(DATA.eol) + (DATA.final_eol ? DATA.eol : "");
}

const csvEsc = v => {
  const s = String(v == null ? "" : v);
  return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
};
function reviewLogText(){
  const head = ["Watershed", "Sample_date", "Cover_crop_presence", "metric_column",
                "original_value", "original_SD", "original_n", "comment", "timestamp_utc"];
  const lines = [head.join(",")];
  offEntries().forEach(x => {
    const r = ROWS[x.i];
    lines.push([r.ws, r.date, r.cc, x.m, COLS[x.m][x.i], COLS[x.m + "_SD"][x.i],
                COLS[x.m + "_n"][x.i], x.o.comment, x.o.ts].map(csvEsc).join(","));
  });
  return lines.join("\n") + "\n";
}

function download(name, text){
  /* a string Blob is written as UTF-8 with no BOM */
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([text], { type: "text/csv;charset=utf-8" }));
  a.download = name;
  document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 400);
}

/* ---------- saved review (this browser only) ---------- */
const SKEY = "iwi_viewer::" + DATA.source_file + "::" + DATA.source_md5;
function saveState(){
  const n = offCount();
  document.getElementById("savestate").textContent =
    n ? n + " point" + (n === 1 ? "" : "s") + " off" + DOT + "saved in this browser" : "";
  try {
    localStorage.setItem(SKEY, JSON.stringify({
      off: OFF, tab: M, wsFilter: wsFilter, ccFilter: ccFilter, errMode: errMode,
      showCtx: showCtx, keepZoom: keepZoom, when: new Date().toISOString()
    }));
  } catch (e) { /* storage unavailable; the page still works */ }
}
function loadState(){
  let s = null;
  try { s = JSON.parse(localStorage.getItem(SKEY) || "null"); } catch (e) { return; }
  if (!s) return;
  if (s.off) METRICS.forEach(m => Object.entries(s.off[m] || {}).forEach(([i, o]) => {
    i = Number(i);
    if (i >= 0 && i < NROW && hasValue(m, i) && o && String(o.comment || "").trim()) {
      OFF[m][i] = { comment: String(o.comment), ts: String(o.ts || "") };
    }
  }));
  if (METRICS.includes(s.tab)) M = s.tab;
  if (s.wsFilter === "all" || WS_LIST.includes(s.wsFilter)) wsFilter = s.wsFilter;
  if (s.ccFilter === "all" || CC_LIST.includes(s.ccFilter)) ccFilter = s.ccFilter;
  if (s.errMode === "sd" || s.errMode === "none") errMode = s.errMode;
  if (typeof s.showCtx === "boolean") showCtx = s.showCtx;
  keepZoom = !!s.keepZoom;
}

/* ---------- wiring ---------- */
document.getElementById("h-banner").textContent = DATA.title;
document.getElementById("h-sub").textContent =
  "Loaded file: " + DATA.source_file + DOT + NROW + " rows" + DOT +
  ROWS.map(r => r.date).sort()[0] + " to " + ROWS.map(r => r.date).sort()[NROW - 1] + DOT +
  METRICS.length + " metrics" + DOT + "built " + DATA.built +
  (HAS_OUT ? DOT + "outlet Q/precip: " + OUT_WS.map(w => OUTS[w].file).join(", ") : "");

document.getElementById("sel-ws").innerHTML = '<option value="all">All</option>' +
  WS_LIST.map(w => '<option value="' + esc(w) + '">' + esc(w) + '</option>').join("");
document.getElementById("sel-cc").innerHTML = '<option value="all">All</option>' +
  CC_LIST.map(c => '<option value="' + esc(c) + '">' + esc(c) + '</option>').join("");

loadState();

document.getElementById("sel-ws").onchange = e => { wsFilter = e.target.value; updateCtxHead(); refresh(); };
document.getElementById("sel-cc").onchange = e => { ccFilter = e.target.value; refresh(); };
document.getElementById("sel-err").onchange = e => {
  errMode = e.target.value; drawPlot(); saveState();
  document.getElementById("plot-cap").innerHTML = plotCaption();
};
document.getElementById("cb-ctx").onchange = e => { showCtx = e.target.checked; applyCtx(); saveState(); };
document.getElementById("cb-keepzoom").onchange = e => { keepZoom = e.target.checked; drawPlot(); saveState(); };
document.getElementById("btn-resetzoom").onclick = () => {
  Plotly.relayout("plot", { "xaxis.autorange": true, "yaxis.autorange": true });
};
document.getElementById("btn-dl-reviewed").onclick = () => download(DATA.names.reviewed, reviewedText());
document.getElementById("btn-dl-log").onclick = () => download(DATA.names.log, reviewLogText());
document.getElementById("btn-clear-saved").onclick = () => {
  if (offCount() && !confirm("Turn every point back on and forget the comments saved in this browser?")) return;
  METRICS.forEach(m => { OFF[m] = {}; });
  try { localStorage.removeItem(SKEY); } catch (e) {}
  refresh();
};
document.getElementById("side-close").onclick = closePanel;
document.getElementById("scrim").onclick = closePanel;
document.addEventListener("keydown", e => { if (e.key === "Escape") closePanel(); });

document.getElementById("sel-ws").value = wsFilter;
document.getElementById("sel-cc").value = ccFilter;
document.getElementById("sel-err").value = errMode;
document.getElementById("cb-keepzoom").checked = keepZoom;
document.getElementById("cb-ctx").checked = showCtx;
if (!HAS_OUT) document.getElementById("wrap-ctx").style.display = "none";

(function writeHint(){
  const L = [];
  L.push("<b>Tabs</b> switch the measurement; each tab is a column of " + esc(DATA.source_file) +
         ". <b>Colour</b> is cover crop and <b>marker shape</b> is the watershed (legend above the plot).");
  L.push("<b>Hover</b> a point for its mean " + PM.trim() + " SD and n (the number of tile drains averaged). " +
         "<b>Click</b> it to see every metric for that row and to turn the point off, with a comment.");
  L.push("<b>Zoom</b> by dragging across the plot; double-click to go back to the whole record. " +
         "Click a name in the legend to hide that series.");
  L.push("<b>Dates</b> run left to right by month " + DASH + " Jan and Jun, then all twelve once zoomed in " + DASH +
         " with the year beside January.");
  if (HAS_OUT) L.push("<b>The strip above</b> is daily discharge and precipitation at the watershed outlet, " +
                      "on the same dates: zoom one and the other follows.");
  L.push("<b>Download reviewed data</b> writes this file back with every OFF point set to " +
         esc(NA_TOKEN) + ", " + esc(NA_TOKEN) + ", " + esc(MISSING_N) + " (value, SD, n); " +
         "<b>download review log</b> lists each OFF point with its comment.");
  document.getElementById("hint").innerHTML =
    L.map(s => '<div style="margin:2px 0">' + s + '</div>').join("");
})();

applyCtx();
refresh();

/* hooks for the headless round-trip test (work/03_roundtrip.R) */
window.IWI = { reviewedText, reviewLogText, turnOff, turnOn, openPanel, switchTo,
               drawPlot, monthTicks, ctxFit, offCount, plotCaption };
</script>
</body>
</html>
]---"

html <- TEMPLATE |>
  fill("/*__PLOTLYJS__*/", plotly_js) |>
  fill("/*__DATA__*/", json)
html_path <- file.path(pkg_dir, html_file)
writeBin(charToRaw(enc2utf8(html)), html_path)

# =============================================================================
# Stage 7. Verification
# =============================================================================
written <- read_file(html_path)
json_back <- regmatches(written, regexpr("(?s)/\\*__DATA_START__\\*/.*?/\\*__DATA_END__\\*/",
                                         written, perl = TRUE))
json_back <- sub("^/\\*__DATA_START__\\*/", "", sub("/\\*__DATA_END__\\*/$", "", json_back))
emb <- fromJSON(json_back, simplifyVector = FALSE)

# every key anywhere in the embedded JSON
all_keys <- function(x) {
  if (!is.list(x)) return(character())
  c(names(x), unlist(lapply(x, all_keys), use.names = FALSE))
}
emb_keys <- unique(all_keys(emb))
csv_headers <- unique(c(header, outlet_header))
extra_cols <- setdiff(emb_keys, c(csv_headers, structural_keys))
if (length(extra_cols)) stop("Embedded JSON has columns that are not in the EDI CSVs: ",
                             paste(extra_cols, collapse = ", "))
if (!identical(names(emb$columns), header)) stop("Embedded data columns differ from the CSV header.")
walk(emb$outlets, \(o) if (!identical(names(o$columns), outlet_header)) {
  stop("Embedded outlet columns differ from the outlet CSV header.")
})
emb_rows <- length(emb$columns[[1]])
if (emb_rows != nrow(data.df)) stop("Embedded row count differs from the CSV.")

# what the page's "download reviewed data" writes with nothing turned off,
# rebuilt the same way from the embedded text: must equal the file byte for byte
cols_back <- map(emb$columns, unlist)
no_toggle <- paste0(
  paste(c(paste(emb$header, collapse = ","), do.call(paste, c(unname(cols_back), sep = ","))),
        collapse = emb$eol),
  if (isTRUE(emb$final_eol)) emb$eol else "")
same_bytes <- identical(charToRaw(enc2utf8(no_toggle)), dat$bytes)
if (!same_bytes) stop("Rebuilding the CSV from the embedded data does not match the file.")

# spelled-out names only (rule 5)
abbrev <- grepl("\\b(SDW|KDW|NoCC|CC)\\b", c(TEMPLATE, json), perl = TRUE)
if (any(abbrev)) stop("An abbreviation (SDW/KDW/CC/NoCC) is in the page.")

cat("\n==== IWI tile drain visualizer: verification ====\n")
cat(sprintf("Data file        : %s  (md5 %s)\n", data_file, dat$md5))
cat(sprintf("Rows x columns   : %d x %d  (embedded: %d rows, %d columns)\n",
            nrow(data.df), ncol(data.df), emb_rows, length(emb$columns)))
cat(sprintf("Metric tabs      : %s\n", paste(metric_cols, collapse = ", ")))
cat(sprintf("Y-axis titles    : %d of %d metrics\n", sum(metric_cols %in% names(emb$labels)), length(metric_cols)))
cat(sprintf("Watersheds       : %s\n", paste(sort(unique(data.df$Watershed)), collapse = ", ")))
cat(sprintf("Outlet files     : %s\n", paste(outlet_files, collapse = ", ")))
walk(outlets, \(o) cat(sprintf("                   %s: %d days\n", o$watershed, length(o$columns$date))))
cat(sprintf("Extra columns in embedded JSON (must be none): %s\n",
            if (length(extra_cols)) paste(extra_cols, collapse = ", ") else "none"))
cat(sprintf("Unedited export rebuilds the file byte for byte: %s\n", same_bytes))
cat(sprintf("HTML written     : %s (%.1f MB)\n", normalizePath(html_path), file.size(html_path) / 1e6))
